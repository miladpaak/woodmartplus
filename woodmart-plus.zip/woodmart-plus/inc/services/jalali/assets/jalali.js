

(function($){
    
    $(document).ready(function(){

        
            // Date picker fields regenaret.
        $( '.sale_price_dates_fields input' ).each(function () {
            if ($(this).hasClass('hasDatepicker')) {
                $(this).datepicker('destroy'); // حذف datepicker جیکوئری UI
            }
        });
        
        $(document).on('woocommerce_variations_loaded',function(wrapper){

            $( '.sale_price_dates_fields' ).each( function () {
                
                $( this ).find( 'input' ).each(function(){

                    var $this = $(this);
                    var $paretns = $this.parents('.woocommerce_variation');
                    // variation-needs-update
                    if ($(this).hasClass('hasDatepicker')) {
                        $(this).datepicker('destroy'); // حذف datepicker جیکوئری UI
                    }
                    
                    var sale_price_dates_from ='';
                    var sale_price_dates_to = '';
                    var $selectedBefore = '';
                    var $selectedDate = '';

                    if( $(this).hasClass('sale_price_dates_from') )
                    {
                        
                        var $variation_name_sale_from = $(this).attr('name');
                        $(this).attr('name','');
                        sale_price_dates_from = $(this).val();
                        $selectedBefore = sale_price_dates_from.length ? 1 : 0;
                        $selectedDate = sale_price_dates_from.length ? sale_price_dates_from.replace(/-/gi, "/") : null;
                        var $date_sale_from = sale_price_dates_from.length ? toGaregorian(sale_price_dates_from) : '';
                        $(this).after('<input class="input_generated_from" type="hidden" name="'+$variation_name_sale_from+'" value="'+$date_sale_from+'">');
                        $(this).on('change',function(){
                            if( $(this).val() == '' )
                            {
                                $(this).next('.input_generated_from').val('');
                            }
                        });
                    }
                    
                    if( $(this).hasClass('sale_price_dates_to') )
                    {
                        var $variation_name_sale_to = $(this).attr('name');
                        $(this).attr('name','');

                        sale_price_dates_to = $(this).val();
                        $selectedBefore = sale_price_dates_to.length ? 1 : 0;
                        $selectedDate = sale_price_dates_to.length ? sale_price_dates_to.replace(/-/gi, "/") : null;
                        var $date_sale_to = sale_price_dates_to.length ? toGaregorian(sale_price_dates_to) : '';
                        $(this).after('<input class="input_generated_to" type="hidden" name="'+$variation_name_sale_to+'" value="'+$date_sale_to+'">')
                        $(this).on('change',function(){
                            if( $(this).val() == '' )
                            {
                                $(this).next('.input_generated_to').val('');
                            }
                        });
                    }
                    
                    $(this).persianDatepicker({
                        formatDate: "YYYY-0M-0D", 
                        selectedBefore: $selectedBefore,
                        selectedDate: $selectedDate,
                        onSelect:function()
                        {
                            $paretns.addClass('variation-needs-update');
                            if( $this.hasClass('sale_price_dates_from') )
                            {
                                var gdate_from = $this.attr("data-gdate");
                                if( gdate_from !== "NaN-0NaN-0NaN" ){
                                    $this.next('.input_generated_from').val(gdate_from);
                                }
                            }
                            if( $this.hasClass('sale_price_dates_to') )
                            {
                                var gdate_to = $this.attr("data-gdate");
    
                                if( gdate_to !== "NaN-0NaN-0NaN" ){
                                    $this.next('.input_generated_to').val(gdate_to);
                                }
                            }
                        }
                    });

                });
            });
        });

        $( '.sale_price_dates_fields' ).each( function () {
            
            $( this ).find( 'input' ).each(function(){

                var $this = $(this);
                var sale_price_dates_from ='';
                var sale_price_dates_to = '';
                var $selectedBefore = '';
                var $selectedDate = '';
                
                if( $(this).attr('id') === '_sale_price_dates_from' )
                {
                    sale_price_dates_from = $(this).val();
                    var $name_sale_from = $(this).attr('name');
                    $(this).attr('name','');
                    $selectedBefore = sale_price_dates_from.length ? 1 : 0;
                    $selectedDate = sale_price_dates_from.length ? sale_price_dates_from.replace(/-/gi, "/") : null
                    var $date_sale_from = sale_price_dates_from.length ? toGaregorian(sale_price_dates_from) : '';
                    $(this).after('<input class="input_generated_from" type="hidden" name="'+$name_sale_from+'" value="'+$date_sale_from+'">');
                    $(this).on('change',function(){
                        if( $(this).val() == '' )
                        {
                            $('.input_generated_from').val('');
                        }
                    });
                }

                if( $(this).attr('id') === '_sale_price_dates_to' )
                {
                    sale_price_dates_to = $(this).val();
                    var $name_sale_to = $(this).attr('name');
                    $(this).attr('name','');
                    $selectedBefore = sale_price_dates_to.length ? 1 : 0;
                    $selectedDate = sale_price_dates_to.length ? sale_price_dates_to.replace(/-/gi, "/") : null
                    var $date_sale_to = sale_price_dates_to.length ? toGaregorian(sale_price_dates_to) : '';
                    $(this).after('<input class="input_generated_to" type="hidden" name="'+$name_sale_to+'" value="'+$date_sale_to+'">')

                    $(this).on('change',function(){
                        if( $(this).val() == '' )
                        {
                            $('.input_generated_to').val('');
                        }
                    });
                }
                    
                $(this).persianDatepicker({
                    formatDate: "YYYY-0M-0D", 
                    selectedBefore: $selectedBefore,
                    selectedDate: $selectedDate,
                    onSelect:function(){
                        
                        if( $this.attr('id') === '_sale_price_dates_from' )
                        {
                            var gdate_from = $this.attr("data-gdate");
                            if( gdate_from !== "NaN-0NaN-0NaN" ){
                                $('.input_generated_from').val(gdate_from);
                            }
                        }
                        if( $this.attr('id') === '_sale_price_dates_to' )
                        {
                            var gdate_to = $this.attr("data-gdate");

                            if( gdate_to !== "NaN-0NaN-0NaN" ){
                                $('.input_generated_to').val(gdate_to);
                            }
                        }
                        
                    }
                });
            });
    
        });

        
        
        var $datePicker = $('#woocommerce-order-data .date-picker');

        if( $datePicker.length )
        {
            $datePicker.datepicker('destroy');
            var selectdate = $datePicker.val();
            var $name = $datePicker.attr( 'name');
            $datePicker.attr( 'name','');
            
            $date = toGaregorian(selectdate);
            
            $datePicker.after('<input class="input_generated" type="hidden" name="'+$name+'" value="'+$date+'">')
    
            $datePicker.persianDatepicker( {
                formatDate: "YYYY-0M-0D",
                selectedBefore: selectdate.length ? 1 : 0,
                selectedDate: selectdate.length ? selectdate.replace(/-/gi, "/") : null,
                onSelect:function(){
                    var gdate = $datePicker.attr("data-gdate");
                    
                    if( gdate !== "NaN-0NaN-0NaN" )
                    {
                        $('.input_generated').val(gdate);
                    }
                }
            } );
        }

        var $couponDatePicker = $('#coupon_options .date-picker');
        if( $couponDatePicker.length )
        {
            $couponDatePicker.datepicker('destroy');
            var selectdate = $couponDatePicker.val();
            var $name = $couponDatePicker.attr( 'name');
            $couponDatePicker.attr( 'name','');

            $couponDatePicker.after('<input class="input_generated" type="hidden" name="'+$name+'" value="'+selectdate+'">')

            $couponDatePicker.persianDatepicker( {
                formatDate: "YYYY-0M-0D",
                selectedBefore: selectdate.length ? 1 : 0,
                selectedDate: selectdate.length ? toJalali(selectdate).replace(/-/gi, "/") : null,
                onSelect:function(){
                    var gdate = $couponDatePicker.attr("data-gdate");
                    
                    if( gdate !== "NaN-0NaN-0NaN" )
                    {
                        $('.input_generated').val(gdate);
                    }
                }
            } );

            $couponDatePicker.on('change',function(){
                if( $(this).val() == '' )
                {
                    $('.input_generated').val('');
                }
            });
        }

        var adminDate =  $('[id*="post-"]');
        
        if( adminDate.length )
        {
            adminDate.each(function(){
                var $this = $(this);
                // $this.find('input[name="aa"]')
                // console.log( $this );
            });
        }

        $(document.body).on('click','.editinline,.edit-timestamp',function(){
            

            var adminTrPost = $('tr[id*="edit-"],#timestampdiv');

            if( !adminTrPost.length ) return;

            let year_input = adminTrPost.find('input[name="aa"]');

            let year_milad = year_input.val();
            let month_miladi = adminTrPost.find('select[name="mm"]').find(':selected').val();
            let day_milad = adminTrPost.find('input[name="jj"]').val();

            let month_option = adminTrPost.find('select[name="mm"]>option');

            let $shamsi_year = shamsi_year();
                
            var $objectJalali = toJalali( year_milad + '-' + month_miladi + '-' + day_milad ,true );
            
            month_option.each(function(){
                $(this).text($shamsi_year[$(this).val()]['output']);
                $(this).attr('data-text',$shamsi_year[$(this).val()]['output']);
                $(this).val($shamsi_year[$(this).val()]['value']);
                                
            });
            adminTrPost.find('select[name="mm"]> option[value="0'+$objectJalali.jm+'"]').prop('selected', true);
            
            year_input.val($objectJalali.jy);
            adminTrPost.find('input[name="jj"]').val($objectJalali.jd);
        });

        $(document).ready(function(){
            var $filterDate = $('#filter-by-date option');
            var $shamsi_year = shamsi_year();

            $filterDate.each(function(){
                var $this = $(this);
                var $value = $this.val();
                if( 0 != $value )
                {
                    // let part1 = $value.split(" ");
                    let part1 = $value.slice(0, 4);
                    let part2 = $value.slice(4);
                    
                    $shamsi_year[part2]['output'] //out put;

                    var $objectJalali = toJalali( part1 + '-3-21' ,true );

                    $this.text( $shamsi_year[part2]['output'] +' '+ $objectJalali.jy );
                }
            });
            
        })
        function shamsi_year(){

            return {
                '01':{
                    'output' : 'بهمن',
                    'value' : '11'
                },
                '02':{
                    'output' : 'اسفند',
                    'value' : '12'
                },
                '03' : {
                    'output' : 'فروردین',
                    'value' : '01'
                },
                '04' : {
                    'output' : 'اردیبهشت',
                    'value' : '02'
                },
                '05' : {
                    'output' : 'خرداد',
                    'value' : '03'
                },
                '06' : {
                    'output' : 'تیر',
                    'value' : '04'
                },
                '07' : {
                    'output' : 'مرداد',
                    'value' : '05'
                },
                '08' : {
                    'output' : 'شهریور',
                    'value' : '06'
                },
                '09' : {
                    'output' : 'مهر',
                    'value' : '07'
                },
                '10' : {
                    'output' : 'آبان',
                    'value' : '08'
                },
                '11' : {
                    'output' : 'آذر',
                    'value' : '09'
                },
                '12' : {
                    'output' : 'دی',
                    'value' : '10'
                },

            };
            
        }
        function getShamsiYear(miladiYear) {
            const jalaliDate = jalaali.toJalaali(miladiYear, 3, 21); // 21 مارس
            return jalaliDate.jy;
        }
        
        function getMiladiYear(shamiYear) {
            console.log( shamiYear );
            const jalaliDate = jalaali.toGregorian(shamiYear, '01', '01'); // 21 مارس
            return jalaliDate.gy;
        }

        function toGaregorian( date )
        {
            if( !date ) return '';
            
            let [jy, jm, jd] = date.split('-').map(Number);
            let jalaliDate = { jy, jm, jd };
            let gregorianDate = jalaali.toGregorian(jalaliDate.jy, jalaliDate.jm, jalaliDate.jd);
            
            return `${gregorianDate.gy}-${String(gregorianDate.gm).padStart(2, '0')}-${String(gregorianDate.gd).padStart(2, '0')}`;
        }
        
        function toJalali( date,object = false )
        {
            
            let [jy, jm, jd] = date.split('-').map(Number);
            let jalaliDate = { jy, jm, jd };
            let gregorianDate = jalaali.toJalaali(jalaliDate.jy, jalaliDate.jm, jalaliDate.jd);
            
            if( object )
            {
                return gregorianDate;
            }

            return `${gregorianDate.jy}-${String(gregorianDate.jm).padStart(2, '0')}-${String(gregorianDate.jd).padStart(2, '0')}`;
        }
        
       
    });
})( jQuery );
