(function($){

    $(document).ready(function(){

        $(document).on('click','.woocommerce-dropdown-button',function(){
            $('#tab-panel-0-custom').remove();
        });
        
    });
})( jQuery );