<?php

return [
    'order_customer' => [
        'customer_pending_now' => [
            'title' => 'پیامک سفارش بلافاصله بعد از خرید',
            'description' => 'ایجاد پیامک سفارش بلافاصله بعد از خرید',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام %billing_first_name% جان! ‍
                سفارش شما با شماره پیگیری %billing_order_id% ثبت شد و در حال حاضر در انتظار پردازش است.
                مبلغ کل سفارش شما: %billing_price_total%
                ما به زودی سفارش رو آماده و به شما اطلاع رسانی میکنیم.
                ممنون که از ( %shop_name% ) خرید کردی، منتظرتیم تا خریدت رو دریافت کنی!',
            
        ],
        'customer_processing' => [
            'title' => 'پیامک سفارش درحال انجام',
            'description' => 'ایجاد پیامک سفارش درحال انجام',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام %billing_first_name% جان! 
            سفارش شما با شماره پیگیری %billing_order_id% در حال پردازش است و تیم ما مشغول آماده‌سازی محصول برای ارسال به شماست.
            به زودی سفارش شما آماده و برای شما ارسال خواهد شد.
            ممنون که از ( %shop_name% ) خرید کردی، منتظرتیم تا سفارشت رو دریافت کنی!',
        ],
        'customer_onhold' => [
            'title' => 'پیامک سفارش در انتظار بررسی',
            'description' => 'ایجاد پیامک سفارش در انتظار بررسی',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام %billing_first_name% جان! 
            سفارش شما با شماره پیگیری %billing_order_id% ثبت شد و در حال بررسی است.
            مبلغ کل سفارش شما: %billing_price_total%
            پس از تکمیل بررسی‌ها، به زودی وضعیت سفارش شما به روزرسانی خواهد شد و اطلاع رسانی خواهد شد .
            ممنون که از ( %shop_name% ) خرید کردی، منتظرتیم تا سریع‌تر سفارشت رو ارسال کنیم!',
        ],
        'customer_completed' => [
            'title' => 'پیامک سفارش تکمیل شده',
            'description' => 'ایجاد پیامک سفارش تکمیل شده',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام %billing_first_name% جان 
            سفارش شما با شماره پیگیری %billing_order_id% تکمیل شد و برات ارسال شد.
            ممنون که از ( %shop_name% ) خرید کردی، امیدواریم از خریدت لذت ببری!',
        ],
        'customer_cancelled' => [
            'title' => 'پیامک سفارش لغو شده',
            'description' => 'ایجاد پیامک سفارش لغو شده',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام %billing_first_name% جان !
            متاسفانه سفارش شما با شماره پیگیری %billing_order_id% به دلایلی لغو شد.
            اگر سوالی دارید یا نیاز به کمک دارید، می‌توانید با تیم پشتیبانی ( %shop_name% ) تماس بگیرید ما همواره کمکت میکنیم 
            ممنون که از ( %shop_name% ) خرید کردی و امیدواریم در خریدهای بعدی دوباره به ما اعتماد کنید!',
        ],
        'customer_refunded' => [
            'title' => 'پیامک سفارش مسترد شده',
            'description' => 'ایجاد پیامک سفارش مسترد شده',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام %billing_first_name% جان
            سفارش شما با شماره پیگیری %billing_order_id% مسترد شد و مبلغ سفارش به حساب شما بازگشت داده شد.
            مبلغ مسترد شده: %billing_price_total%
            اگر سوالی داشتید یا به کمک نیاز دارید، تیم پشتیبانی ( %shop_name% ) در خدمت شماست.
            ممنون که از ( %shop_name% ) خرید کردید و امیدواریم دوباره شما رو در فروشگاه ببینیم!',
        ],
        'customer_failed' => [
            'title' => 'پیامک سفارش ناموفق',
            'description' => 'ایجاد پیامک سفارش ناموفق',
            'website' => 'https://website.com', #home_url(),
            'message' => 'متاسفانه سفارش شما با شماره پیگیری %billing_order_id% به دلیل مشکل در پردازش، ناموفق بود.
            مبلغ کل سفارش شما: %billing_price_total%
            لطفاً دوباره تلاش کنید یا با تیم پشتیبانی ( %shop_name% ) تماس بگیرید تا مشکل رفع بشه.
            ممنون از صبر و شکیبایی شما، در خدمتتون هستیم!',
        ],
    ],
    'order_manager' => [
        'manager_pending_now' => [
            'title' => 'پیامک سفارش بلافاصله بعد از خرید مدیر',
            'description' => 'ایجاد پیامک سفارش بلافاصله بعد از خرید مدیر',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام مدیر سایت عزیز ...
            تبریک ....
            سفارشی در ( %shop_name% ) با مبلغ %billing_price_total% توسط ( %customer_full_name% ) ثبت گردید و منتظر نتیجه است ، لطفا به آن رسیدگی نمایید .',
            
        ],
        'manager_pending' => [
            'title' => 'پیامک سفارش در انتظار پرداخت مدیر',
            'description' => 'ایجاد پیامک سفارش در انتظار پرداخت مدیر',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام مدیر عزیز ...
            سفارشی در ( %shop_name% ) با مبلغ %billing_price_total% توسط ( %customer_full_name% ) در انتظار پرداخت است',
        ],
        'manager_onhold' => [
            'title' => 'پیامک سفارش در انتظار بررسی مدیر',
            'description' => 'ایجاد پیامک سفارش در انتظار بررسی مدیر',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سلام مدیر عزیز،
            سفارش با شماره پیگیری %billing_order_id% برای کاربر %customer_full_name% در حال انتظار بررسی است.
            مبلغ سفارش: %billing_price_total%
            لطفاً وضعیت سفارش را بررسی کنید و در صورت نیاز اقدام لازم را انجام دهید.
            با تشکر، تیم ( %shop_name% )',
        ],
        'manager_failed' => [
            'title' => 'پیامک سفارش ناموفق مدیر',
            'description' => 'ایجاد پیامک سفارش ناموفق مدیر',
            'website' => 'https://website.com', #home_url(),
            'message' => 'سفارش با شماره پیگیری %billing_order_id% برای کاربر %customer_full_name% ناموفق بود.
            مشکل در پردازش سفارش پیش آمده است. لطفاً بررسی کنید و در صورت نیاز اقدامات لازم را انجام دهید.
            مبلغ سفارش: %billing_price_total%
            با تشکر، تیم ( %shop_name% )',
        ],
    ],
    'order_tracking' => [
        'order_tracking_post' => [
            'title' => 'پیامک پیگیری سفارش',
            'description' => 'ایجاد پیامک برای پیگری سفارشات پستی',
            'website' => 'https://website.com',
            'message' => 'سلام %billing_first_name% جان
            سفارش شما به شماره %billing_order_id% در تاریخ %date_tracking% تکمیل و تحویل اداره %shipping_tracking% شد ، شماره پیگیری : %consignment_tracking%
            نام فروشگاه : %shop_name%
            '
        ],
        'order_tracking_delivery' => [
            'title'   => 'پیامک پیگیری سفارش پیک',
            'description' => 'ایجاد پیامک برای پیگری سفارشات پیک',
            'website' => 'https://website.com',
            'message' => 'سلام %billing_first_name% جان
            سفارش شما به شما %billing_order_id% در تاریخ %date_tracking% تحویل پیک شد ، شماره پیک : %delivery_mob_tracking%
            نام فروشگاه : %shop_name%
            '
        ],
    ],
    'ticket_notif' => [
        'ticket_new_to_manager' => [
            'title' => 'متن ارسال تیکت زمانی که کاربر یک تیکت جدید باز کرد ( ارسال به مدیر )',
            'description' => 'زمانی که کاربر تیکت باز میکند از این پنرن استفاده میشود',
            'website' => 'https://website.com',
            'message' => 'سلام مدیر  ، یک  تیکت با شناسه : %ticket_id% 
            توسط %ticket_fullname% برای شما ثبت شده و منتظر پاسخگویی است .
            اولویت این تیکت : %ticket_priority% میباشد 
            دپارتمان : %ticket_departman% [ در صورتی که قبلا دپارتمان وارد کرده باشد ] 
            %home_url% '
        ],
        'ticket_new_to_customer' => [
            'title' => 'متن ارسال تیکت زمانی که کاربر یک تیکت جدید باز کرد ( ارسال به کاربر)',
            'description' => 'زمانی که کاربر تیکت جدید باز میکند از این پترن استفاده میشود',
            'website' => 'https://website.com',
            'message' => 'سلام %ticket_fullname% عزیز 
            تیکت شما با شماره %ticket_id% ثبت شد و در اسرع وقت توسط پشتیبانان ما پاسخ داده خواهد شد .
            پس از پاسخ مدیر اطلاع رسانی حضورتان انجام میگردد 
            %home_url%'
        ],
        'ticket_answer_to_manager' => [
            'title' => 'زمانی کاربر تیکت را پاسخ داد(ارسال به مدیر)',
            'description' => 'زمانی که کاربر تیکت جدید باز میکند از این پترن استفاده میشود',
            'website' => 'https://website.com',
            'message' => 'سلام مدیر عزیز 
            تیکت شماره %ticket_id% توسط کاربر پاسخ داده شد و %ticket_fullname% منتظر پاسخ شماست .
            %home_url% '
        ],
        'ticket_answer_to_customer' => [
            'title' => 'زمانی کاربر تیکت را پاسخ داد(ارسال به کاربر)',
            'description' => 'زمانی که کاربر تیکت جدید باز میکند از این پترن استفاده میشود',
            'website' => 'https://website.com',
            'message' => 'سلام %ticket_fullname% عزیز 
            پاسخ تیکت شما با شماره %ticket_id% به تیم پشتیبانی ارسال شد و  در اسرع وقت توسط پشتیبانان ما پاسخ داده خواهد شد .
            پس از پاسخ مدیر اطلاع رسانی حضورتان انجام میگردد 
            %home_url%'
        ],
        'ticket_touser' => [
            'title' => 'زمانی که تیکت کاربر پاسخ داده میشود(ارسال به کاربر)',
            'description' => 'زمانی که کاربر تیکت جدید باز میکند از این پترن استفاده میشود',
            'website' => 'https://website.com',
            'message' => 'سلام %ticket_fullname% عزیز 
            تیکت شما به شماره شناسه %ticket_id% توسط تیم پشتیبانی پاسخ داده شد .
            میتوانید همین حالا به تیکت مراجعه نمایید .
            %home_url%'
        ],
        'ticket_from_admin_to_user' => [
            'title' => 'زمانی کاربر تیکت را پاسخ داد(ارسال به کاربر)',
            'description' => 'زمانی که کاربر تیکت جدید باز میکند از این پترن استفاده میشود',
            'website' => 'https://website.com',
            'message' => 'سلام %ticket_fullname% عزیز ، یک تیکت توسط تیم پشتیبانی برای شما ارسال شده است ، لطفا در اسرع وقت آن را مشاهده نمایید 
            با تشکر از شما %home_url%'
        ]
    ]  
];