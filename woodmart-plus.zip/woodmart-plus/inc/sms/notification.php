<?php

require_once 'smsSender.php';

class notification
{


    public function __call($name , $arguments)
    {
        $method = lcfirst(substr($name,4));
        $class_name = $method . 'Sender';
       

        if(!class_exists($class_name)){

            throw new \Exception('class Not Exists');
        }
        
        $provider = new $class_name(...$arguments);
        
        return $provider->send();
    }


}