<?php $id = self::generate_uniqe_id($field['name']); ?>
<div class="wc_extra_field wc_extra_field_select">
    <label class="title_extra_field" for="<?php echo $id; ?>"><?php echo esc_html( $field['label'] ); ?>
        <?php if( $field['field_required'] ): ?>
            <abbr class="required" title="<?php esc_html_e('ضروری','woodmartplus') ?>">*</abbr>
        <?php endif; ?>
    </label>
    <div class="box_wc_extra_field_value wc_extra_field_select_value">
        <select name="<?php echo esc_html($field['name']); ?>" id="<?php echo $id ?>">
            <?php echo self::generate_options_select_box($field['select_box_options']);?>
        </select>
    </div>
</div>