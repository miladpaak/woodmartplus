
<div class="wc_extra_field wc_extra_field_checkbox_group">
    <span class="title_extra_field" ><?php echo esc_html( $field['label'] ); ?>
        <?php if( $field['field_required'] ): ?>
            <abbr class="required" title="<?php esc_html_e('ضروری','woodmartplus') ?>">*</abbr>
        <?php endif; ?>
    </span>
    <div class="box_wc_extra_field_value wc_extra_field_checkbox_group_value">
        <?php
        echo self::generate_checkbox_group($field['check_box_options'],$field['name']);
        ?>
    </div>
</div>