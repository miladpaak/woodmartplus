<?php $id = self::generate_uniqe_id($field['name']); ?>
<div class="wc_extra_field wc_extra_field_checkbox">
    <label class="title_extra_field" for="<?php echo $id; ?>"><?php echo esc_html( $field['label'] ); ?>
        <?php if( $field['field_required'] ): ?>
            <abbr class="required" title="<?php esc_html_e('ضروری','woodmartplus') ?>">*</abbr>
        <?php endif; ?>
    </label>
    <div class="box_wc_extra_field_value wc_extra_field_checkbox_value">
        <input id="<?php echo $id; ?>" type="checkbox" name="<?php echo esc_html($field['name']); ?>" value="<?php echo esc_html( $field['default_checkbox'] ) ?>" placeholder="<?php echo esc_html( $field['placeholder'] ) ?>" />
    </div>
</div>