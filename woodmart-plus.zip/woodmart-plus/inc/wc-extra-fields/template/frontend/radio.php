<div class="wc_extra_field wc_extra_field_radio">
    <label class="title_extra_field" ><?php echo esc_html( $field['label'] ); ?>
        <?php if( $field['field_required'] ): ?>
            <abbr class="required" title="<?php esc_html_e('ضروری','woodmartplus') ?>">*</abbr>
        <?php endif; ?>
    </label>
    <div class="box_wc_extra_field_value wc_extra_field_radio_value">
        <?php echo self::generate_radio_button($field['radio_options'],$field['name'],$field['default'],$field['placeholder']); ?>
    </div>
</div>