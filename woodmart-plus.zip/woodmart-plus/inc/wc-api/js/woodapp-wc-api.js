/**
 * App Custom Option Js
 * @param-key:
 */
(function ($) {
  jQuery(document).ready(function () {
    // jQuery('.wood-hid-section').hide();
    // jQuery('body').on('click','.product_input_check',function(e){

    // 	if($(this).is(":checked")) {
    // 		$(".wood-hid-section").show();
    // 	} else {
    // 		$(".wood-hid-section").hide();
    // 	}
    // });
    /**
     * On update option or settings show loader
     */
    if (document.getElementById("woodapp-expand-div-options-products-carousel")) {
      jQuery(
        ".woodapp-wc-api-sort-products-carousel, .woodapp-wc-api-sort-footer-app"
      ).sortable({
        //placeholder: "ui-state-highlight"
      });
      jQuery(".woodapp-wc-api-sort-products-carousel").disableSelection();

      jQuery(".woodapp-expand-div-btn").each(function () {
        jQuery(this).on("click", function () {
          jQuery(this).next(".woodapp-expand-div-content").toggle("1000");
          jQuery("i", this).toggleClass(
            "dashicons dashicons-arrow-up dashicons dashicons-arrow-down"
          );
        });
      });
      var disable_url = jQuery(".disable-data-url").attr("data-url");
      jQuery(document).on("click", ".carousel-box-status", function () {
        var carouselstatus = jQuery(this).val();
        if (carouselstatus == "enable") {
          var lblid = jQuery(this).attr("data-id");
          jQuery("#" + lblid).removeClass("woodapp-wc-api-disable-lbl");
          jQuery(".is-disable-" + lblid).html("");
        } else {
          var lblid = jQuery(this).attr("data-id");

          jQuery("#" + lblid).addClass("woodapp-wc-api-disable-lbl");
          jQuery(".is-disable-" + lblid).html(
            '<img src="' + disable_url + '" alt="disable" />'
          );
        }
      });
    }

    /** End **/

    /**
     * On update option or settings show loader
     */
    if (document.getElementById("publish-btn")) {
      jQuery("#publish-btn").on("click", function () {
        jQuery(".spinner").css("visibility", "visible");
      });
    }
    /** End **/

    /**
     * Show / Hide options
     */
    jQuery(".feature-box-status").on("click", function () {
      var status = jQuery(this).val();
      if (status == "disable") {
        jQuery(".feature-box").hide();
      } else {
        jQuery(".feature-box").show();
      }
    });
    /** End **/

    /**
     * Show / Hide options
     */

    jQuery(".home-layout-button-status").on("click", function () {
      var status = jQuery(this).val();
      if (status == "default") {
        jQuery(".home-layout-scroll-options").show();
      } else {
        jQuery(".home-layout-scroll-options").show();
      }
    });

    /** End **/

    /**
     * Show / Hide options
     */
    /*jQuery('.whatsapp-floating-button-status').on('click',function(){
			var status = jQuery(this).val();
			if(status == "disable"){
				jQuery('.woodapp-wc-api-whatsapp-no').hide();
			} else {
				jQuery('.woodapp-wc-api-whatsapp-no').show();
			}
		});*/
    /** End **/

    /**
     * Main Category Icon image.
     */
    var get_cat_id;
    var main_category_icon;
    var get_cat_icon;
    var cat_media_holder;
    var removeimage;
    var cat_image_id;
    var imagelbl;
    var get_cat_icon_id;
    jQuery(document).on("change", ".woodapp-wc-api_main_category", function () {
      get_cat_id = jQuery(this).val();
      get_cat_icon = jQuery(this).find(":selected").attr("data-caticon");
      get_cat_icon_id = jQuery(this).find(":selected").attr("data-caticonid");
      main_category_icon = jQuery(this)
        .parents(".woodapp-wc-api-field-group")
        .find(".woodapp-wc-api_main_category_icon");
      cat_media_holder = jQuery(main_category_icon).find(".upload_image");
      removeimage = jQuery(main_category_icon).find(".remove-image-button");
      cat_image_id = jQuery(main_category_icon).find(".upload_image_id");
      imagelbl = jQuery(main_category_icon).find(".upload-image-button");
      if (get_cat_id) {
        if (get_cat_icon != "") {
          var img =
            '<img src="' + get_cat_icon + '" width="150px" height="150px" />';
          jQuery(removeimage).show();
          jQuery(cat_image_id).val(get_cat_icon_id);
          jQuery(imagelbl).text("Edit");
        } else {
          var img = "";
          jQuery(removeimage).hide();
          jQuery(cat_image_id).val("");
          jQuery(imagelbl).text("Add Image");
        }
        jQuery(cat_media_holder).html(img);
        jQuery(main_category_icon).show();
      } else {
        jQuery(main_category_icon).hide();
      }
    });
    /** End **/

    /**
     * Add Datepiker on user date of birth field
     */
    if (document.getElementById("dob")) {
      jQuery("#dob").datepicker({
        dateFormat: "mm/dd/yy",
      });
    }
    /** End **/

    /*
     * Open filte upload onclick button
     */
    if (document.getElementById("open_pem_file_dev")) {
      jQuery("#open_pem_file_dev").on("click", function (event) {
        event.preventDefault();
        jQuery("#pem_file_dev").trigger("click");
      });

      jQuery(document).on("change", "#pem_file_dev", function () {
        var dev_file =
          this.files && this.files.length ? this.files[0].name : "";
        jQuery("#pem-dev-file-desc").text(dev_file);
      });
    }
    if (document.getElementById("open_pem_file_pro")) {
      jQuery("#open_pem_file_pro").on("click", function (event) {
        event.preventDefault();
        jQuery("#pem_file_pro").trigger("click");
      });

      jQuery(document).on("change", "#pem_file_pro", function () {
        var pro_file =
          this.files && this.files.length ? this.files[0].name : "";
        jQuery("#pem-pro-file-desc").text(pro_file);
      });
    }
    /** End **/

    /**
     *
     * WP Media Upload popup box
     *
     */
    var mediaUploader;
    var $this;
    // jQuery(document).on("click", ".upload-image-button", function (event) {
    //   event.preventDefault();
    //   ($this = jQuery(this)),
    //     (current_parent = jQuery(this).closest(".woodapp-wc-api-field-group"));
    //   media_holder = jQuery(current_parent).find(".upload_image");
    //   hd_image_id = jQuery(current_parent).find(".upload_image_id");

    //   // If the uploader object has already been created, reopen the dialog
    //   if (mediaUploader) {
    //     mediaUploader.open();
    //     return;
    //   }
    //   // Extend the wp.media object
    //   mediaUploader = wp.media.frames.file_frame = wp.media({
    //     title: woodapp_wc_api.choose_image,
    //     button: {
    //       text: woodapp_wc_api.choose_image,
    //     },
    //     multiple: false,
    //   });

    //   // When a file is selected, grab the URL and set it as the text field's value
    //   mediaUploader.on("select", function () {
    //     var attachment = mediaUploader
    //       .state()
    //       .get("selection")
    //       .first()
    //       .toJSON();
    //     jQuery(current_parent)
    //       .find(".upload-image-button")
    //       .removeClass("button button-primary")
    //       .addClass("button button-default")
    //       .html("Edit");
    //     var img =
    //       '<img src="' + attachment.url + '" width="150px" height="150px" />';
    //     jQuery(media_holder).html(img);
    //     jQuery(hd_image_id).val(attachment.id);
    //     jQuery(current_parent).find(".remove-image-button").show();
    //   });
    //   // Open the uploader dialog
    //   mediaUploader.open();
    // });

    //Remove image on click remove button
    jQuery(document).on("click", ".remove-image-button", function (event) {
      event.preventDefault();
      var $this = jQuery(this);
      $this.parent().find(".upload_image").html("");
      $this
        .parent()
        .find(".upload-image-button")
        .removeClass("button button-default")
        .html("Edit");
      $this
        .parent()
        .find(".upload-image-button")
        .addClass("button button-primary")
        .html(woodapp_wc_api.add_image);

      $this.parent().find(".remove-image-button").hide();
      $this.parent().find(".upload_image_id").val(0);
    });
    /** End **/

    // Add Color Picker to all inputs that have 'color-field' class
    jQuery(".cpa-color-picker").wpColorPicker();

    /*
     * Vertical tabs
     */
    if (document.getElementById("woodapp-wc-api-tabs")) {
      var index = "woodapp-wc-api-active-tab";
      //  Define friendly data store name
      var store_data = window.sessionStorage;
      var old_index = 0;
      //  Start magic!
      try {
        // getter: Fetch previous value
        old_index = store_data.getItem(index);
      } catch (e) {}
      var woodappTabs = jQuery("#woodapp-wc-api-tabs")
        .tabs({
          active: old_index,
          activate: function (event, ui) {
            //  Get future value
            var new_index = ui.newTab.parent().children().index(ui.newTab);
            //  Set future value
            try {
              store_data.setItem(index, new_index);
              old_id = ui.newPanel.attr("id");
            } catch (e) {}
          },
        })
        .addClass("ui-tabs-vertical ui-helper-clearfix");
      jQuery("#woodapp-wc-api-tabs li")
        .removeClass("ui-corner-top")
        .addClass("ui-corner-left");
    }
    /** End **/

    /*
     * Repeater Field
     */
    ("use strict");
    jQuery("#woodapp-wc-api-main_slider").repeater({
      show: function () {
        jQuery(".upload_image", this).html("");
        jQuery(".upload-image-button", this)
          .removeClass("button button-default")
          .html("Edit");
        jQuery(".upload-image-button", this)
          .addClass("button button-primary")
          .html(woodapp_wc_api.add_image);
        jQuery(".remove-image-button", this).hide();
        jQuery(this).slideDown();
      },
      hide: function (deleteElement) {
        //if(confirm(woodapp_wc_api.delete_msg)) {
        jQuery(this).slideUp(deleteElement);
        //}
      },
      ready: function (setIndexes) {},
    });

    jQuery(
      "#woodapp-wc-api-category-banners,#woodapp-wc-api-banner-ad,#woodapp-wc-api-feature-box,#woodapp-wc-api-coupon"
    ).repeater({
      show: function () {
        jQuery(".cpa-color-picker-category_banner").wpColorPicker();
        jQuery(".upload_image", this).html("");
        jQuery(".upload-image-button", this)
          .removeClass("button button-default")
          .html("Edit");
        jQuery(".upload-image-button", this)
          .addClass("button button-primary")
          .html(woodapp_wc_api.add_image);
        jQuery(".remove-image-button", this).hide();
        jQuery(this).slideDown();
      },
      hide: function (deleteElement) {
        //if(confirm(woodapp_wc_api.delete_msg)) {
        jQuery(this).slideUp(deleteElement);
        //}
      },
      ready: function (setIndexes) {
        jQuery(".cpa-color-picker-category_banner").wpColorPicker();
      },
    });

    jQuery(
      "#woodapp-wc-api-info-pages,#woodapp-wc-api-main-category,#woodapp-wc-api-is-web-view"
    ).repeater({
      initEmpty: false,
      show: function () {
        jQuery(".upload_image", this).html("");
        jQuery(".upload-image-button", this)
          .removeClass("button button-default")
          .html("Edit");
        jQuery(".upload-image-button", this)
          .addClass("button button-primary")
          .html(woodapp_wc_api.add_image);
        jQuery(".remove-image-button", this).hide();
        jQuery(this).slideDown();

        if (
          jQuery(this).parents("#woodapp-wc-api-main-category").attr("data-limit")
            .length > 0
        ) {
          if (
            jQuery(this)
              .parents("#woodapp-wc-api-main-category")
              .find("div[data-repeater-item]").length <=
            jQuery(this)
              .parents("#woodapp-wc-api-main-category")
              .attr("data-limit")
          ) {
            jQuery(this).slideDown();
          } else {
            jQuery(this).remove();
          }
        } else {
          jQuery(this).slideDown();
        }
      },
      hide: function (deleteElement) {
        //if(confirm(woodapp_wc_api.delete_msg)) {
        jQuery(this).slideUp(deleteElement);
        //}
      },
      ready: function (setIndexes) {},
    });

    /*
     * Remove app cat image on add new image with ajax
     */
    jQuery("input[name=submit]").on("click", function () {
      setTimeout(function () {
        jQuery("#product_app_cat_thumbnail")
          .find("img")
          .attr(
            "src",
            woodapp_wc_api.woodapp_api_url + "img/woodapp_app_cat_placeholder.jpg"
          );
        jQuery("#product_app_cat_thumbnail_id").val(0);
        jQuery(".remove_app_image_button").hide();
      }, 2000);
    });
    /** End **/

    /**
     * Second media Popup box for App cat image
     */
    // var mediaUploader;
    jQuery(document).on("click", ".upload_app_image_button", function (event) {
      event.preventDefault();
      var $this = jQuery(this),
        current_parent = jQuery(this).closest(".form-field");
      media_holder = jQuery(current_parent).find(".upload_image");

      // If the uploader object has already been created, reopen the dialog
      if (mediaUploader) {
        mediaUploader.open();
        return;
      }
      // Extend the wp.media object
      mediaUploader = wp.media.frames.file_frame = wp.media({
        title: woodapp_wc_api.choose_image,
        button: {
          text: woodapp_wc_api.choose_image,
        },
        multiple: false,
      });

      // When a file is selected, grab the URL and set it as the text field's value
      mediaUploader.on("select", function () {
        var attachment = mediaUploader
          .state()
          .get("selection")
          .first()
          .toJSON();
        var img =
          '<img src="' + attachment.url + '" width="60px" height="60px" />';
        jQuery(media_holder).html(img);
        jQuery(current_parent).find(".upload_image_id").val(attachment.id);
        jQuery(current_parent).find(".remove_app_image_button").show();
      });
      // Open the uploader dialog
      mediaUploader.open();
    });

    jQuery(document).on("click", "#remove-image-button", function (event) {
      event.preventDefault();
      var $this = jQuery(this);
      current_parent = jQuery(this).closest(".form-field");
      jQuery("#product_app_cat_thumbnail")
        .find("img")
        .attr(
          "src",
          woodapp_wc_api.woodapp_api_url + "img/woodapp_app_cat_placeholder.jpg"
        );
      jQuery(current_parent).find(".upload_image_id").val(0);
      jQuery(".remove_app_image_button").hide();
    });
    /** End **/

    /**
     * Call test api
     */
    if (document.getElementById("test-api-btn")) {
      jQuery(document).on("click", "#test-api-btn", function () {
        jQuery.ajax({
          url: ajaxurl,
          type: "post",
          dataType: "json",
          data: { action: "woodapp_wc_api_test_api_ajax_call" },
          beforeSend: function () {
            jQuery(".woodapp-loader").addClass("'woodapp-api'-console");
            jQuery(".woodapp-loader").html("loading..");
          },
          success: function (response) {
            jQuery(".woodapp-loader").html(response);
          },
          error: function (msg) {
            alert("Something went wrong!");
            jQuery(".woodapp-loader").removeClass("'woodapp-api'-console");
            jQuery(".woodapp-loader").html("");
          },
        });
      });
    }

    /**
     * Submit token generations proccess form fields to ajax
     */
    jQuery(document).on("click", ".token-gen-pro", function () {
      var id = jQuery(this).attr("id");
      var form_data = "";
      if (id == "stp-1") {
        //var form_data = $(".step-1 :input");
        form_data += '<input type="hidden" name="step" value="1" />';
      } else if (id == "stp-2") {
        var oauth_consumer_key = jQuery("input[name=oauth_consumer_key]").val();
        var oauth_consumer_secret = jQuery(
          "input[name=oauth_consumer_secret]"
        ).val();
        var oauth_token = jQuery("input[name=oauth_token]").val();
        var oauth_token_secret = jQuery("input[name=oauth_token_secret]").val();
        var oauth_verifier = jQuery("input[name=oauth_verifier]").val();

        form_data +=
          '<input type="hidden" name="oauth_consumer_key" value="' +
          oauth_consumer_key +
          '" />';
        form_data +=
          '<input type="hidden" name="oauth_consumer_secret" value="' +
          oauth_consumer_secret +
          '" />';
        form_data +=
          '<input type="hidden" name="oauth_token" value="' +
          oauth_token +
          '" />';
        form_data +=
          '<input type="hidden" name="oauth_token_secret" value="' +
          oauth_token_secret +
          '" />';
        form_data +=
          '<input type="hidden" name="oauth_verifier" value="' +
          oauth_verifier +
          '" />';
        form_data += '<input type="hidden" name="step" value="2" />';
      }

      jQuery("<form>", {
        id: "getwoodappApiData",
        html: form_data,
        action: "",
      })
        .appendTo(document.body)
        .submit();
    });

    /**
     * On update option or settings show loader
     */
    if (document.getElementById("geo-publish-btn")) {
      jQuery("#geo-publish-btn").on("click", function () {
        jQuery(".spinner").css("visibility", "visible");
      });
    }

    /**
     * Display device images based on device selected
     */
    if (document.getElementsByClassName("woodapp-woo-device-img-display")) {
      jQuery(".woodapp-woo-device-img-display").on("click", function (e) {
        e.preventDefault();
        jQuery(this)
          .parents(".woodapp-wc-api-panel-sidebar")
          .find(".woodapp-woo-device-img-display")
          .removeClass("active");
        jQuery(this).addClass("active");
        jQuery(this)
          .parents(".woodapp-wc-api-panel-sidebar")
          .find(".device-display")
          .addClass("hidden");
        jQuery("#" + jQuery(this).data("target")).removeClass("hidden");
      });
    }
    jQuery(".credentials-code-device-img").on("click", function (e) {
      e.preventDefault();

      jQuery(".credentials-code-device-img").removeClass("active");
      jQuery(this).addClass("active");
      var html_cd = "";
      var credentials_code = "Something went wrong!",
        client_key = jQuery("input.client_key").val(),
        client_secret = jQuery("input.client_secret").val(),
        token = jQuery("input.token").val(),
        token_secret = jQuery("input.token_secret").val(),
        consumer_key = jQuery("input.consumer_key").val(),
        consumer_secret = jQuery("input.consumer_secret").val(),
        site_url = jQuery("input.woodapp-site-url").val();
      plugin_varsion = woodapp_app_sample_data_import_object.plugin_ver;
      android_purchased = woodapp_app_sample_data_import_object.purchased_android;
      ios_purchased = woodapp_app_sample_data_import_object.purchased_ios;
      purchasekey_android =
        woodapp_app_sample_data_import_object.purchasekey_android;
      purchasekey_ios = woodapp_app_sample_data_import_object.purchasekey_ios;

      if (
        client_key == "" ||
        client_secret == "" ||
        token == "" ||
        token_secret == "" ||
        consumer_key == "" ||
        consumer_secret == ""
      ) {
        credentials_code = "Something went wrong!";
        jQuery("#credentials-code-api-btn").hide();
      } else if (jQuery(this).data("target") == "credentials-code-android") {
        html_cd = "";
        if (android_purchased) {
          html_cd += 'public final String APP_URL = "' + site_url + '/";\n';
          html_cd +=
            'public final String WOO_MAIN_URL = APP_URL + "wp-json/wc/v2/";\n';
          html_cd +=
            'public final String MAIN_URL = APP_URL + "wp-json/woodapp-wc-api/v1/";\n\n';
          html_cd +=
            'public static final String CONSUMERKEY = "' + client_key + '";\n';
          html_cd +=
            'public static final String CONSUMERSECRET = "' +
            client_secret +
            '";\n';
          html_cd +=
            'public static final String OAUTH_TOKEN = "' + token + '";\n';
          html_cd +=
            'public static final String OAUTH_TOKEN_SECRET = "' +
            token_secret +
            '";\n\n';
          html_cd +=
            'public static final String WOOCONSUMERKEY = "' +
            consumer_key +
            '";\n';
          html_cd +=
            'public static final String WOOCONSUMERSECRET = "' +
            consumer_secret +
            '";\n';
          html_cd +=
            'public static final String version="' + plugin_varsion + '";\n';
          html_cd +=
            'public static final String purchasekey="' +
            purchasekey_android +
            '";';
          jQuery("#credentials-code-api-btn").show();
        } else {
          html_cd +=
            "Please validate item purchase code. App Settings > Support";
        }
        credentials_code = html_cd;
      } else if (jQuery(this).data("target") == "credentials-code-ios") {
        html_cd = "";
        if (ios_purchased) {
          html_cd += '#define OAUTH_CUSTOMER_KEY @"' + consumer_key + '" \n';
          html_cd +=
            '#define OAUTH_CUSTOMER_SERCET @"' + consumer_secret + '"\n\n';
          html_cd +=
            '#define OAUTH_CONSUMER_KEY_PLUGIN @"' + client_key + '"\n';
          html_cd +=
            '#define OAUTH_CONSUMER_SECRET_PLUGIN @"' + client_secret + '"\n';
          html_cd += '#define OAUTH_TOKEN_PLUGIN @"' + token + '"\n';
          html_cd +=
            '#define OAUTH_TOKEN_SECRET_PLUGIN @"' + token_secret + '"\n\n';
          html_cd += '#define appURL @"' + site_url + '/"\n';
          html_cd += '#define PATH appURL@"wp-json/wc/v2/"\n';
          html_cd +=
            '#define OTHER_API_PATH appURL@"wp-json/woodapp-wc-api/v1/"\n';
          html_cd += '#define PLUGIN_VERSION @"' + plugin_varsion + '"\n';
          html_cd += '#define PURCHASEKEY @"' + purchasekey_ios + '";';
          jQuery("#credentials-code-api-btn").show();
        } else {
          html_cd +=
            "Please validate item purchase code from App Settings > Support";
        }
        credentials_code = html_cd;
      }
      jQuery(".woodapp-wc-api-credentials-code").removeClass("woodapp-hidden");
      jQuery(".woodapp-wc-api-credentials-code").text(credentials_code);
    });

    jQuery("#credentials-code-api-btn").on("click", function (e) {
      e.preventDefault();
      jQuery(".woodapp-wc-api-credentials-code").select();
      document.execCommand("copy");
    });

    jQuery("#htaccess-code-toggle").click(function () {
      jQuery("#htaccess-code").toggle(function () {
        // Animation complete.
      });
    });

    jQuery(".woodapp-wc-api-import-this-sample").click(function (e) {
      e.preventDefault();
      //alert('sdfsdf');
      if (jQuery(this).hasClass("disabled")) {
        return false;
      }

      var current_element = jQuery(e.target);

      if (current_element.data("message")) {
        var import_message = unescape(current_element.data("message"));
      } else {
        var import_message =
          woodapp_app_sample_data_import_object.alert_default_message;
      }

      var install_required_plugins = false;
      if (current_element.data("required-plugins")) {
        install_required_plugins = true;
      }

      var template = wp.template("woodapp-wc-api-sample-import-alert");
      var template_content = template({
        title: current_element.data("title"),
        message: import_message,
        //import_requirements_list: sample_data_import_object.sample_data_requirements,
        required_plugins_list:
          woodapp_app_sample_data_import_object.sample_data_required_plugins_list,
      });

      jQuery.confirm({
        title: woodapp_app_sample_data_import_object.alert_title,
        content: template_content,
        type: "red",
        icon: "fa fa-warning",
        animation: "scale",
        closeAnimation: "scale",
        bgOpacity: 0.8,
        columnClass:
          "col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1 sample-data-confirm",
        buttons: {
          confirm: {
            text: woodapp_app_sample_data_import_object.alert_proceed,
            btnClass: "btn-green",
            action: function () {
              if (install_required_plugins) {
                window.location = woodapp_app_sample_data_import_object.tgmpa_url;
              } else {
                // ********************************** Ajax Start **********************************

                var sample_import_nonce = jQuery("#sample_import_nonce").val();

                var data = {
                  action: "woodapp_wc_api_plugin_import_sample", //calls wp_ajax_nopriv_ajaxlogin
                  sample_id: current_element.data("id"),
                  sample_import_nonce:
                    woodapp_app_sample_data_import_object.sample_import_nonce,
                  action_source: "plugin-options",
                };

                jQuery.ajax({
                  type: "POST",
                  dataType: "json",
                  url: woodapp_app_sample_data_import_object.ajaxurl,
                  data: data,
                  beforeSend: function (xhr) {
                    jQuery("#woodapp-wc-api-panel-body-loader")
                      .parent()
                      .addClass("overlay-loader");
                    jQuery("#woodapp-wc-api-panel-body-loader").html(
                      '<span class="sample-data-loader">Loading..</span>'
                    );
                    //overlay-loader
                  },
                  success: function (data) {
                    // Hide Loader
                    //jQuery(loader).removeClass('is-active');

                    // Hide Overlay
                    //overlay.fadeOut( 'fast' );

                    if (data.success) {
                      jQuery(".data-alert-notitication")
                        .html(data.message)
                        .slideDown("slow")
                        .delay(5000)
                        .slideUp("slow");
                      jQuery(".data-alert-notitication")
                        .html(data.alert_msg)
                        .delay(500)
                        .slideDown("slow")
                        .delay(15000)
                        .slideUp("slow");

                      // Reload Page
                      window.setTimeout(function () {
                        jQuery("#woodapp-wc-api-panel-body-loader").html("");
                        jQuery("#woodapp-wc-api-panel-body-loader")
                          .parent()
                          .removeClass("overlay-loader");
                        document.location.href = document.location.href;
                      }, 5000);
                    } else {
                      jQuery("#woodapp-wc-api-panel-body-loader").html("");
                      jQuery("#woodapp-wc-api-panel-body-loader")
                        .parent()
                        .removeClass("overlay-loader");
                      //jQuery('.data-alert-notitication').html(data.alert_msg).slideDown('slow').delay(5000).slideUp('slow');
                      jQuery(".data-alert-notitication").html(data.alert_msg);
                    }
                    return data;
                  },
                });
                //**********************************  Ajax End  **********************************
              }
            },
          },
          cancel: {
            text: woodapp_app_sample_data_import_object.alert_cancel,
            btnClass: "btn-red",
          },
        },
        onContentReady: function () {
          if (install_required_plugins) {
            this.buttons.confirm.setText(
              woodapp_app_sample_data_import_object.alert_install_plugins
            );
          }
        },
        onOpen: function () {
          // $.alert('onOpen');
        },
      });
    });

  

    /**
     * WhatsUpp phone number validation
     */
    if (document.getElementById("woodapp-wc-api-whatsapp-no-validation")) {
      jQuery("#woodapp-wc-api-whatsapp-no-validation").on("input", function (e) {
        if (
          !woodapp_wc_api_validate_phone("woodapp-wc-api-whatsapp-no-validation")
        ) {
          jQuery("#validation_status").html("Invalid");
          jQuery("#validation_status").css("color", "red");
        } else {
          jQuery("#validation_status").html("");
          //jQuery('#validation_status').css('color', 'green');
        }
      });
    }
    /**
     * WhatsUpp phone number validation rules
     */
    function woodapp_wc_api_validate_phone(phone_txt) {
      var phone_val = document.getElementById(phone_txt).value;
      var valid_rules1 = (patt1 = /\++/g);
      var valid_rules2 =
        /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
      if (valid_rules1.test(phone_val) && valid_rules2.test(phone_val)) {
        return true;
      } else {
        return false;
      }
    }

    /**
     * Show / Hide options
     */
    jQuery(".checkout-multistep-button-status").on("click", function () {
      var status = jQuery(this).val();
      if (status == "disable") {
        jQuery("#woodapp_wc_api_multi_num_of_steps_button-groups").hide();
        jQuery("#checkout-android-section")
          .find("img")
          .attr(
            "src",
            woodapp_app_sample_data_import_object.checkout_imge_url_admin +
              "/android/checkout.png"
          );
        jQuery("#checkout-ios-section")
          .find("img")
          .attr(
            "src",
            woodapp_app_sample_data_import_object.checkout_imge_url_admin +
              "/ios/checkout.png"
          );
      } else {
        jQuery("#woodapp_wc_api_multi_num_of_steps_button-groups").show();
        jQuery("#checkout-android-section")
          .find("img")
          .attr(
            "src",
            woodapp_app_sample_data_import_object.checkout_imge_url_admin +
              "/android/multistep.png"
          );
        jQuery("#checkout-ios-section")
          .find("img")
          .attr(
            "src",
            woodapp_app_sample_data_import_object.checkout_imge_url_admin +
              "/ios/multistep.png"
          );
      }
    });

    /** End **/
    if (
      document.getElementById("woodapp_wc_api_multi_num_of_steps_button-groups")
    ) {
      jQuery(".woodapp_wc_api_multi_num_of_steps_button").on(
        "click",
        function () {
          if (jQuery(this).attr("data-step") == 4) {
            jQuery("#woodapp-img-steps-3").removeClass("image-select-selected");
            jQuery("#woodapp-img-steps-4").addClass("image-select-selected");
          } else {
            jQuery("#woodapp-img-steps-4").removeClass("image-select-selected");
            jQuery("#woodapp-img-steps-3").addClass("image-select-selected");
          }
        }
      );
    }

    if (document.getElementById("woodapp-wc-api-custom-section-product")) {
      setTimeout(function () {
        jQuery(".woodapp-wc-api-custom-section-product")
          .find("select")
          .each(function () {
            var $this = jQuery(this);
            get_more_product($this);
          });
      }, 100);

      jQuery(".woodappaddcfield, .woodappremovecfield").on("click", function () {
        setTimeout(function () {
          jQuery(".woodapp-wc-api-custom-section-product")
            .find("select")
            .each(function () {
              var $this = jQuery(this);
              get_more_product($this);
            });
        }, 100);
      });
    }

    if (document.getElementById("woodapp-woo-product-baner-section")) {
      setTimeout(function () {
        jQuery(".woodapp-woo-product-baner-section")
          .find("select")
          .each(function () {
            var $this = jQuery(this);
            get_more_product($this);
          });
          
      }, 100);

      jQuery(".woodapp-banner-product-select,.add_product_slider").on("click", function () {
        setTimeout(function () {
          jQuery(".woodapp-woo-product-baner-section")
            .find("select")
            .each(function () {
              var $this = jQuery(this);
              get_more_product($this);
            });
        }, 100);
      });
    }

    if (document.getElementById("woodapp-woo-product-baner-ad-section")) {
      setTimeout(function () {
        jQuery(".woodapp-woo-product-baner-ad-section")
          .find("select")
          .each(function () {
            var $this = jQuery(this);
            get_more_product($this);
          });
      }, 100);

      jQuery(".woodapp-banner-ads-product-select").on("click", function () {
        setTimeout(function () {
          jQuery(".woodapp-woo-product-baner-ad-section")
            .find("select")
            .each(function () {
              var $this = jQuery(this);
              get_more_product($this);
            });
        }, 100);
      });
    }

    function get_more_product($this) {
      jQuery($this).select2({
        ajax: {
          url: ajaxurl + "?action=woodapp_wc_api_get_customsection_products",
          //type: 'POST',
          dataType: "json",
          delay: 250,
          placeholder: "Breed...",
          data: function (params) {
            return {
              search: params.term,
              page: params.page || 1,
            };
          },
          processResults: function (data) {
            data.page = data.page || 1;
            return {
              results: data.items,
              pagination: {
                more: data.pagination,
              },
            };
          },
        },
        allowClear: true,
        cache: true,
        placeholder: "Search for products",
        templateResult: formatPro,
        templateSelection: formatproSelection,
      });
    }
    
    function get_more_category($this) {
      jQuery($this).select2({
        ajax: {
          url: ajaxurl + "?action=search_categories",
          //type: 'POST',
          dataType: "json",
          delay: 250,
          placeholder: "Breed...",
          data: function (params) {
            return {
              search: params.term,
              page: params.page || 1,
            };
          },
          processResults: function (data) {
            data.page = data.page || 1;
            return {
              results: data.items,
              pagination: {
                more: data.pagination,
              },
            };
          },
        },
        allowClear: true,
        cache: true,
        placeholder: "Search for products",
        templateResult: formatPro,
        templateSelection: formatproSelection,
      });
    }

    function formatPro(pro) {
      if (pro.loading) {
        return pro.text;
      }

      var $container = $(
        "<div class='select2-result-repository clearfix'>" +
          "<div class='select2-result-repository__avatar'><img src='" +
          pro.img +
          "' width='50px' height='50px' /></div>" +
          "<div class='select2-result-repository__meta'>" +
          "<div class='select2-result-repository__title'></div>" +
          "<div class='select2-result-repository__description'></div>" +
          "</div>" +
          "</div>"
      );
      $container.find(".select2-result-repository__title").text(pro.text);
      $container
        .find(".select2-result-repository__description")
        .html(pro.price);
      return $container;
    }

    function formatproSelection(pro) {
      return pro.text;
    }

  //  $('.app_slider_section').each(function (index , element) {
  //       var $this = $(this);

  //       var $val = $this.find('.choose_type_show_app_slider').val();

  //       console.log( $val );
  //  })

    $(".woo-hide-ads-select").hide();
    $(".category_bannerad_input_check").click(function () {
      if ($(this).is(":checked")) {
        $(".woo-hide-ads-select").show();
      } else {
        $(".woo-hide-ads-select").hide();
      }
    });

    $(".woo-hide-ads-product").hide();
    $(".bannerad_input_check").click(function () {
      if ($(this).is(":checked")) {
        $(".woo-hide-ads-product").show();
      } else {
        $(".woo-hide-ads-product").hide();
      }
    });

    //   $('.condition-trigger').each(function(e){
    // 		var $this = $(this);
    // 		var id_element = $this.attr('id');
    // 		console.log(id_element);

    //   });
    // $.fn.conditionalFields = function (action) {
    // 	var $base = $(this);
    // 	function toggle_field($field, trigger_value, val) {
    // 		if ($.inArray(trigger_value, val) !== -1) {
    // 			if ($field.css('display') === 'none')
    // 				$field.slideDown(500);
    // 		}
    // 		else {
    // 			if ($field.css('display') !== 'none') {
    // 				$field.slideUp(500);
    // 			}
    // 		}
    // 	}
    // 	function update_fields() {
    // 		var $fields = $base.find('[data-condition][data-condition-value]');
    // 		var $field, condition, condition_values, $trigger, trigger_value;
    // 		$.each($fields, function () {
    // 			$field = $(this);
    // 			condition = $field.attr('data-condition');
    // 			condition_values = $field.attr('data-condition-value').toString().split(';');
    // 			$trigger = $('[name="' + condition + '"]');
    // 			if($trigger.is('[type="radio"]')){
    // 				$trigger = $('[name="' + condition + '"]:checked');
    // 			}
    // 			if ($trigger.length) {
    // 				if($trigger.length === 1){
    // 					trigger_value = $trigger.val().toString();
    // 					if($trigger.is('[type="checkbox"]')){
    // 						trigger_value = $trigger.prop( "checked" ) ? '1' : '0';
    // 					}
    // 					toggle_field($field, trigger_value, condition_values);
    // 				}
    // 				else {
    // 					var or = '0';
    // 					var and = '1';
    // 					$.each($trigger, function (id, trigger_instance) {
    // 						trigger_value = $(trigger_instance).val().toString();
    // 						if($trigger.is('[type="checkbox"]')){
    // 							trigger_value = $trigger.prop( "checked" ) ? '1' : '0';
    // 						}
    // 						if ($.inArray(trigger_value, condition_values) !== -1) {
    // 							or = '1';
    // 						}
    // 						else {
    // 							and = '0';
    // 						}
    // 					});
    // 					if($field.hasClass('condition-logical-or')){
    // 						trigger_value = or;
    // 					}
    // 					else {
    // 						trigger_value = and;
    // 					}
    // 					toggle_field($field, trigger_value, ['1']);
    // 				}
    // 			}
    // 			else {
    // 				if ($field.css('display') !== 'none'){
    // 					$field.slideUp(500);
    // 				}
    // 			}
    // 		});
    // 	}
    // 	function init_events(){
    // 		$base.on('change', '.condition-trigger', function () {

    // 			update_fields();
    // 		});
    // 		$base.on('click', '.condition-trigger-delayed', function () {
    // 			var delay = $(this).attr('data-delay');
    // 			setTimeout(function () {
    // 				update_fields();
    // 			}, delay);
    // 		});
    // 	}
    // 	if(action === 'init'){
    // 		init_events();
    // 		update_fields();
    // 	}
    // 	if(action === 'update'){
    // 		update_fields();
    // 	}
    // }
    // $('body').conditionalFields('init');

    jQuery("#custom_section_date_picker_2").datepicker({
      dateFormat: "yy-mm-dd",
    });

    var $stories = woodapp_wc_api.stories
    let storyCounter = 1;
    let subitemCounter = 1;
    
    // متغیرهای گلوبال برای ذخیره داده‌ها
    let storiesData = {};
    
    // افزودن استوری جدید
    $('#add-new-story').on('click', function() {
        addNewStory();
    });
    
    // حذف استوری
    $(document).on('click', '.remove-story-btn', function() {
        const storyId = $(this).data('story-id');
        $(`.story-item[data-story-id="${storyId}"]`).fadeOut(300, function() {
            $(this).remove();
            delete storiesData[storyId];
        });
    });
    
    // افزودن زیرمجموعه
    $(document).on('click', '.add-subitem-btn', function() {
        const storyId = $(this).data('story-id');
        addNewSubitem(storyId);
    });
    
    // حذف زیرمجموعه
    $(document).on('click', '.remove-subitem-btn', function() {
        const subitemId = $(this).data('subitem-id');
        $(`.subitem-item[data-subitem-id="${subitemId}"]`).fadeOut(300, function() {
            $(this).remove();
        });
    });
    
    // تغییر عنوان استوری
    $(document).on('input', '.story-title-input', function() {
        const storyId = $(this).closest('.story-item').data('story-id');
        const title = $(this).val();
        
        if (storiesData[storyId]) {
            storiesData[storyId].title = title;
        }
    });

    // تغییر نوع لینک
    $(document).on('change', '.link-type-select', function() {
        const subitemId = $(this).data('subitem-id');
        const linkType = $(this).val();
        
        // مخفی کردن همه انتخاب‌ها
        $(`.product-selection[data-subitem-id="${subitemId}"]`).hide();
        $(`.category-selection[data-subitem-id="${subitemId}"]`).hide();
        
        // نمایش انتخاب مربوطه
        if (linkType === 'product') {
            $(`.product-selection[data-subitem-id="${subitemId}"]`).show();
            initProductSelect2(subitemId);
        } else if (linkType === 'category') {
            $(`.category-selection[data-subitem-id="${subitemId}"]`).show();
            initCategorySelect2(subitemId);
        }
    });
    
    // آپلود تصویر
    $(document).on('click', '.upload-image-btn', function() {
        const type = $(this).data('type');
        const storyId = $(this).data('story-id');
        const subitemId = $(this).data('subitem-id');
        
        // ایجاد media uploader
        const mediaUploader = wp.media({
            title: 'انتخاب تصویر',
            button: {
                text: 'انتخاب تصویر'
            },
            multiple: false
        });
        
        mediaUploader.on('select', function() {
            const attachment = mediaUploader.state().get('selection').first().toJSON();
            
            if (type === 'main') {
                updateMainImage(storyId, attachment);
            } else if (type === 'subitem') {
                updateSubitemImage(subitemId, attachment);
            }
        });
        
        mediaUploader.open();
    });
    
    // حذف تصویر
    $(document).on('click', '.remove-image-btn', function() {
        const type = $(this).data('type');
        const storyId = $(this).data('story-id');
        const subitemId = $(this).data('subitem-id');
        
        if (type === 'main') {
            removeMainImage(storyId);
        } else if (type === 'subitem') {
            removeSubitemImage(subitemId);
        }
    });
    
    // تابع افزودن استوری جدید
    function addNewStory() {
        const storyId = storyCounter++;
        const storyUnqieId = GenerateUniqeId(8,false,false);
        const template = $('#story-template').html();
        const compiled = template
            .replace(/\{\{storyId\}\}/g, storyId)
            .replace(/\{\{storyTitle\}\}/g, '')
            .replace(/\{\{mainImageUrl\}\}/g, '')
            .replace(/\{\{mainImageDisplay\}\}/g, 'none')
            .replace(/\{\{noImageDisplay\}\}/g, 'block')
            .replace(/\{\{removeBtnDisplay\}\}/g, 'none')
            .replace(/\{\{mainImageId\}\}/g, '')
            .replace(/\{\{storyUnqieId\}\}/g, storyUnqieId);
        
        $('#stories-list').append(compiled);
        
        // مقداردهی اولیه داده‌ها
        storiesData[storyId] = {
            title: '',
            mainImage: null,
            subitems: {}
        };
        
        // انیمیشن ورود
        $(`.story-item[data-story-id="${storyId}"]`).hide().fadeIn(500);
    }
    
    // تابع افزودن زیرمجموعه جدید
    function addNewSubitem(storyId) {
        const subitemId = subitemCounter++;
        const template = $('#subitem-template').html();
        const compiled = template
            .replace(/\{\{storyId\}\}/g, storyId)
            .replace(/\{\{subitemId\}\}/g, subitemId)
            .replace(/\{\{subitemImageUrl\}\}/g, '')
            .replace(/\{\{subitemImageDisplay\}\}/g, 'none')
            .replace(/\{\{subitemNoImageDisplay\}\}/g, 'block')
            .replace(/\{\{subitemRemoveBtnDisplay\}\}/g, 'none')
            .replace(/\{\{storySubTitle\}\}/g, '')
            .replace(/\{\{subitemImageId\}\}/g, '');
        
        $(`.subitems-list[data-story-id="${storyId}"]`).append(compiled);
        
        // مقداردهی اولیه داده‌ها
        if (!storiesData[storyId]) {
            storiesData[storyId] = { subitems: {} };
        }
        storiesData[storyId].subitems[subitemId] = {
            image: null,
            linkType: '',
            productId: '',
            categoryId: ''
        };
        
        // انیمیشن ورود
        $(`.subitem-item[data-subitem-id="${subitemId}"]`).hide().fadeIn(500);
    }
    
    // تابع به‌روزرسانی تصویر اصلی
    function updateMainImage(storyId, attachment) {
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .image-preview img`).attr('src', attachment.url).show();
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .no-image-placeholder`).hide();
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .remove-image-btn`).show();
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .main-image-input`).val(attachment.id);
        
        storiesData[storyId].mainImage = {
            id: attachment.id,
            url: attachment.url
        };
    }
    
    // تابع حذف تصویر اصلی
    function removeMainImage(storyId) {
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .image-preview img`).hide();
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .no-image-placeholder`).show();
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .remove-image-btn`).hide();
        $(`.story-item[data-story-id="${storyId}"] .story-main-image .main-image-input`).val('');
        
        storiesData[storyId].mainImage = null;
    }
    
    // تابع به‌روزرسانی تصویر زیرمجموعه
    function updateSubitemImage(subitemId, attachment) {
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .image-preview img`).attr('src', attachment.url).show();
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .no-image-placeholder`).hide();
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .remove-image-btn`).show();
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .subitem-image-input`).val(attachment.id);
        
        // پیدا کردن storyId مربوطه
        const storyId = $(`.subitem-item[data-subitem-id="${subitemId}"]`).closest('.story-item').data('story-id');
        if (storiesData[storyId] && storiesData[storyId].subitems[subitemId]) {
            storiesData[storyId].subitems[subitemId].image = {
                id: attachment.id,
                url: attachment.url
            };
        }
    }
    
    // تابع حذف تصویر زیرمجموعه
    function removeSubitemImage(subitemId) {
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .image-preview img`).hide();
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .no-image-placeholder`).show();
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .remove-image-btn`).hide();
        $(`.subitem-item[data-subitem-id="${subitemId}"] .subitem-image .subitem-image-input`).val('');
        
        // پیدا کردن storyId مربوطه
        const storyId = $(`.subitem-item[data-subitem-id="${subitemId}"]`).closest('.story-item').data('story-id');
        if (storiesData[storyId] && storiesData[storyId].subitems[subitemId]) {
            storiesData[storyId].subitems[subitemId].image = null;
        }
    }
    
    // تابع مقداردهی Select2 محصولات
    function initProductSelect2(subitemId) {
      get_more_product($(`.product-select2[data-subitem-id="${subitemId}"]`));

        
        // ذخیره تغییرات محصول
        $(`.product-select2[data-subitem-id="${subitemId}"]`).on('change', function() {
            const productId = $(this).val();
            const storyId = $(`.subitem-item[data-subitem-id="${subitemId}"]`).closest('.story-item').data('story-id');
            
            if (storiesData[storyId] && storiesData[storyId].subitems[subitemId]) {
                storiesData[storyId].subitems[subitemId].productId = productId;
                storiesData[storyId].subitems[subitemId].linkType = 'product';
            }
        });
    }
    
    function initCategorySelect2(subitemId) {
      // get_more_category( $(`.category-select2[data-subitem-id="${subitemId}"]`));
        $(`.category-select2[data-subitem-id="${subitemId}"]`).select2({
            ajax: {
                url: ajaxurl,
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return {
                        search: params.term,
                        action: 'search_categories',
                    };
                },
                processResults: function (data) {
                    return {
                        results: data.map(function(item) {
                            return {
                                id: item.id,
                                text: item.name
                            };
                        })
                    };
                },
                cache: true
            },
            minimumInputLength: 2,
            placeholder: 'جستجو و انتخاب دسته‌بندی...',
            allowClear: true,
            language: {
                noResults: function() {
                    return "دسته‌بندی یافت نشد";
                },
                searching: function() {
                    return "در حال جستجو...";
                }
            }
        });
        
        // ذخیره تغییرات دسته‌بندی
        $(`.category-select2[data-subitem-id="${subitemId}"]`).on('change', function() {
            const categoryId = $(this).val();
            const storyId = $(`.subitem-item[data-subitem-id="${subitemId}"]`).closest('.story-item').data('story-id');
            
            if (storiesData[storyId] && storiesData[storyId].subitems[subitemId]) {
                storiesData[storyId].subitems[subitemId].categoryId = categoryId;
                storiesData[storyId].subitems[subitemId].linkType = 'category';
            }
        });
    }

    // Preselect helpers for Select2 with async data
    function preselectProduct(subitemId, productId) {
        const $select = $(`.product-select2[data-subitem-id="${subitemId}"]`);
        if (!$select.data('select2')) {
            get_more_product($select);
        }
        // تا دریافت لیبل، هیچ آیتمی را انتخاب نکن
        showInlineLoader($select);
        $select.prop('disabled', true);
        // دریافت لیبل صحیح از طریق AJAX اختصاصی بر اساس ID
        jQuery.ajax({
            url: ajaxurl,
            type: 'GET',
            dataType: 'json',
            data: { action: 'woodapp_wc_api_get_product_label', id: productId }
        }).done(function (data) {
            if (data && (data.text || data.name)) {
                const label = data.text || data.name;
                // اگر option موجود نیست ایجاد کن، سپس انتخاب کن
                let $opt = $select.find(`option[value="${productId}"]`);
                if ($opt.length === 0) {
                    const option = new Option(label, productId, true, true);
                    $select.append(option).trigger('change');
                } else {
                    $opt.text(label);
                    $select.val(productId).trigger('change');
                }
            }
        }).always(function () {
            hideInlineLoader($select);
            $select.prop('disabled', false);
        });
    }

    function preselectCategory(subitemId, categoryId) {
        const $select = $(`.category-select2[data-subitem-id="${subitemId}"]`);
        if (!$select.data('select2')) {
            initCategorySelect2(subitemId);
        }
        // تا دریافت لیبل، هیچ آیتمی را انتخاب نکن
        showInlineLoader($select);
        $select.prop('disabled', true);
        // دریافت لیبل صحیح از طریق AJAX اختصاصی بر اساس ID
        jQuery.ajax({
            url: ajaxurl,
            type: 'GET',
            dataType: 'json',
            data: { action: 'woodapp_wc_api_get_category_label', id: categoryId }
        }).done(function (data) {
            if (data && (data.text || data.name)) {
                const label = data.text || data.name;
                let $opt = $select.find(`option[value="${categoryId}"]`);
                if ($opt.length === 0) {
                    const option = new Option(label, categoryId, true, true);
                    $select.append(option).trigger('change');
                } else {
                    $opt.text(label);
                    $select.val(categoryId).trigger('change');
                }
            }
        }).always(function () {
            hideInlineLoader($select);
            $select.prop('disabled', false);
        });
    }

    // Inline loader helpers
    function showInlineLoader($select) {
        const $container = $select.closest('.select2-container').length
            ? $select.closest('.select2-container')
            : $select.parent();
        if ($container.find('.woodapp-inline-loader').length === 0) {
            const $loader = jQuery('<span class="woodapp-inline-loader" style="margin-right:6px; vertical-align: middle; display:inline-block;">\u23F3</span>');
            // Place before the select2 rendered element when possible
            if ($container.hasClass('select2-container')) {
                $container.prepend($loader);
            } else {
                $select.before($loader);
            }
        }
    }
    function hideInlineLoader($select) {
        const $container = $select.closest('.select2-container').length
            ? $select.closest('.select2-container')
            : $select.parent();
        $container.find('.woodapp-inline-loader').remove();
    }
    function loadSavedStories() {
        const savedStories = $stories;
        if (savedStories && Object.keys(savedStories).length > 0) {
            $('#stories-list').empty();
            
            Object.keys(savedStories).forEach(function(storyId) {
                const storyData = savedStories[storyId];
                loadSingleStory(storyId, storyData);
            });
            
            // به‌روزرسانی شمارنده‌ها
            const maxStoryId = Math.max(...Object.keys(savedStories).map(Number));
            const maxSubitemId = Math.max(...Object.values(savedStories).map(story => 
                story.subitems ? Math.max(...Object.keys(story.subitems).map(Number)) : 0
            ));
            
            storyCounter = maxStoryId + 1;
            subitemCounter = maxSubitemId + 1;
        } else {
            // اگر استوری ذخیره شده‌ای وجود ندارد، یک استوری خالی اضافه کن
            addNewStory();
        }
    }
    
    // تابع بارگذاری یک استوری
    function loadSingleStory(storyId, storyData) {
        const template = $('#story-template').html();
        const compiled = template
            .replace(/\{\{storyId\}\}/g, storyId)
            .replace(/\{\{storyTitle\}\}/g, storyData.story_title || '')
            .replace(/\{\{mainImageUrl\}\}/g, storyData.story_main_image ? getImageUrl(storyData.story_main_image) : '')
            .replace(/\{\{mainImageDisplay\}\}/g, storyData.story_main_image ? 'block' : 'none')
            .replace(/\{\{noImageDisplay\}\}/g, storyData.story_main_image ? 'none' : 'block')
            .replace(/\{\{removeBtnDisplay\}\}/g, storyData.story_main_image ? 'inline-block' : 'none')
            .replace(/\{\{mainImageId\}\}/g, storyData.story_main_image || '')
            .replace(/\{\{storyUnqieId\}\}/g, storyData.story_id || '');
        
        $('#stories-list').append(compiled);
        
        // مقداردهی اولیه داده‌ها
        storiesData[storyId] = {
            title: storyData.story_title || '',
            mainImage: storyData.story_main_image ? {
                id: storyData.story_main_image,
                url: getImageUrl(storyData.story_main_image)
            } : null,
            subitems: {}
        };
        
        // بارگذاری زیرمجموعه‌ها
        if (storyData.subitems && Object.keys(storyData.subitems).length > 0) {
            Object.keys(storyData.subitems).forEach(function(subitemId) {
                const subitemData = storyData.subitems[subitemId];
                loadSingleSubitem(storyId, subitemId, subitemData);
            });
        }
        
        // انیمیشن ورود
        $(`.story-item[data-story-id="${storyId}"]`).hide().fadeIn(500);
    }
    
    // تابع بارگذاری یک زیرمجموعه
    function loadSingleSubitem(storyId, subitemId, subitemData) {
        const template = $('#subitem-template').html();
        const compiled = template
            .replace(/\{\{storyId\}\}/g, storyId)
            .replace(/\{\{subitemId\}\}/g, subitemId)
            .replace(/\{\{subitemImageUrl\}\}/g, subitemData.subitem_image ? getImageUrl(subitemData.subitem_image) : '')
            .replace(/\{\{subitemImageDisplay\}\}/g, subitemData.subitem_image ? 'block' : 'none')
            .replace(/\{\{subitemNoImageDisplay\}\}/g, subitemData.subitem_image ? 'none' : 'block')
            .replace(/\{\{subitemRemoveBtnDisplay\}\}/g, subitemData.subitem_image ? 'inline-block' : 'none')
            .replace(/\{\{subitemImageId\}\}/g, subitemData.subitem_image || '')
            .replace(/\{\{storySubTitle\}\}/g, subitemData.story_subtitle || '');
        
        $(`.subitems-list[data-story-id="${storyId}"]`).append(compiled);
        
        // مقداردهی اولیه داده‌ها
        if (!storiesData[storyId]) {
            storiesData[storyId] = { subitems: {} };
        }
        storiesData[storyId].subitems[subitemId] = {
            image: subitemData.subitem_image ? {
                id: subitemData.subitem_image,
                url: getImageUrl(subitemData.subitem_image)
            } : null,
            linkType: subitemData.link_type || '',
            productId: subitemData.product_id || '',
            categoryId: subitemData.category_id || ''
        };
        
        // تنظیم مقادیر select ها (ابتدا Select2 را مقداردهی سپس مقدار ذخیره شده را ست کن)
        if (subitemData.link_type) {
            $(`.link-type-select[data-subitem-id="${subitemId}"]`).val(subitemData.link_type);
            if (subitemData.link_type === 'product') {
                $(`.product-selection[data-subitem-id="${subitemId}"]`).show();
                initProductSelect2(subitemId);
                if (subitemData.product_id) {
                    preselectProduct(subitemId, subitemData.product_id);
                }
            } else if (subitemData.link_type === 'category') {
                $(`.category-selection[data-subitem-id="${subitemId}"]`).show();
                initCategorySelect2(subitemId);
                if (subitemData.category_id) {
                    preselectCategory(subitemId, subitemData.category_id);
                }
            }
            $(`.link-type-select[data-subitem-id="${subitemId}"]`).trigger('change.select2');
        }
        
        // انیمیشن ورود
        $(`.subitem-item[data-subitem-id="${subitemId}"]`).hide().fadeIn(500);
    }
   
    function getImageUrl(imageId) {
        return woodapp_wc_api.image_stories[imageId] || '';
    }
    
    function GenerateUniqeId(length = 12, specialChars = true, extraSpecialChars = false)
    {
        let chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        
        if (specialChars) {
            chars += '!@#$%^&*()';
        }
        
        if (extraSpecialChars) {
            chars += '-_ []{}<>~`+=,.;:/?|';
        }
        
        let password = '';
        for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        
        return password;
    }

    loadSavedStories();
  });

    
})(jQuery);
