<?php


defined( 'ABSPATH' ) || exit;
?>
<div class="woocommerce-billing-fields">

	<?php do_action( 'woocommerce_before_checkout_billing_form', $checkout ); ?>

    <?php
        $fields = $checkout->get_checkout_fields( 'billing' );
        $all_fields = [];
        $need = [
            'billing_first_name',
            'billing_last_name'
        ];
        $first_and_last = [];

        foreach ( $fields as $key => $field ) {
            $field['return'] = true;
            $field['class'][] = 'form-group';
            $field['input_class'][] = 'form-input';

            if( in_array( $key ,$need ) )    
            {
                $first_and_last[$key] = woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
            }else{
                $all_fields []= woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );    
            }
            
        }
        
    ?>
    <?php if( !empty( $first_and_last ) ): ?>
        <div class="form-row-app-checkout">
            <?php foreach( $first_and_last as $key => $value ): ?>
                <?php $new_Tag = preg_replace('/<(\/?)p\b([^>]*)>/i', '<$1div$2>', $value); ?>
                    <?php echo $new_Tag; ?>   
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

   <?php if( !empty( $all_fields ) ): ?>
        <?php foreach( $all_fields as $field_value ): ?>    
            <div class="form-group">
                <?php $new_Tag = preg_replace('/<(\/?)p\b([^>]*)>/i', '<$1div$2>', $field_value); ?>
                <?php echo $new_Tag; ?>
            </div>
        <?php endforeach; ?>
   <?php endif; ?>

	<?php do_action( 'woocommerce_after_checkout_billing_form', $checkout ); ?>
</div>

<?php if ( ! is_user_logged_in() && $checkout->is_registration_enabled() ) : ?>
	<div class="woocommerce-account-fields">
		<?php if ( ! $checkout->is_registration_required() ) : ?>

			<p class="form-row form-row-wide create-account">
				<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
					<input class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" id="createaccount" <?php checked( ( true === $checkout->get_value( 'createaccount' ) || ( true === apply_filters( 'woocommerce_create_account_default_checked', false ) ) ), true ); ?> type="checkbox" name="createaccount" value="1" /> <span><?php esc_html_e( 'Create an account?', 'woocommerce' ); ?></span>
				</label>
			</p>

		<?php endif; ?>

		<?php do_action( 'woocommerce_before_checkout_registration_form', $checkout ); ?>

		<?php if ( $checkout->get_checkout_fields( 'account' ) ) : ?>

			<div class="create-account">
				<?php foreach ( $checkout->get_checkout_fields( 'account' ) as $key => $field ) : ?>
					<?php woocommerce_form_field( $key, $field, $checkout->get_value( $key ) ); ?>
				<?php endforeach; ?>
				<div class="clear"></div>
			</div>

		<?php endif; ?>

		<?php do_action( 'woocommerce_after_checkout_registration_form', $checkout ); ?>
	</div>
<?php endif; ?>
