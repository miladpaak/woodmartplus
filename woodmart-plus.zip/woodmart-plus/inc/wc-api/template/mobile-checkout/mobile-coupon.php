<?php


defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) { // @codingStandardsIgnoreLine.
	return;
}

?>
<section class="section">
    <div class="woocommerce-form-coupon-toggle">
        <?php
            /**
             * Filter checkout coupon message.
             *
             * @param string $message coupon message.
             * @return string Filtered message.
             *
             * @since 1.0.0
             */
            wc_print_notice( apply_filters( 'woocommerce_checkout_coupon_message', esc_html__( 'Have a coupon?', 'woocommerce' ) . ' <a href="#" role="button" aria-label="' . esc_attr__( 'Enter your coupon code', 'woocommerce' ) . '" aria-controls="woocommerce-checkout-form-coupon" aria-expanded="false" class="showcoupon">' . esc_html__( 'Click here to enter your code', 'woocommerce' ) . '</a>' ), 'notice' );
        ?>
    </div>
</section>
<form class="checkout_coupon woocommerce-form-coupon coupon-form" method="post" style="display:none" id="woocommerce-checkout-form-coupon">
    <section class="section">
        <h2 class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 5H3a2 2 0 0 0-2 2v4a2 2 0 0 1 2 2 2 2 0 0 1-2 2v4a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2v-4a2 2 0 0 1-2-2 2 2 0 0 1 2-2V7a2 2 0 0 0-2-2z"></path>
                <line x1="9" y1="5" x2="9" y2="19"></line>
            </svg>
            <?php esc_html_e( 'Coupon:', 'woocommerce' ); ?>
        </h2>
        <div class="coupon-box">
            <input type="text" name="coupon_code" class="coupon-input" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" id="coupon_code" value="" />
            <button type="submit" class="coupon-btn button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php esc_html_e( 'Apply coupon', 'woocommerce' ); ?></button>
        </div>
    </section>
</form>
