<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//WC 3.5.0
if ( function_exists( 'WC' ) && version_compare( WC()->version, '3.5.0', '<' ) ) {
	wc_print_notices();
}



// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}
$woodapp_app_id_checkout = woodplus_wc_api::get_app_setting('woodapp_app_id_checkout','');
$app_logo = woodplus_wc_api::get_app_setting('app_logo_light','');
$attachment_log = wp_get_attachment_image_url($app_logo);

// filter hook for include new pages inside the payment method
$get_checkout_url = apply_filters( 'woocommerce_get_checkout_url', wc_get_checkout_url() ); ?>

<?php if( $woodapp_app_id_checkout ): ?>
    <header class="header">
        <a href="intent:#Intent;action=<?php echo esc_attr( $woodapp_app_id_checkout ); ?>;category=android.intent.category.DEFAULT;category=android.intent.category.BROWSABLE;S.msg_from_browser=orderData;package=<?php echo esc_attr( $woodapp_app_id_checkout ); ?>;end" style="width: 30%;display: flex; ">
            <svg style="transform: rotate(-180deg);" class="header-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 19l-7-7 7-7"/>
            </svg>
        </a>
        <?php if( $attachment_log ): ?>
        <div class="" style="width: 30%; text-align:center;">
            <img src="<?php echo esc_url( $attachment_log ); ?>" alt="" style="width: 50px;height: auto;">
        </div>
        <?php endif; ?>
        <div class="" style="width: 30%; text-align: left;">
            <h1><?php esc_html_e('تسویه حساب','woodmartplus'); ?></h1>
        </div>
    </header>
<?php endif; ?>

<?php do_action( 'woocommerce_before_checkout_form', $checkout ); ?>
<form name="checkout" method="post" class="checkout woocommerce-checkout checkout-form" action="<?php echo esc_url( $get_checkout_url ); ?>" enctype="multipart/form-data" aria-label="<?php echo esc_attr__( 'Checkout', 'woocommerce' ); ?>">

    <section class="section">

        <h2 class="section-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
            </svg>
            <?php esc_html_e('اطلاعات صورتحساب','woodmartplus'); ?>
        </h2>

        <?php if ( $checkout->get_checkout_fields() ) : ?>

            <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

            <div class="customer-details" id="customer_details">
                <?php do_action( 'woocommerce_checkout_billing' ); ?>
                <?php do_action( 'woocommerce_checkout_shipping' ); ?>
            </div>

            <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

        <?php endif; ?>
        
    </section>
			

    <?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

    
    <?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

    <div id="order_review" class="woocommerce-checkout-review-order">
        <?php do_action( 'woocommerce_checkout_order_review' ); ?>
    </div>

    <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

	
</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
