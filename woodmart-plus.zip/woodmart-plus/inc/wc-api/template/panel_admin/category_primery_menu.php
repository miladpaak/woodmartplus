<?php $setting_status = woodplus_wc_api::get_app_setting('main_category_status'); ?>
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن دسته بندی','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('دسته بندی در اپلیکیشن فعال باشد؟','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[main_category_status][status]'); ?>"  <?php echo isset( $setting_status['status'] ) && !empty( $setting_status['status'] ) ? 'checked' : '' ?> >
   </div>
</div>


<div class="item p-top-18 offer_section order_tracking_steps_condition">
    <span class="title"><?php esc_html_e('دسته بندی ها','woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('دسته بندی ها در زیر اسلایدر نمایش داده میشوند ، مشابه تصویر.','woodmartplus'); ?></p>
    <div data-repeater-list="<?php echo woodplus_wc_api::generate_option_app('[main_category]'); ?>" >
        <?php foreach( woodplus_wc_api::get_app_setting('main_category',[
            'defualt_category' => [
                'product_app_cat_thumbnail_id',
                'main_cat_id',
            ]
        ]) as $category ): ?>
            <section class="repeater-sections-slider-images add-suggestions m-t-18 opened" data-repeater-item >
                <div class="br-radius-8 opened">

                    <div class="suggestion-title">
                        <span class="suggestion-menu">
                            <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/menu.svg" alt="">
                            <p><?php esc_html_e('دسته بندی','woodmartplus'); ?></p>
                        </span>
                        <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
                    </div>

                    <div class="suggestion-content">

                        <div class="upload-loding">
                            <?php $img_id = isset( $category['product_app_cat_thumbnail_id'] ) && !empty( $category['product_app_cat_thumbnail_id'] ) ? $category['product_app_cat_thumbnail_id'] : '';
                                    $image = '';
                                    if( $img_id )
                                    {
                                        $img_src = wp_get_attachment_image_src($img_id,'medium');
                                        if( isset( $img_src[0] ) )
                                        {
                                            $image = $img_src[0];
                                        }
                                    }
                            
                            ?>
                            <?php if( $image ): ?>
                                <div class="upload-loding-img upload_image">
                                    <img class="img-responsive" src="<?php echo esc_url( $image ); ?>" alt="slider">
                                </div>
                                <div class="upload-loding-btns">
                                    <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش','woodmartplus') ?></span>
                                    <span class="delete-btn remove-image-button">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </span>
                                </div>
                                <input type="hidden" name="product_app_cat_thumbnail_id" id="" class="upload_image_id" value="<?php echo esc_attr( $img_id ); ?>" / >
                            <?php else: ?>
                                <div class="upload-loding-img upload_image">
                                </div>
                                <div class="upload-loding-btns">
                                    <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود','woodmartplus') ?></span>
                                    <span class="delete-btn remove-image-button" style="display: none;">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
                                    </span>
                                </div>
                                <input type="hidden" name="product_app_cat_thumbnail_id" id="" class="upload_image_id" value="" / >
                            <?php endif; ?>
                        </div>

                        <div class="suggestion-inputs">
                            <div>
                                <p><?php esc_html_e('انتخاب دسته بندی', 'woodmartplus'); ?></p>
                                <select class="js-example-basic-multiple" name="main_cat_id" dir="rtl">
                                    <?php $selected = isset( $category['main_cat_id'] ) && !empty( $category['main_cat_id'] ) ? $category['main_cat_id'] : '' ?>
                                    <?php foreach (woodapp_wc_api_get_all_woo_cat() as $key => $value): ?>
                                        <option value="<?php echo esc_attr($key) ?>" <?php echo  $key == $selected  ? 'selected' : '' ?> ><?php echo esc_html($value); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                        </div>
                    </div>

                    <div class="suggestion-btns">
                        <input class="delete-btn" data-repeater-delete type="button" value="<?php esc_html_e('حذف دسته بندی','woodmartplus') ?>" >
                    </div>
                </div>
            </section>
        <?php endforeach; ?>
    </div>
    <input class="add-btn blue-btn m-t-18" style="display:inline-block" data-repeater-create type="button" value="<?php esc_html_e('افزودن مرحله','woodmartplus') ?>" >
</div>
