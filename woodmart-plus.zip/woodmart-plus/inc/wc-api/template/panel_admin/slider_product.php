 <?php $products_carousel = woodapp_wc_api_get_products_carousel(); ?>

 <?php foreach( $products_carousel as $name_category => $product ) :  ?>
 <div class="add-suggestions slider_product open_acard opened" style="margin-top:20px;">
    <div class="suggestion-title">
        <span class="suggestion-menu">
            <p><?php echo esc_html($product['label']); ?></p>
        </span>
        <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
    </div>
    <div class="suggestion-content">
        <div class="suggestion-inputs gray-inp">

            <div class="item p-18 br-bottom">
                <span class="title"><?php esc_html_e('فعال کردن','woodmartplus'); ?></span>
                <p class="des"><?php printf(__('فعال کردن %s','woodmartplus'),$product['label']) ?></p>
                <div class="btn-select">
                    <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][status]'); ?>" <?php echo isset( $product['status'] ) && !empty( $product['status'] ) ? 'checked' : '' ?>   >
                </div>
            </div>

            <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                <label for=""><?php printf( __('عنوان %s','woodmartplus'),$product['label'] ); ?></label>
                <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][title]'); ?>" placeholder="<?php esc_html_e('عنوان', 'woodmartplus'); ?>" value="<?php echo isset( $product['title'] ) && !empty( $product['title'] ) ? esc_html($product['title']) : '' ?>">
            </div>

            <div>
                <p><?php esc_html_e('انتخاب دسته بندی', 'woodmartplus'); ?></p>
                <?php $selected = isset( $product['category'] ) && !empty( $product['category'] ) ? $product['category'] : ''; ?>
                <select class="js-example-basic-multiple choose_type_show_app_slider" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][category]'); ?>" dir="rtl">
                    <option value="" ><?php esc_html_e('انتخاب دسته بندی','woodmartplus') ?></option>
                    <?php foreach (woodapp_wc_api_get_all_woo_cat() as $key => $value): ?>
                        <option value="<?php echo esc_attr($key) ?>" <?php echo  $key == $selected  ? 'selected' : '' ?> ><?php echo esc_html($value); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="item p-18 br-bottom offer_section_condition">
                <span class="title"><?php esc_html_e('تعداد نمایش محصول','woodmartplus') ?></span>
                <p class="des"><?php esc_html_e('تعداد نمایش محصولات در اسلایدر حداکثر 10','woodmartplus'); ?></p>
                <div class="inp-rang p-top-18">
                    <input type="range" class="rang" min="1" max="10" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][perpage]'); ?>" value="<?php echo isset( $product['perpage'] ) && !empty( $product['perpage'] ) ? esc_html($product['perpage']) : '4' ?>">
                    <div class="br-radius-8 rang-number d-center">
                        <span class="num">4</span><span class="text-num"><?php esc_html_e('تعداد','woodmartplus'); ?></span>
                    </div>
                </div>
            </div>

            <div class="item p-18 br-bottom">
                <span class="title"><?php esc_html_e('محصولات ناموجود','woodmartplus'); ?></span>
                <p class="des"><?php esc_html_e('محصولات ناموجود را نمایش نده','woodmartplus') ?></p>
                <div class="btn-select">
                    <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][instock]'); ?>"  <?php echo isset( $product['instock'] ) && !empty( $product['instock'] ) ? 'checked' : '' ?> >
                </div>
            </div>

            <div class="item p-18">
            <span class="title"><?php esc_html_e('آپلود آیکون', 'woodmartplus'); ?></span>
            <p class="des"><?php printf(__('ایکون کنار %s','woodmartplus'),$product['label']); ?></p>
            <?php $icon = isset( $product['icon'] ) && !empty( $product['icon'] ) ? $product['icon'] : ''; ?>
            <div class="logo_login_register <?php echo isset($app_logo_light) && !empty($app_logo_light) ? 'upload-loding' : ''  ?>">
                <?php if (isset($icon) && !empty($icon)): ?>
                    <?php
                    $img_src = wp_get_attachment_image_src($icon);
                    ?>
                    <div class="upload-loding-img upload_image ">
                        <img src="<?php echo isset($img_src[0]) ? $img_src[0] : '' ?>" class="img-responsive" alt="logo-factor">
                    </div>
                    <div class="upload-loding-btns">
                        <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش', 'woodmartplus'); ?></span>
                        <span class="delete-btn remove-image-button">
                        <img class="img-responisve" src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
                        </span>
                        <input type="hidden" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][icon]'); ?>" class="upload_image_id" value="<?php echo $icon ?>" />
                    </div>
                <?php else: ?>

                    <div class=" upload_image">
                    </div>
                    <div class="upload-loding-btns">
                        <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود', 'woodmartplus'); ?></span>
                        <span class="delete-btn remove-image-button" style="display: none;">
                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
                        </span>
                        <input type="hidden" name="<?php echo woodplus_wc_api::generate_option_app('[products_carousel]['.$name_category.'][icon]'); ?>" class="upload_image_id" value="" />
                    </div>
                <?php endif; ?>
            </div>
            </div>

        </div>
    </div>
</div>
<?php endforeach; ?>