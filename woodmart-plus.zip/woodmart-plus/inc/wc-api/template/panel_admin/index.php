<div class="body-wrapper">

    <section class="body-main-wrapper">
        <aside class="sidbar">
            <div class="silbar-menu-wrapper">
                <div class="sidbar-menu">
                    <ul>
                        <?php $i = 0;
                        foreach ($data_tabs as $key => $data_tab):  ?>

                            <li class="<?php echo $i == 0 ? 'opened' : '' ?>">
                                <div class="sidbar-menu-item" data-id="<?php echo esc_html($key); ?>">
                                    <div class="sidbar-menu-name">
                                        <div class="menu-icon">
                                            <img src="<?php echo $data_tab['img'] ?>">
                                        </div>
                                        <p><?php echo $data_tab['output']; ?></p>
                                    </div>
                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down.svg" class="arrow_sidebar">
                                </div>
                                <?php if (isset($data_tab['submenu'])): ?>

                                    <div class="submenu">
                                        <ul>
                                            <?php foreach ($data_tab['submenu'] as $key_submenu => $sub_menu): ?>
                                                <li data-id="<?php echo $key_submenu ?>">
                                                    <span><?php echo $sub_menu['output']; ?></span>
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-square-left.svg">
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </li>

                        <?php $i++;
                        endforeach; ?>
                    </ul>
                </div>
            </div>
        </aside>

        <div class="main-wrapper">
            <form method="POST" name="woodapp-wc-api-form" id="woodapp-wc-api-form">
                
                <?php $i = 0;
                foreach ($data_tabs as $new_key => $data_tab): ?>
                    <?php
                    $style = '';
                        if( $new_key == 'custom_css' ){
                            $style = 'style="z-index: 0;"';
                        }
                    ?>
                    <?php if (file_exists(WOODAPP_API_PATH . 'template/panel_admin/' . $new_key . '.php')): ?>
                        <div class="content-wrapper <?php echo $i == 0 ? 'show-wrapper' : '' ?> " id="<?php echo $new_key ?>" <?php echo $style ?>>
                            <div class="main-content">
                                <?php include_once $new_key . '.php'  ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($data_tab['submenu'])): ?>
                        <?php foreach ($data_tab['submenu'] as $submenu_key => $submenu_value): ?>
                            <?php if (file_exists(WOODAPP_API_PATH . 'template/panel_admin/' . $submenu_key . '.php')): ?>
                                <div class="content-wrapper" id="<?php echo $submenu_key ?>">
                                    <div class="main-content">
                                        <?php include_once $submenu_key . '.php'  ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php $i++;
                endforeach; ?>

                <div class="content-header">
                    <div class="content-header-details">
                        <div><button class="chang-btn blue-btn-bg" name="submit-api"><?php esc_html_e('ذخیره تغییرات','woodmartplus') ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div>