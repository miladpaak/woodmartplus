<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('نمودار چارت قیمت','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('فعال کردن نمودار چارت قیمت','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[woodmart_chart_app]'); ?>"  <?php echo woodplus_wc_api::show_app_value('woodmart_chart_app',false) ? 'checked' : '' ?> >
   </div>
</div>

<?php if (wplus_helper::is_digits_enabled()): ?>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('ارسال پیامک در اپلیکیشن با digits','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('اگر این قسمت را فعال کنید مراحل ارسال پیامک یکبار مصرف و احراز هویت از طریق digits انجام میشود.','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[digit_check_otp]'); ?>"  <?php echo woodplus_wc_api::show_app_value('digit_check_otp',false) ? 'checked' : '' ?> >
   </div>
</div>

<?php endif; ?>