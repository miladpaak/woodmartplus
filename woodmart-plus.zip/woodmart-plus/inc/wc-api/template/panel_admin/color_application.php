<?php
   $app_assets_options = get_option('woodapp_wc_api_app_assets_options');
   $primary_color = (isset($app_assets_options['app_assets']['app_color']['primary_color'])) ? $app_assets_options['app_assets']['app_color']['primary_color'] : '';
   $secondary_color = (isset($app_assets_options['app_assets']['app_color']['secondary_color'])) ? $app_assets_options['app_assets']['app_color']['secondary_color'] : '';
?>
<p class="des"><?php esc_html_e('شما میتوانید رنگ بندی اپلیکیشن تان را با دوسبک رانگ اولیه و ثانویه مجهز نمایید', 'woodmartplus') ?></p>
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('اصلی رنگ', 'woodmartplus'); ?></span>
   <div class="chose-color">
      <div class="color-palet"><input class="color_picke" type="text" name="woodapp_app_assets[app_color][primary_color]" value="<?php echo esc_attr($primary_color) ?>"></div>
      <div class="color-icon">
         <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="brush">
      </div>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('رنگ فرعی', 'woodmartplus'); ?></span>
   <div class="chose-color">
      <div class="color-palet"><input class="color_picke" type="text" name="woodapp_app_assets[app_color][secondary_color]" value="<?php echo esc_attr( $secondary_color ); ?>"></div>
      <div class="color-icon">
         <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="brush">
      </div>
   </div>
</div>