<?php $setting_status = woodplus_wc_api::get_app_setting('main_slider_status_and_type'); ?>
<?php $style_slider = woodplus_wc_api::get_app_setting('main_slider_style_slider'); ?>
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('بنر اسلایدر','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('فعال کردن بنر اسلایدر','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[main_slider_status_and_type][status]'); ?>"  <?php echo isset( $setting_status['status'] ) && !empty( $setting_status['status'] ) ? 'checked' : '' ?> >
   </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('انتخاب حالت نمایش اسلایدر', 'woodmartplus') ?></span>
    <div>
        <select class="js-example-basic-multiple" name="<?php echo woodplus_wc_api::generate_option_app('[main_slider_style_slider]'); ?>">
            <option value="style_1" <?php echo isset( $style_slider ) && 'style_1' === $style_slider ? 'selected' : '' ?>><?php echo esc_html_e('حالت 1','woodmartplu'); ?></option>
            <option value="style_2" <?php echo isset( $style_slider ) && 'style_2' === $style_slider ? 'selected' : '' ?>><?php echo esc_html_e('حالت 2','woodmartplu'); ?></option>
            <option value="style_3" <?php echo isset( $style_slider ) && 'style_3' === $style_slider ? 'selected' : '' ?>><?php echo esc_html_e('حالت 3','woodmartplu'); ?></option>
        </select>
    </div>
</div>


<div class="item p-top-18 offer_section order_tracking_steps_condition">
    <span class="title"><?php esc_html_e('دسته بندی ها','woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('دسته بندی ها در زیر اسلایدر نمایش داده میشوند ، مشابه تصویر.','woodmartplus'); ?></p>
    <div data-repeater-list="<?php echo woodplus_wc_api::generate_option_app('[main_slider]'); ?>" >
        <?php foreach( woodplus_wc_api::get_app_setting('main_slider',[
            'defualt_slider' => [
                'upload_image_id',
                'main_slider_type',
                'slider_cat_id',
                'product_banner_selected',
            ]
        ]) as $slider ): 

        $selected_title_product_baner = (isset($slider['product_banner_selected']) && ! empty($slider['product_banner_selected'])) ? get_the_title($slider['product_banner_selected']) : '';
        ?>
            <section class="repeater-sections-slider-images app_slider_section add-suggestions m-t-18 opened" data-repeater-item >
                <div class="br-radius-8 opened">

                    <div class="suggestion-title">
                        <span class="suggestion-menu">
                            <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/menu.svg" alt="">
                            <p><?php esc_html_e('اسلاید','woodmartplus'); ?></p>
                        </span>
                        <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
                    </div>

                    <div class="suggestion-content">

                        <div class="upload-loding">
                            <?php $img_id = isset( $slider['upload_image_id'] ) && !empty( $slider['upload_image_id'] ) ? $slider['upload_image_id'] : '';
                                    $image = '';
                                    if( $img_id )
                                    {
                                        $img_src = wp_get_attachment_image_src($img_id,'medium');
                                        if( isset( $img_src[0] ) )
                                        {
                                            $image = $img_src[0];
                                        }
                                    }
                            
                            ?>
                            <?php if( $image ): ?>
                                <div class="upload-loding-img upload_image">
                                    <img class="img-responsive" src="<?php echo esc_url( $image ); ?>" alt="slider">
                                </div>
                                <div class="upload-loding-btns">
                                    <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش','woodmartplus') ?></span>
                                    <span class="delete-btn remove-image-button">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </span>
                                </div>
                                <input type="hidden" name="upload_image_id" id="" class="upload_image_id" value="<?php echo esc_attr( $img_id ); ?>" / >
                            <?php else: ?>
                                <div class="upload-loding-img upload_image">
                                </div>
                                <div class="upload-loding-btns">
                                    <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود','woodmartplus') ?></span>
                                    <span class="delete-btn remove-image-button" style="display: none;">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
                                    </span>
                                </div>
                                <input type="hidden" name="upload_image_id" id="" class="upload_image_id" value="" / >
                            <?php endif; ?>
                        </div>

                        <div class="suggestion-inputs">

                            <div>
                                <p><?php esc_html_e('نمایش محصول بر اساس', 'woodmartplus'); ?></p>
                                <select class="js-example-basic-multiple choose_type_show_app_slider" name="[main_slider_type]" dir="rtl">
                                    <option value="product" <?php echo isset( $slider['main_slider_type'] ) && $slider['main_slider_type'] === 'product' ? 'selected' : '' ?> ><?php esc_html_e('بر اساس محصول','woodmartplus') ?></option>
                                    <option value="category" <?php echo isset( $slider['main_slider_type'] ) && $slider['main_slider_type'] === 'category' ? 'selected' : '' ?> ><?php esc_html_e('بر اساس دسته بندی','woodmartplus') ?></option>
                                </select>
                            </div>

                            <div>
                                <p><?php esc_html_e('دسته بندی محصول', 'woodmartplus'); ?></p>
                                <select class="js-example-basic-multiple" name="[slider_cat_id]" dir="rtl">
                                    <?php $selected = isset( $slider['slider_cat_id'] ) && !empty( $slider['slider_cat_id'] ) ? $slider['slider_cat_id'] : '' ?>
                                    <?php foreach (woodapp_wc_api_get_all_woo_cat() as $key => $value): ?>
                                        <option value="<?php echo esc_attr($key) ?>" <?php echo  $key == $selected  ? 'selected' : '' ?> ><?php echo esc_html($value); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div id="woodapp-woo-product-baner-section" class="hide_product_type">
                                <div class="woodapp-wc-api-field-group  woodapp-woo-product-baner-section">
                                    <div class="woodapp-wc-api-form-group">
                                        <label><?php esc_html_e('انتخاب محصول', 'woodapp-api') ?></label>
                                        <select class="js-example-basic-multiple_mahsol" name="[product_banner_selected]">
                                            <option value=""><?php esc_html_e('انتخاب محصول', 'woodapp-api') ?></option>
                                            <option value="<?php echo isset($slider['product_banner_selected']) ? $slider['product_banner_selected'] : ''; ?>" selected="selected"><?php echo $selected_title_product_baner; ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="suggestion-btns">
                        <input class="delete-btn" data-repeater-delete type="button" value="<?php esc_html_e('حذف اسلاید','woodmartplus') ?>" >
                    </div>
                </div>
            </section>
        <?php endforeach; ?>
    </div>
    <input class="add-btn blue-btn m-t-18 add_product_slider" style="display:inline-block" data-repeater-create type="button" value="<?php esc_html_e('افزودن مرحله','woodmartplus') ?>" >
</div>
