<div class="item p-top-18 offer_section offer_section_condition">
   <span class="title"><?php esc_html_e('کدتخفیف','woodmartplus') ?></span>
   <p class="des"><?php esc_html_e('اطلاعات کد تخفیف را تکمیل کنید','woodmartplus'); ?></p>
   <div data-repeater-list="<?php echo woodplus_wc_api::generate_option_app('[coupon]'); ?>" >
        <?php foreach( woodplus_wc_api::get_app_setting( 'coupon',[
            'default_slider' => [
                'feature_image_id',
                'coupon_title',
                'coupon_description',
                'coupon_code'
            ]
        ] ) as $coupon ): ?>
            <?php 
                $img_id = isset( $coupon['feature_image_id'] ) && !empty( $coupon['feature_image_id'] ) ? $coupon['feature_image_id'] : false;
                $image = '';
                if( $img_id )
                {
                    $img_src = wp_get_attachment_image_src($img_id,'medium');
                    if( isset( $img_src[0] ) )
                    {
                        $image = $img_src[0];
                    }
                }
            ?>
            <section class="repeater-sections-slider-images add-suggestions m-t-18 opened" data-repeater-item >
                <div class="br-radius-8 opened">

                    <div class="suggestion-title">
                        <span class="suggestion-menu">
                            <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/menu.svg" alt="">
                            <p><?php esc_html_e('تخفیف جدید','woodmartplus'); ?></p>
                        </span>
                        <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
                    </div>

                    <div class="suggestion-content">
                        <div class="repater_upload_slider <?php echo $image ? 'upload-loding' : ''; ?>">
                            <?php if( $image ): ?>
                                <div class="upload-loding-img upload_image">
                                    <img class="img-responsive" src="<?php echo esc_url( $image ); ?>" alt="slider">
                                </div>
                                <div class="upload-loding-btns">
                                    <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش','woodmartplus') ?></span>
                                    <span class="delete-btn remove-image-button">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </span>
                                </div>
                                <input type="hidden" name="feature_image_id" id="" class="upload_image_id" value="<?php echo esc_attr( $img_id ); ?>" / >
                            <?php else: ?>
                            <div class=" upload_image">
                            </div>
                            <div class="upload-loding-btns">
                                <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود','woodmartplus') ?></span>
                                <span class="delete-btn remove-image-button" style="display: none;">
                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
                                </span>
                            </div>
                            <input type="hidden" name="feature_image_id" id="" class="upload_image_id" value="" / >
                            <?php endif; ?>
                        </div>

                        <div class="suggestion-inputs">
                            <div>
                                <input type="text" name="coupon_title" id="" placeholder="<?php esc_html_e('عنوان کد','woodmartplus'); ?>" value="<?php echo isset( $coupon['coupon_title'] ) && !empty( $coupon['coupon_title'] ) ? $coupon['coupon_title']  : '' ?>">
                            </div>
                            <div>
                                <input type="text" name="coupon_code" id="" placeholder="<?php esc_html_e('کد تخفیف','woodmartplus'); ?>" value="<?php echo isset( $coupon['coupon_code'] ) && !empty( $coupon['coupon_code'] ) ? $coupon['coupon_code']  : '' ?>">
                            </div>
                            <div>
                                <textarea name="coupon_description" placeholder="<?php esc_html_e('توضیحات','woodmartplus'); ?>" id=""><?php echo isset( $coupon['coupon_description'] ) && !empty( $coupon['coupon_description'] ) ? $coupon['coupon_description']  : '' ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="suggestion-btns">
                        <input class="delete-btn" data-repeater-delete type="button" value="<?php esc_html_e('حذف تخفیف','woodmartplus') ?>" >
                    </div>
                </div>
            </section>
        <?php endforeach; ?>
   </div>
   <input class="add-btn blue-btn m-t-18" style="display:inline-block" data-repeater-create type="button" value="<?php esc_html_e('افزودن تخفیف','woodmartplus') ?>" >
</div>