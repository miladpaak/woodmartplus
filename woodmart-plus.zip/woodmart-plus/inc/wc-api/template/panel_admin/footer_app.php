<?php $footer_items = woodapp_wc_api_get_footer_items(); ?>
<?php $footer_style = woodplus_wc_api::get_app_setting('footer_items'); ?>
<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('حالت فوتر', 'woodmartplus') ?></span>
    <div>
        <select class="js-example-basic-multiple" name="<?php echo woodplus_wc_api::generate_option_app('[footer_items][style_footer]'); ?>">
            <option value="style_1" <?php echo isset( $footer_style['style_footer'] ) && 'style_1' === $footer_style['style_footer'] ? 'selected' : '' ?>><?php echo esc_html_e('حالت 1','woodmartplu'); ?></option>
            <option value="style_2" <?php echo isset( $footer_style['style_footer'] ) && 'style_2' === $footer_style['style_footer'] ? 'selected' : '' ?>><?php echo esc_html_e('حالت 2','woodmartplu'); ?></option>
            <option value="style_3" <?php echo isset( $footer_style['style_footer'] ) && 'style_3' === $footer_style['style_footer'] ? 'selected' : '' ?>><?php echo esc_html_e('حالت 3','woodmartplu'); ?></option>
            <option value="style_4" <?php echo isset( $footer_style['style_footer'] ) && 'style_4' === $footer_style['style_footer'] ? 'selected' : '' ?>><?php echo esc_html_e('حالت 4','woodmartplu'); ?></option>
        </select>
    </div>
</div>

 <?php foreach( $footer_items as $key => $item ) :  ?>
 <div class="add-suggestions open_acard opened" style="margin-top:20px;">
    <div class="suggestion-title">
        <span class="suggestion-menu">
            <p><?php echo $item['label'] ?></p>
        </span>
        <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
    </div>
    <div class="suggestion-content">
        <div class="suggestion-inputs gray-inp">

            <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[footer_items]['.$key.'][footer_title_item]'); ?>" placeholder="<?php esc_html_e('عنوان', 'woodmartplus'); ?>" value="<?php echo isset( $item['title'] ) && !empty( $item['title'] ) ? esc_html($item['title']) : '' ?>">
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>