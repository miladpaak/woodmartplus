<?php $get_setting =  woodplus_wc_api::get_app_setting('woodapp_app_contact_info'); ?>

<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("آدرس یک", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_contact_info][address_line_1]') ?>" placeholder="" value="<?php echo isset( $get_setting['address_line_1'] ) && !empty( $get_setting['address_line_1'] ) ? esc_attr( $get_setting['address_line_1'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("آدرس دو", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_contact_info][address_line_2]') ?>" placeholder="" value="<?php echo isset( $get_setting['address_line_2'] ) && !empty( $get_setting['address_line_2'] ) ? esc_attr( $get_setting['address_line_2'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("ایمیل", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_contact_info][email]') ?>" placeholder="" value="<?php echo isset( $get_setting['email'] ) && !empty( $get_setting['email'] ) ? esc_attr( $get_setting['email'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("تلفن", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_contact_info][phone]') ?>" placeholder="" value="<?php echo isset( $get_setting['phone'] ) && !empty( $get_setting['phone'] ) ? esc_attr( $get_setting['phone'] ) : '' ?>" class="hovered">
</div>
