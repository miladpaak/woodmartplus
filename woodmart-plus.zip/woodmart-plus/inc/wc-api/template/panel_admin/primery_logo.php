<?php $app_logo_light = woodplus_wc_api::get_app_setting('app_logo_light') ?>
<div class="item p-18">
   <span class="title"><?php esc_html_e('لوگوی اصلی', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('لوگو در هدر اپلیکیشن نمایش داده میشود', 'woodmartplus'); ?></p>
   <div class="logo_login_register <?php echo isset($app_logo_light) && !empty($app_logo_light) ? 'upload-loding' : ''  ?>">
      <?php if (isset($app_logo_light) && !empty($app_logo_light)): ?>
         <?php
         $img_src = wp_get_attachment_image_src($app_logo_light);
         ?>
         <div class="upload-loding-img upload_image ">
            <img src="<?php echo isset($img_src[0]) ? $img_src[0] : '' ?>" class="img-responsive" alt="logo-factor">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button">
               <img class="img-responisve" src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo woodplus_wc_api::generate_option_app('[app_logo_light]'); ?>" class="upload_image_id" value="<?php echo $app_logo_light ?>" />
         </div>
      <?php else: ?>

         <div class=" upload_image">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button" style="display: none;">
               <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo woodplus_wc_api::generate_option_app('[app_logo_light]'); ?>" class="upload_image_id" value="" />
         </div>
      <?php endif; ?>
   </div>
</div>