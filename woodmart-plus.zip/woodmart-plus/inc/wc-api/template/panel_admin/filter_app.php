

<?php
$woodapp_wc_api_home_option = woodplus_wc_api::get_app_setting('woodapp_api_filters');
$woodapp_price_filters = (isset($woodapp_wc_api_home_option['woodapp_price'])) ? $woodapp_wc_api_home_option['woodapp_price'] : 'enable';
$woodapp_average_rating = (isset($woodapp_wc_api_home_option['woodapp_average_rating'])) ? $woodapp_wc_api_home_option['woodapp_average_rating'] : 'enable';
?>
<div class="item p-18 br-bottom">
    <label><?php esc_html_e("قیمت", 'woodapp-api') ?></label><br />
    <label><input type="radio" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_api_filters][woodapp_price]') ?>" class="woodapp-wc-api-form-control" value="enable" <?php echo ($woodapp_price_filters == "enable") ? 'checked=""' : ''; ?> /><?php esc_html_e('فعال', 'woodapp-api') ?></label>
    <label><input type="radio" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_api_filters][woodapp_price]') ?>" class="woodapp-wc-api-form-control" value="disable" <?php echo ($woodapp_price_filters == "disable") ? 'checked=""' : ''; ?> /><?php esc_html_e('غیرفعال', 'woodapp-api') ?></label>
</div>
<?php
$attribute_taxonomies = wc_get_attribute_taxonomies();
if (! empty($attribute_taxonomies)) {
    foreach ($attribute_taxonomies as $tax) {
        $attribute    = wc_sanitize_taxonomy_name($tax->attribute_name);
        $taxonomy     = wc_attribute_taxonomy_name($attribute);
        $woodapp_taxonomy_filters = (isset($woodapp_wc_api_home_option[$taxonomy])) ? $woodapp_wc_api_home_option[$taxonomy] : 'enable';
?>
        <div class="item p-18 br-bottom">
            <label><?php echo ucfirst($tax->attribute_label) ?></label><br />
            <label><input type="radio" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_api_filters]['.$taxonomy.']') ?>" class="woodapp-wc-api-form-control" value="enable" <?php echo ($woodapp_taxonomy_filters == "enable") ? 'checked=""' : ''; ?> /><?php esc_html_e('فعال', 'woodapp-api') ?></label>
            <label><input type="radio" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_api_filters]['.$taxonomy.']') ?>" class="woodapp-wc-api-form-control" value="disable" <?php echo ($woodapp_taxonomy_filters == "disable") ? 'checked=""' : ''; ?> /><?php esc_html_e('غیرفعال', 'woodapp-api') ?></label>
        </div>
<?php
    }
}
?>
<div class="item p-18 br-bottom">
    <label><?php esc_html_e("معدل امتیاز", 'woodapp-api') ?></label><br />
    <label><input type="radio" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_api_filters][woodapp_average_rating]') ?>" class="woodapp-wc-api-form-control" value="enable" <?php echo ($woodapp_average_rating == "enable") ? 'checked=""' : ''; ?> /><?php esc_html_e('فعال', 'woodapp-api') ?></label>
    <label><input type="radio" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_api_filters][woodapp_average_rating]') ?>" class="woodapp-wc-api-form-control" value="disable" <?php echo ($woodapp_average_rating == "disable") ? 'checked=""' : ''; ?> /><?php esc_html_e('غیرفعال', 'woodapp-api') ?></label>
</div>