<?php
$woodapp_app_id_checkout = woodplus_wc_api::get_app_setting('woodapp_app_id_checkout');
?>
<div class="item p-18 br-bottom">
   <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
      <label><?php esc_html_e("شناسه درگاه پرداخت", 'woodmartplus') ?></label>
      <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_id_checkout]') ?>" placeholder="" value="<?php echo isset( $woodapp_app_id_checkout ) && !empty( $woodapp_app_id_checkout ) ? esc_attr( $woodapp_app_id_checkout ) : '' ?>" class="hovered">
   </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('انتخاب برگه تسویه حساب', 'woodmartplus') ?></span>
    <div>
        <select class="js-example-basic-multiple" name="woodapp_checkout_page">
            <option value=""><?php echo esc_attr(__('Select page')); ?></option>
            <?php
            $checkout_page = '';
            $checkout_page = get_option('woodapp_checkout_page');
            $pages = get_pages();
            foreach ($pages as $page) {
                $selected = '';
                if (isset($checkout_page) && !empty($checkout_page)) {
                    if ($checkout_page == $page->ID) {
                    $selected = 'selected';
                    }
                } 
                $option = '<option value="' . $page->ID . '" ' . $selected . '>';
                $option .= $page->post_title;
                $option .= '</option>';
                echo $option;
            }
            ?>
        </select>
    </div>
</div>
