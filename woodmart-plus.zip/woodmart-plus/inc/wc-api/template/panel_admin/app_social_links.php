<?php $get_setting =  woodplus_wc_api::get_app_setting('woodapp_app_social_links'); ?>

<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("فیس بوک", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_social_links][facebook]') ?>" placeholder="" value="<?php echo isset( $get_setting['facebook'] ) && !empty( $get_setting['facebook'] ) ? esc_attr( $get_setting['facebook'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("تویتر", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_social_links][twitter]') ?>" placeholder="" value="<?php echo isset( $get_setting['twitter'] ) && !empty( $get_setting['twitter'] ) ? esc_attr( $get_setting['twitter'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("لینکدین", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_social_links][linkedin]') ?>" placeholder="" value="<?php echo isset( $get_setting['linkedin'] ) && !empty( $get_setting['linkedin'] ) ? esc_attr( $get_setting['linkedin'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("واتساپ", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_social_links][whatsapp]') ?>" placeholder="" value="<?php echo isset( $get_setting['whatsapp'] ) && !empty( $get_setting['whatsapp'] ) ? esc_attr( $get_setting['whatsapp'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("تلگرام", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_social_links][telegram]') ?>" placeholder="" value="<?php echo isset( $get_setting['telegram'] ) && !empty( $get_setting['telegram'] ) ? esc_attr( $get_setting['telegram'] ) : '' ?>" class="hovered">
</div>
<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("اینستاگرام", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[woodapp_app_social_links][instagram]') ?>" placeholder="" value="<?php echo isset( $get_setting['instagram'] ) && !empty( $get_setting['instagram'] ) ? esc_attr( $get_setting['instagram'] ) : '' ?>" class="hovered">
</div>