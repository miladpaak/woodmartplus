<?php $getDetial = woodplus_wc_api::get_app_setting('product_custom_section'); ?>
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('فعال کردن اسلایدر شگفت انگیز در اپلیکیشن','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo woodplus_wc_api::generate_option_app('[product_custom_section][status]'); ?>"  <?php echo isset( $getDetial['status'] ) && !empty( $getDetial['status'] ) ? 'checked' : '' ?> >
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('حذف کش','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('اگر تغییری در این قسمت داده اید ، برای حذف کش این گزینه را فعال کنید','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="checkbox" name="<?php echo woodplus_wc_api::generate_option_app('[amazing_product_cach][cach]'); ?>" >
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('تاریخ شروع شگفت انگیز','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('برای نمایش تاریخ در اپلیکیشن یک تاریخ انتخاب کنید','woodmartplus') ?></p>
   <div class="btn-select">
      <input type="text" id="custom_section_date_picker_2" name="<?php echo woodplus_wc_api::generate_option_app('[product_custom_section][date]'); ?>"  value="<?php echo isset( $getDetial['date'] ) && !empty( $getDetial['date'] ) ? esc_attr( $getDetial['date'] ) : '' ?>"  >
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('رنگ پس زمینه اسلایدر شگفت انگیز', 'woodmartplus'); ?></span>
   <div class="chose-color">
      <div class="color-palet"><input class="color_picke" type="text" name="<?php echo woodplus_wc_api::generate_option_app('[product_custom_section][color]') ?>" value="<?php echo isset( $getDetial['color'] ) && !empty( $getDetial['color'] ) ? esc_attr( $getDetial['color'] ) : '' ?>"></div>
      <div class="color-icon">
         <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="brush">
      </div>
   </div>
</div>

<div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
    <label><?php esc_html_e("عنوان", 'woodapp-api') ?></label>
    <input type="text" name="<?php echo woodplus_wc_api::generate_option_app('[product_custom_section][title]') ?>" placeholder="" value="<?php echo isset( $getDetial['title'] ) && !empty( $getDetial['title'] ) ? esc_attr( $getDetial['title'] ) : '' ?>" class="hovered">
</div>

<?php $logo_product_amazing = isset( $getDetial['image_id_product_custom_section'] ) && !empty( $getDetial['image_id_product_custom_section'] ) ? $getDetial['image_id_product_custom_section'] : ''; ?>
<div class="item p-18">
   <span class="title"><?php esc_html_e('تصویر', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('آپلود تصویر شگفت انگیز', 'woodmartplus'); ?></p>
   <div class="logo_login_register <?php echo isset($logo_product_amazing) && !empty($logo_product_amazing) ? 'upload-loding' : ''  ?>">
      <?php if (isset($logo_product_amazing) && !empty($logo_product_amazing)): ?>
         <?php
         $img_src = wp_get_attachment_image_src($logo_product_amazing);
         ?>
         <div class="upload-loding-img upload_image ">
            <img src="<?php echo isset($img_src[0]) ? $img_src[0] : '' ?>" class="img-responsive" alt="logo-factor">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button">
               <img class="img-responisve" src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo woodplus_wc_api::generate_option_app('[product_custom_section][image_id_product_custom_section]'); ?>" class="upload_image_id" value="<?php echo $logo_product_amazing ?>" />
         </div>
      <?php else: ?>

         <div class=" upload_image">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button" style="display: none;">
               <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo woodplus_wc_api::generate_option_app('[product_custom_section][image_id_product_custom_section]'); ?>" class="upload_image_id" value="" />
         </div>
      <?php endif; ?>
   </div>
</div>


<div class="item p-top-18 offer_section order_tracking_steps_condition">
    <span class="title"><?php esc_html_e('محصولات','woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('یک یا بیش از یک محصول برای نمایش در قسمت شگفت انگیز انتخاب کنید','woodmartplus'); ?></p>
    <div data-repeater-list="<?php echo woodplus_wc_api::generate_option_app('[custom_section]'); ?>" >
        <?php foreach( woodplus_wc_api::get_app_setting('custom_section',[
            'defualt_slider' => [
                'product_banners_cat_id',
            ]
        ]) as $custom_section ): 

        $title_product = (isset($custom_section['product_banners_cat_id']) && ! empty($custom_section['product_banners_cat_id'])) ? get_the_title($custom_section['product_banners_cat_id']) : '';
        ?>
            <section class="repeater-sections-slider-images app_slider_section add-suggestions m-t-18 opened" data-repeater-item >
                <div class="br-radius-8 opened">

                    <div class="suggestion-content">
                        <div class="suggestion-inputs">
                            <div id="woodapp-woo-product-baner-section" class="hide_product_type">
                                <div class="woodapp-wc-api-field-group  woodapp-woo-product-baner-section">
                                    <div class="woodapp-wc-api-form-group">
                                        <label><?php esc_html_e('انتخاب محصول', 'woodapp-api') ?></label>
                                        <select class="js-example-basic-multiple_mahsol" name="product_banners_cat_id">
                                            <option value=""><?php esc_html_e('انتخاب محصول', 'woodapp-api') ?></option>
                                            <option value="<?php echo isset($custom_section['product_banners_cat_id']) ? $custom_section['product_banners_cat_id'] : ''; ?>" selected="selected"><?php echo $title_product; ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="suggestion-btns">
                        <input class="delete-btn" data-repeater-delete type="button" value="<?php esc_html_e('حذف محصول','woodmartplus') ?>" >
                    </div>
                </div>
            </section>
        <?php endforeach; ?>
    </div>
    <input class="add-btn blue-btn m-t-18 add_product_slider" style="display:inline-block" data-repeater-create type="button" value="<?php esc_html_e('افزودن محصول','woodmartplus') ?>" >
</div>