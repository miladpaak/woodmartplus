<?php

// $input   = file_get_contents("php://input");
// $request = json_decode($input,true);
$request = [];
$request['user_id'] = isset( $_GET['user_id'] ) ? $_GET['user_id'] : '';
$request['os'] = 'android';
global $woocommerce;
            

if (isset($request['os']) && $request['os'] == 'android') {

    if (isset($request['user_id']) && ! empty($request['user_id'])) {
        $user_id         = $request['user_id'];
        $current_user_id = null;
        if(is_user_logged_in()) {
            $current_user_id = get_current_user_id();
        }
        
        if ($current_user_id != $user_id) {
            //wp_destroy_current_session();
            //wp_clear_auth_cookie();
            $user = get_user_by('id', $user_id);
            if ($user) {
                $user_set = wp_set_current_user($user_id, $user->data->user_login);
                 wp_set_auth_cookie($user_id);
				
                $current_user_id = $user_id;
                @do_action( 'wp_login', $user->data->user_login, 10) ;

				if( $user_set  )
				{
					?>
					<script>
						location.reload();
					</script>
					<?php
				}
				
            }
        } 
		

		$user_meta = get_user_meta($current_user_id, '_woocommerce_persistent_cart_1', true);
		
		if( $user_meta )
		{
			$woocommerce->cart->empty_cart();

			foreach($user_meta['cart'] as $cart_item) {

				
				if( $cart_item['variation_id'] )
				{
					$woocommerce->cart->add_to_cart($cart_item['product_id'], $cart_item['quantity'], $cart_item['variation_id'], isset( $cart_item['variation'] ) ? $cart_item['variation'] : []);

				}else{
					$woocommerce->cart->add_to_cart($cart_item['product_id'], $cart_item['quantity']);
				}
			}
		}
    }
}


woodapp_wc_api_remove_admin_bar();?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> style="margin-top:0px !important;">
<head>
<meta charset="<?php echo esc_attr(get_bloginfo( 'charset' )); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no" />
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php echo esc_url(get_bloginfo( 'pingback_url' )); ?>">
<?php $app_color = woodapp_wc_api_get_app_color();?>
<style>
	:root{
		--app-color-check : <?php echo esc_attr($app_color['primary_color'])?>;
	}
.woodapp-wc-api-app-checkout { background-color:#fff; }
.woodapp-wc-api-app-checkout .woocommerce .woocommerce-checkout-review-order-table .order-total td { color: <?php echo esc_attr($app_color['primary_color'])?> !important; }
.woodapp-wc-api-app-checkout .woocommerce button, input[type="button"], input[type="submit"]{ background-color: var(--app-color-check,#dc2626) !important; }
.woodapp-wc-api-app-checkout .woocommerce .input-text:focus { border-width: 2px; border-color: <?php echo esc_attr($app_color['primary_color'])?> !important; }
/*.woodapp-wc-api-app-checkout .select2-container--default.select2-container--open li:hover{ background-color: <?php //echo esc_attr($app_color['primary_color'])?> !important; }
.woodapp-wc-api-app-checkout .select2-container--default.select2-container--open .select2-results__option--highlighted{ background-color: <?php //echo esc_attr($app_color['primary_color'])?> !important; }*/
.woodapp-wc-api-app-checkout .woocs_auto_switcher{ display: none;}
.wpml-ls-statics-footer{ display: none;}

.woodapp-wc-api-app-checkout .woocommerce .woocommerce-checkout-review-order-table .order-total td .woocommerce-Price-amount bdi  {
	color: <?php echo esc_attr($app_color['secondary_color'])?> !important;
}
.woodapp-wc-api-app-checkout .select2-container--default .select2-results__option[data-selected=true], .woodapp-wc-api-app-checkout .select2-container--default.select2-container--open .select2-results__option--highlighted, .woodapp-wc-api-app-checkout .select2-container--default.select2-container--open li:hover, .select2-container--default.select2-container--open li:focus, .woodapp-wc-api-app-checkout .select2-container--default.select2-container--open li:active {
	background-color: <?php echo esc_attr($app_color['secondary_color'])?> !important;
	color: <?php echo esc_attr($app_color['primary_color'])?> !important;
}

.container {
	max-width: 480px;
	margin: 0 auto;
	background-color: #fff;
	min-height: 100vh;
}
.btn-prefactor{
	background: var(--app-color-check,#dc2626) !important;
}
.tabbar_container--2 .tabbar_container__buttons .tabbar_container__button.show,
.tabbar_container--2 .tabbar_container__buttons .tabbar_container__button.show p.desc,
.tabbar_container--2 .tabbar_container__buttons .tabbar_container__button.show
 {
     color: var(--app-color-check,#dc2626) !important;
}
.tabbar_container--2 .tabbar_container__buttons .tabbar_container__button.show::after
{
	background: var(--app-color-check,#dc2626) !important;
}

/* Header */
.header {
	background-color: var(--app-color-check,#dc2626);
	color: #fff;
	padding: 16px 20px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	position: sticky;
	top: 0;
	z-index: 999;
	transition: border-radius 0.3s ease;
}

.header.scrolled {
	border-radius: 0 !important;
}
.header-icon{
	color: white;
}
.header h1 {
	font-size: 18px;
	font-weight: 600;
	margin: 0;
	color: white;
}
:root :is(.woocommerce-form-coupon-toggle,.woocommerce-form-login-toggle)>div :is(.showlogin,.woocommerce-info .showcoupon){
	color: var(--app-color-check) !important;
}
.header-icon {
	width: 24px;
	height: 24px;
	cursor: pointer;
}

/* Section */
.section {
	padding: 20px;
	border-bottom: 8px solid #f5f5f5;
}

.section-title {
	font-size: 16px;
	font-weight: 600;
	margin-bottom: 16px;
	display: flex;
	align-items: center;
	gap: 8px;
	color: #333;
}

.section-title svg {
	width: 20px;
	height: 20px;
	color: var(--app-color-check,#dc2626);
}

/* Form Styles */
.form-group {
	margin-bottom: 16px;
}

.form-label {
	display: block;
	font-size: 14px;
	color: #555;
	margin-bottom: 8px;
}

.form-label .required {
	color: var(--app-color-check,#dc2626);
}

.form-input {
	width: 100% !important;
	padding: 14px 16px !important;
	border: 1px solid #ddd !important;
	border-radius: 8px !important;
	font-size: 14px !important;
	direction: rtl !important;
	text-align: right !important;
	transition: border-color 0.2s !important;
}

.form-input:focus {
	outline: none;
	border-color: var(--app-color-check,#dc2626);
}

.form-input::placeholder {
	color: #aaa;
}

.form-row-app-checkout {
	display: flex;
	gap: 12px;
}

.form-row-app-checkout .form-group {
	flex: 1;
}

/* Order Summary */
.order-item {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 12px 0;
	border-bottom: 1px solid #eee;
}

.order-item:last-child {
	border-bottom: none;
}

.item-info {
	display: flex;
	align-items: center;
	gap: 12px;
}

.item-image {
	width: 50px;
	height: 50px;
	background-color: #f5f5f5;
	border-radius: 8px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.item-image svg {
	width: 24px;
	height: 24px;
	color: #999;
}

.item-details h4 {
	font-size: 14px;
	font-weight: 500;
	margin-bottom: 4px;
}

.item-details span {
	font-size: 12px;
	color: #888;
}

.item-price {
	font-size: 14px;
	font-weight: 600;
	color: var(--app-color-check,#dc2626);
}

/* Price Summary */
.price-row {
	display: flex;
	justify-content: space-between;
	padding: 10px 0;
	font-size: 14px;
}

.price-row.total {
	border-top: 2px solid #eee;
	margin-top: 8px;
	padding-top: 16px;
	font-size: 16px;
	font-weight: 700;
}

.price-row.total .price-value {
	color: var(--app-color-check,#dc2626);
}

.discount {
	color: #16a34a;
}

/* Payment Methods */
.payment-methods {
	display: flex;
	flex-direction: column;
	gap: 12px;
}

.payment-option {
	display: flex;
	align-items: center;
	gap: 12px;
	padding: 16px;
	border: 2px solid #eee;
	border-radius: 10px;
	cursor: pointer;
	transition: all 0.2s;
}

.payment-option:hover {
	border-color: var(--app-color-check,#dc2626);
}

.payment-option.selected {
	border-color: var(--app-color-check,#dc2626);
}

.payment-radio {
	width: 20px;
	height: 20px;
	border: 2px solid #ddd;
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 9px;
}

.payment-option.selected .payment-radio {
	border-color: var(--app-color-check,#dc2626);
	padding: 4px;
}

.payment-option.selected .payment-radio::after {
	content: '';
	width: 10px;
	height: 10px;
	background-color: var(--app-color-check,#dc2626);
	border-radius: 50%;
}

.payment-icon {
	width: 40px;
	height: 40px;
	background-color: #f5f5f5;
	border-radius: 8px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.payment-icon svg {
	width: 24px;
	height: 24px;
	color: var(--app-color-check,#dc2626);
}

.payment-info h4 {
	font-size: 14px;
	font-weight: 600;
	margin-bottom: 2px;
}

.payment-info span {
	font-size: 12px;
	color: #888;
}

/* Coupon */
.coupon-box {
	display: flex;
	gap: 10px;
}

.coupon-input {
	flex: 1;
	padding: 12px 16px;
	border: 1px solid #ddd;
	border-radius: 8px;
	font-size: 14px;
	direction: rtl;
}

.coupon-input:focus {
	outline: none;
	border-color: var(--app-color-check,#dc2626);
}

.coupon-btn {
	padding: 12px 20px;
	background-color: #fff;
	color: var(--app-color-check,#dc2626);
	border: 2px solid var(--app-color-check,#dc2626);
	border-radius: 8px;
	font-size: 14px;
	font-weight: 600;
	cursor: pointer;
	transition: all 0.2s;
}

.coupon-btn:hover {
	background-color: var(--app-color-check,#dc2626);
	color: #fff;
}

/* Submit Button */
.submit-section {
	padding: 20px;
	background-color: #fff;
	position: sticky;
	bottom: 0;
	box-shadow: 0 -4px 12px rgba(0,0,0,0.08);
}

.submit-btn {
	width: 100%;
	padding: 16px;
	background-color: var(--app-color-check,#dc2626);
	color: #fff;
	border: none;
	border-radius: 10px;
	font-size: 16px;
	font-weight: 600;
	cursor: pointer;
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 10px;
	transition: background-color 0.2s;
}

.submit-btn:hover {
	background-color: #b91c1c;
}

.submit-btn svg {
	width: 20px;
	height: 20px;
}

/* Security Badge */
.security-badge {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 6px;
	margin-top: 12px;
	font-size: 12px;
	color: #888;
}

.security-badge svg {
	width: 14px;
	height: 14px;
	color: #16a34a;
}

/* Responsive */
@media (min-width: 481px) {
	body {
		background-color: #e5e5e5;
		padding: 20px 0;
	}

	.container {
		border-radius: 16px;
		box-shadow: 0 4px 20px rgba(0,0,0,0.1);
		min-height: auto;
		margin: 20px auto;
	}

	.header {
		border-radius: 16px 16px 0 0;
	}
}

/* Textarea */
.form-textarea {
	width: 100%;
	padding: 14px 16px;
	border: 1px solid #ddd;
	border-radius: 8px;
	font-size: 14px;
	direction: rtl;
	text-align: right;
	resize: vertical;
	min-height: 80px;
	font-family: inherit;
}

.form-textarea:focus {
	outline: none;
	border-color: var(--app-color-check,#dc2626);
}
.woocommerce-form-coupon, .woocommerce-form-login.hidden-form {
	margin-bottom: unset !important;
	padding: unset !important;
	max-width: unset !important;
	border: unset !important;
	border-radius: unset !important;
	text-align: unset !important;
}
:is(.woocommerce-error,.woocommerce-message,.woocommerce-info){
	margin-bottom:0px !important ;
}
.wd-toolbar,div#chatBotToggle {
	display: none !important;
}
#order_review,#payment{
	padding: 20px;
	border-bottom: 8px solid #f5f5f5;
}
.shop_table tr :is(td,th):last-child{
	text-align: left !important;
}
button[name="woocommerce_checkout_place_order"]{
	position: fixed;
    bottom: 0;
    right: 0;
    border-radius: 0 !important;
	z-index: 999;
}
<?php
$is_woodapp_multisteps = is_woodapp_multisteps_checkout_active();
if( $is_woodapp_multisteps ){
    woodapp_wc_api_MultiSteps_Checkout::woodapp_wc_api_wcmc_inline_checkout_style($app_color);
}?>
</style>
<?php wp_head(); ?>
</head>

<body <?php body_class('woodapp-wc-api-app-checkout');?>>
<?php

remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
add_filter( 'woocommerce_checkout_registration_enabled', function( $data ) { return $data = 0; });

// Product thumbnail in checkout
if ( !$woocommerce->cart->is_empty() ) {
	do_action( 'woodapp_wc_api_preloader' );
}
/**
 * Hook: woodapp_wc_api_app_checkout_before_main_content.
 */
do_action( 'woodapp_wc_api_app_checkout_before_main_content' );
	/**
	* Hook: woodapp_wc_api_app_checkout_content_wrapper_start.
	* @hooked woodapp_wc_api_app_checkout_output_content_wrapper_start - 10
	*/
	// do_action( 'woodapp_wc_api_app_checkout_content_wrapper_start' );

		/**
		 * Hook: woodapp_wc_api_app_checkout_.
		 */
		do_action( 'woodapp_wc_api_app_checkout_before_content_loop' );

		if ( have_posts() ) :
			if( !$woocommerce->cart->is_empty()){

				while ( have_posts() ) : the_post();
					the_content();
				endwhile; // End of the loop.
			}else{
				esc_html_e( 'سبد خرید شما خالی است', 'woodapp-api' );
			}
		endif;

		/**
		 * Hook: woodapp_wc_api_app_checkout_after_content_loop.
		 */
		do_action( 'woodapp_wc_api_app_checkout_after_content_loop' );

	/**
	* Hook: woodapp_wc_api_app_checkout_content_wrapper_end.
	* @hooked woodapp_wc_api_app_checkout_output_content_wrapper_end - 10
	*/
	// do_action( 'woodapp_wc_api_app_checkout_content_wrapper_end' );

/**
 * Hook: woodapp_wc_api_app_checkout_after_main_content.
 */
do_action( 'woodapp_wc_api_app_checkout_after_main_content' );

// header('Location: '.$_SERVER['REQUEST_URI']);
wp_footer();
?>
<script>
	jQuery(document).ready(function($) {
		
		$('body').on('change','input[name="payment_method"]', function() {
			$('.payment-option').removeClass('selected');
			$(this).closest('.payment-option').addClass('selected');
		});

		// Header scroll effect
		$(window).on('scroll', function() {
			if ($(this).scrollTop() > 10) {
				$('.header').addClass('scrolled');
			} else {
				$('.header').removeClass('scrolled');
			}
		});
	});
    </script>
</body>
</html>
