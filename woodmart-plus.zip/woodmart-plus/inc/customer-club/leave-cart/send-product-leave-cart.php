<?php

if( !defined( 'ABSPATH' ) ) exit;

class send_notification_product_leave_cart {

    private $keyLog = 'leave_cart_sms';
    private $phone = PHONEMETA;
    private $email;
    private $save_log = [];
    private $phone_meta;

    public function __construct() {
        
        add_action('woocommerce_add_to_cart', [$this, 'update_cart_item'], 999);
        add_action('woocommerce_cart_emptied', [$this, 'remove_leave_cart_created'], 999);
        
        add_action('woocommerce_payment_complete', [$this, 'remove_leave_cart_created_after_payment'], 10);

        add_action('connect_hook_send_notif_product_leave_cart1', [$this, 'leave_cart_notif']);

        add_action('wp_loaded', function () {
            if (!wp_next_scheduled('connect_hook_send_notif_product_leave_cart1')) {
                wp_schedule_event(time(), 'every_hour', 'connect_hook_send_notif_product_leave_cart1');
            }
        }, 99);

        add_filter('cron_schedules', [$this, 'cron_schedules_change_time_leave_cart'], 1);
    }

    public function remove_leave_cart_created_after_payment($order_id){
        $user_id = get_current_user_id();
        
        if (!$user_id) return;

        delete_user_meta($user_id, '_leave_cart_created');
        delete_user_meta($user_id, '_leave_cart_notif_sent');
        delete_user_meta($user_id, 'leave_cart_sms'); //log
    }
    
    public function update_cart_item(){

        $user_id = get_current_user_id();
        if (!$user_id) return;

        $old_timestamp = get_user_meta($user_id, '_leave_cart_created', true);
        if (!$old_timestamp || (time() - (int) $old_timestamp) > 30 * 60) {
            update_user_meta($user_id, '_leave_cart_created', time());
        }
    }

    public function remove_leave_cart_created(){

        $user_id = get_current_user_id();

        if (!$user_id) return;

        delete_user_meta($user_id, '_leave_cart_created');
        delete_user_meta($user_id, '_leave_cart_notif_sent');
        delete_user_meta($user_id, 'leave_cart_sms');
    }

    public function cron_schedules_change_time_leave_cart($schedules) {
        $schedules['every_hour'] = array(
            'interval' => HOUR_IN_SECONDS, 
            'display'  => __('هر یک ساعت', PTEXT_DOMAIN)
        );
        return $schedules;
    }

    public function leave_cart_notif() {
        $this->send_notification();
    }

    private function send_notification() {
        
        $bigger = $this->get_cart();
        
        foreach( $bigger as $key => $value ) {

            if( !isset($value['phone']) || empty($value['phone']) ) {
                continue;
            }
            
            $this->phone = $value['phone'];

            $highest_price_product_id[] = $value['product_id'];

            $leave_cart_message_time = get_post_meta($value['product_id'], '_leave_cart_message_time', true);

            if( $leave_cart_message_time )
            {
                $leave_cart_message_time = $leave_cart_message_time * 3600;

                if( $value['date_cart_created'] <= time() + $leave_cart_message_time ) {
                    
                    $highest_price_product_id[] = $value['product_id'];

                    $leave_cart_message_how_to_send = get_post_meta($value['product_id'], '_leave_cart_message_how_to_send', true);

                    $message = get_post_meta($value['product_id'], '_leave_cart_message', true);

                    $response = $this->check_how_to_send_notif($leave_cart_message_how_to_send, $message, $value['user_id']);
                    
                    $this->add_log($response, $value['user_id'], $value['product_id'],$message);
                }
            }
        }

    }

    private function check_how_to_send_notif($how_send, $message, $user_id)
    {

        switch ($how_send) {
            case 'just_sms':
                return [
                    'sms_send' => $this->send_message_with_sms($message),
                ];
                break;
            case 'just_email':
                return [
                    'email_send' => $this->send_message_with_email($user_id , $message),
                ];
                break;
            case 'together':
                return [
                    'sms_send' => $this->send_message_with_sms($message),
                    'email_send' => $this->send_message_with_email($user_id , $message),
                ];
            break;
        }
    }

    private function send_message_with_sms($message)
    {
        
        $object = new woodplus_sms_send_to_order($message,$this->phone,false);
        $response = $object->send();
        return $response;
    }

    private function send_message_with_email($user_id , $message)
    {
        $user = get_user_by('id', $user_id);
        $email = $user->user_email;
        if( !$email ) {
            return new WP_Error('email-error', __('ایمیلی برای این کاربر ثبت نشده است', PTEXT_DOMAIN));
        }
        $this->email = $email;
        $from = $this->get_from_email();
        $headers = "From: $from";
        $sobject = __('پیامک سبد خرید رها شده', PTEXT_DOMAIN);
        $result = $this->confirm_email($email, $sobject, $message, $headers);

        if( !$result ) {
            return new WP_Error('email-error', __('در روند ارسال ایمیل برای این سفارش مشکلی پیش آمده ، مطمئن شوید ایمیل smtp به درستی ست شده است', PTEXT_DOMAIN));
        }

        return true;
    }

    private function get_from_email()
    {
        $email = get_option('admin_email');

        $email = wplus_helper::get_setting('email_send_from', $email);

        if ($email) {
            return $email;
        }
        return false;
    }

    protected function confirm_email($email, $subject, $message, $headers)
    {
        return wp_mail($email, $subject, $message, $headers);
    }

    private function add_log($response, $user_id, $product_id,$message)
    {
        $this->save_log['product_id'] = $product_id;

        if( array_key_exists('sms_send', $response) )
        {
            if( is_wp_error($response['sms_send']) ) {
                $this->save_log['sms'] = [
                    'status' => 'faild',
                    'text_log' => $response['sms_send']->get_error_message(),
                    'type' => 'sms',
                    'recipient' => $this->phone,
                    'date' => date('Y-m-d H:i:s'),
                    'message_content' => $message
                ];
            }else{
                $this->save_log['sms'] = [
                    'status' => 'success',
                    'text_log' => __('اس ام اس با موفقیت ارسال شد', PTEXT_DOMAIN),
                    'type' => 'sms',
                    'recipient' => $this->phone,
                    'date' => date('Y-m-d H:i:s'),
                    'message_content' => $message
                ];
            }
        }

        if( array_key_exists('email_send', $response) )
        {
            if( is_wp_error($response['email_send']) ) {
                $this->save_log['email'] = [
                    'status' => 'faild',
                    'text_log' => $response['email_send']->get_error_message(),
                    'type' => 'email',
                    'recipient' => $this->email,
                    'date' => date('Y-m-d H:i:s'),
                    'message_content' => $message
                ];
            }else{
                $this->save_log['email'] = [
                    'status' => 'success',
                    'text_log' => __('ایمیل با موفقیت ارسال شد', PTEXT_DOMAIN),
                    'type' => 'email',
                    'recipient' => $this->email,
                    'date' => date('Y-m-d H:i:s'),
                    'message_content' => $message
                ];
            }
        }
        
        $all_log = get_user_meta( $user_id , $this->keyLog, true );

        if( $all_log ) {
            $all_log[] = $this->save_log;
        }else{
            $all_log = [$this->save_log];
        }

        update_user_meta($user_id, '_leave_cart_notif_sent', time());
        update_user_meta($user_id, $this->keyLog, $all_log);

        $this->save_log = [];
    }

    private function get_cart()
    {
        global $wpdb;

        $query = "SELECT phone.meta_value AS phone, wc_cart.meta_value AS wc_cart, leave_cart_created.meta_value AS leave_cart_created, {$wpdb->prefix}users.ID AS user_id
            FROM {$wpdb->prefix}users 
            JOIN {$wpdb->prefix}usermeta AS phone ON {$wpdb->prefix}users.ID = phone.user_id AND phone.meta_key = %s
            JOIN {$wpdb->prefix}usermeta AS wc_cart ON {$wpdb->prefix}users.ID = wc_cart.user_id AND wc_cart.meta_key = %s
            LEFT JOIN {$wpdb->prefix}usermeta AS leave_cart_notif_sent ON {$wpdb->prefix}users.ID = leave_cart_notif_sent.user_id AND leave_cart_notif_sent.meta_key = %s
            JOIN {$wpdb->prefix}usermeta AS leave_cart_created ON {$wpdb->prefix}users.ID = leave_cart_created.user_id AND leave_cart_created.meta_key = %s
            WHERE (leave_cart_notif_sent.meta_value IS NULL OR leave_cart_notif_sent.user_id IS NULL) 
            AND leave_cart_created.meta_value != ''
            LIMIT %d";

        $params = [ PHONEMETA, '_woocommerce_persistent_cart_1', '_leave_cart_notif_sent', '_leave_cart_created', 50];

        $results = $wpdb->get_results($wpdb->prepare($query, ...$params), ARRAY_A);
        
        $bigger = [];

        foreach( $results as $key =>  $result ) {

            $cart = maybe_unserialize($result['wc_cart']);

            if( isset($cart['cart']) && !empty($cart['cart']) ) {
                
                $cart_items = maybe_unserialize($cart['cart']);
                
                foreach( $cart_items as $cart_item ) {
                    
                    $include_leave_cart_option = get_post_meta($cart_item['product_id'], '_include_leave_cart_option', true);

                    if( $include_leave_cart_option != 'yes' )
                    {
                        continue;
                    }

                    if( isset( $cart_item['variation_id'] ) && !empty( $cart_item['variation_id'] ) && $cart_item['variation_id'] != 0 )
                    {
                        $product = new WC_Product_Variation( $cart_item['variation_id'] );
                    }else{
                        $product = wc_get_product($cart_item['product_id']);
                    }

                    if( !$product ) {
                        continue;
                    }

                    if (!isset($bigger[$key]) || !is_array($bigger[$key])) {
                        $bigger[$key] = ['max_price' => 0, 'product_id' => 0 ];
                    }

                    if ($product->get_price() > $bigger[$key]['max_price']) {
                        $bigger[$key]['max_price'] = $product->get_price();
                        $bigger[$key]['product_id'] = $cart_item['product_id'];
                        $bigger[$key]['user_id'] = $result['user_id'];
                        $bigger[$key]['date_cart_created'] = $result['leave_cart_created'];
                        $bigger[$key]['phone'] = $result['phone'];
                    }
                }
            }
        }

        return $bigger;
    }
        
}
