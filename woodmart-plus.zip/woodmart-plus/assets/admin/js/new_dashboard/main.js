(function($){


$(document).ready(function(){
    
    $('.import-btn-account').on('click', function() {
        var designId = $(this).data('design');
        var fname = $(this).data('fname');
        var sliderImage = $(this).data('slider_image').split(',');
        var designTitle = $(this).closest('.design-item').find('.design-title').text();
        
        
        $('.import-status').show();
        $('.progress-bar').css('width', '0%');
        $('.import-message').text('در حال آماده‌سازی برای درون‌ریزی ' + designTitle + '...');

        var progress = 0;

        var interval = setInterval(function() {
           progress += 10;
           $('.progress-bar').css('width', progress + '%');

           if (progress < 30) {
              $('.import-message').text('در حال دانلود فایل‌ها...');
           } else if (progress < 60) {
              $('.import-message').text('در حال پردازش فایل‌ها...');
           } else if (progress < 90) {
              $('.import-message').text('در حال درون‌ریزی...');
           }
        }, 100);

        $.ajax({
            url : ajaxurl, dataType:'json', type:'POST',
            data : {
                'action': "import_myaccount",
                'import' : designId,
                'fname' : fname,
                'slider_image' : sliderImage
            },
            success:function(response){

                clearInterval(interval);
                $('.progress-bar').css('width', '100%');
                $('.import-message').text('درون‌ریزی با موفقیت انجام شد!');
                setTimeout(function() {
                    $('.import-status').fadeOut();
                }, 2000);

                $('.show_dashboard_builder').show();
            },
            error : function(error){
                clearInterval(interval);
                $('.progress-bar').css('width', '100%');
                $('.import-message').text(error.responseJSON.msg);
                $('.progress-bar').css('background-color', 'red');
                setTimeout(function() {
                    $('.import-status').fadeOut();
                    $('.progress-bar').css('background-color', 'green');
                }, 2000);
            }
        });

        
     });
    
});

$(document).ready(function () {
    $('.sidbar-menu ul li ').on('click', function () {
        if ($(this).hasClass('opened')) {
            // $(this).removeClass('opened');
        } else {
            $('.sidbar-menu ul li ').removeClass('opened');
            $(this).addClass('opened');
        }
    });
});


$(document).ready(function () {
    $('.submenu ul li').click(function () {
        $('.submenu ul li img , .submenu ul li ').removeClass('select');
        $(this).find('img').addClass('select');
        $(this).addClass('select');
        $('.sidbar-menu ul li ').removeClass('opened')
    });
});

$(document).ready(function () {
    $('.submenu ul li, .sidbar-menu-item').click(function () {
        
        var $this = $(this);
        var id_li = $(this).data('id');
        var main_wrapper    = $this.parents('.body-main-wrapper');
        var conntet_wrapper = main_wrapper.find('#'+id_li);
       
        if ($('.content-wrapper').hasClass('show-wrapper')) {
            $('.content-wrapper').removeClass('show-wrapper');
            // $('.sidbar-menu ul li ').removeClass('opened')
        }

        if( conntet_wrapper.length )
        {
            conntet_wrapper.addClass('show-wrapper');
            localStorage.setItem("lastLiSelected", id_li);
        }else{

            if( $this.siblings('.submenu').length )
            {
                var $submenu = $this.siblings('.submenu');
                $first_li = $submenu.find('ul li:first-child');

                var nextid = $first_li.data('id');
                
                if(  main_wrapper.find('#'+nextid).length )
                {
                    main_wrapper.find('#'+nextid).addClass('show-wrapper');

                    $first_li.addClass('select');

                    $first_li.find('img').addClass('select');
                    $('.sidbar-menu ul li ').removeClass('opened')
                }
               localStorage.setItem("lastLiSelected", nextid);
            }
        }
    });
});
$(document).ready(function(e){
    var $li_id = localStorage.getItem('lastLiSelected');
    
    if( $li_id )
    {
        if( $('li[data-id="'+$li_id+'"]').length ){
            $('li[data-id="'+$li_id+'"]').click();
        }
        if( $('div[data-id="'+$li_id+'"]').length )
        {
            $('div[data-id="'+$li_id+'"]').click();
        }
    }else{
        $('.sidbar-menu-item').first().trigger('click');
    }
})
// button
$('input[type=checkbox].switch').each(function () {
    $(this).on('change', function () {
        if ($(this).is(':checked')) {

            $(this).removeClass('unchecked-animate');
            $('.product-report-content ').stop(true, true).slideDown(200); // انیمیشن slideDown
        } else {

            $(this).addClass('unchecked-animate');
            $('.product-report-content ').stop(true, true).slideUp(200); // انیمیشن slideUp
        }
    });
});

// dropdown
$(document).ready(function () {
    const $dropdowns = $('.dropdown');

    if ($dropdowns.length > 0) {
        $dropdowns.each(function () {
            createCustomDropdown($(this));
        });
    }

    const $form = $('.form');
    if ($form.length > 0) {
        $form.on('submit', function (e) {
            e.preventDefault();
        });
    }

    function createCustomDropdown($dropdown) {
        const $options = $dropdown.find('option');
        const optionsArr = $options.toArray();

        const $customDropdown = $('<div>', { class: 'dropdown' });
        $dropdown.after($customDropdown);

        const $selected = $('<div>', { class: 'dropdown-select', text: $options.filter(':selected').text() });
        $customDropdown.append($selected);

        const $menu = $('<div>', { class: 'dropdown-menu' });
        $customDropdown.append($menu);
        $selected.on('click', function () {
            toggleDropdown($menu, $selected);
        });

        const $search = $('<input>', { type: 'text', placeholder: 'جست و جو', class: 'dropdown-menu-search' });
        $menu.append($search);

        const $menuInnerWrapper = $('<div>', { class: 'dropdown-menu-inner' });
        $menu.append($menuInnerWrapper);
        
        $options.each(function () {
            const $option = $(this);
            var newClass = $option.is(':selected') ? 'is-select' : '';
            
            const $item = $('<div>', {
                class: 'dropdown-menu-item '+newClass,
                'data-value': $option.val(),
                text: $option.text()
            });
            $menuInnerWrapper.append($item);

            if ($option.prop('disabled')) {
                $item.addClass('disabled-item');
                $item.on('click', function (e) {
                    e.stopPropagation();
                });
            } else {
                $item.on('click', function () {
                    setSelected($(this), $selected, $dropdown, $menu);
                });
            }
        });

        // $menuInnerWrapper.find('div').first().addClass('is-select');

        $search.on('input', function () {
            filterItems(optionsArr, $menu, $(this).val());
        });

        $(document).on('click', function (e) {
            closeIfClickedOutside($menu, e);
        });

        $dropdown.hide();
    }

    function toggleDropdown($menu, $selected) {
        $menu.toggleClass('open');
        $selected.toggleClass('open');
    }

    function setSelected($item, $selected, $dropdown, $menu) {
        const value = $item.data('value');
        const label = $item.text();

        if ($item.hasClass('disabled-item')) {
            return;
        }

        $selected.text(label);
        $dropdown.val(value);

        $selected.addClass('is-selected');

        $menu.removeClass('open');
        $selected.removeClass('open');
        $menu.find('input').val('');

        $menu.find('.dropdown-menu-item').removeClass('is-select').show();
        $item.addClass('is-select');

        if (value === 'ready') {
            $('.ready-loding').slideDown(200);
            $('.personal-loding').hide();
        } else if (value === 'personal') {
            $('.personal-loding').slideDown(200);
            $('.ready-loding').hide();
        } else {
            $('.ready-loding').hide();
            $('.personal-loding').hide();
        }
    }

    function filterItems(itemsArr, $menu, searchValue) {
        const $customOptions = $menu.find('.dropdown-menu-inner div');
        const value = searchValue.toLowerCase();

        const indexesArr = itemsArr
            .filter(item => $(item).text().toLowerCase().includes(value))
            .map(item => itemsArr.indexOf(item));

        $customOptions.each(function () {
            const $option = $(this);
            const index = $customOptions.index($option);

            if (!indexesArr.includes(index)) {
                $option.hide();
            } else {
                $option.show();
            }
        });
    }

    function closeIfClickedOutside($menu, e) {
        if (!$(e.target).closest('.dropdown').length && !$menu.has(e.target).length && $menu.hasClass('open')) {
            $menu.removeClass('open');
            $('.dropdown-select').removeClass('open');
        }
    }
});

// با انتخاب گزینه سفارشی سازی
$(document).ready(function () {

    $('.dropdown-menu-item').on('click', function () {
        const selectedValue = $(this).data('value');
        const $parentItem = $(this).closest('.item');

        if (selectedValue === 'custom') {
            $parentItem.find('.inp-rang').css('display', 'flex').hide().slideDown();
        } else {
            $parentItem.find('.inp-rang').slideUp(function () {
                $(this).css('display', 'none');
            });
        }
    });
});

//  for animations
$('.animations .anim-item').click(function () {
    $('.animations .anim-item').removeClass('active');
    $(this).addClass('active');
});


// sidbar
$('.sidbar-item').on('click', function () {
    $('.sidbar-item').removeClass('select');
    $(this).addClass('select');
})

// rang
$(document).ready(function () {
    $('.rang').each(function () {
        var value = $(this).val();
        var min = $(this).attr('min');
        var max = $(this).attr('max');
        var percentage = (value - min) / (max - min) * 100;
        $(this).css('background', 'linear-gradient(to right, var(--theme-main) ' + percentage + '%, var(--gray-11) ' + percentage + '%)');
        $(this).next('.rang-number').find('span.num').text(value);
    });

    $('.rang').on('input', function () {
        var value = $(this).val();
        var min = $(this).attr('min');
        var max = $(this).attr('max');
        var percentage = (value - min) / (max - min) * 100;
        $(this).css('background', 'linear-gradient(to right, var(--theme-main) ' + percentage + '%, var(--gray-11) ' + percentage + '%)');
        $(this).next('.rang-number').find('span.num').text(value);
    });
});


// to open and close a new

$(document).ready(function () {
    $('.sliders_section,.offer_section,.notif_section,.open_acard').on('click','.suggestion-title', function () {
        var parent = $(this).closest('.add-suggestions'); 
        parent.toggleClass('opened');
    });
});

// show and hide days
$(document).ready(function () {

    $('.send-day input[type="checkbox"]').on('change', function () {
        var sendTime = $(this).closest('.shipping-time').find('.send-time');
        if ($(this).is(':checked')) {
            sendTime.slideDown(300);
        } else {
            sendTime.slideUp(300);
        }
    }).trigger('change');
});

$(document).ready(function () {

    $('.add-time').on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        var $parent = $this.parents('.send-time');
        var $name = $parent.find('.hours-time input').attr('name');
        console.log( $name );
        var newTime = $('<div class="hours-time"><input type="text" placeholder="'+dashboardScript.add_time_placeholder+'" name="'+$name+'" autocomplete="disable" ><a class="delete-btn"><img src="'+dashboardScript.trash_svg+'" alt="remove"></a></div>');
        var addTime = $(this).closest('.send-time');
        newTime.hide().prependTo(addTime).slideDown(200); // ابتدا آیتم مخفی می‌شود، سپس با انیمیشن اضافه می‌شود
    });

    $('.send-time').on('click', '.delete-btn', function (e) {
        e.preventDefault();
        var delete_inp = $(this).closest('.hours-time');
        delete_inp.slideUp(300, function () {
            $(this).remove();
        });
    });
});


//  add filed
$(document).ready(function () {
    $("#addFieldBtn").click(function () {

        var newItem = `
          <div class="field-item">
<div><img src="./img/menu.svg" alt=""></div>
<div><input type="text" placeholder="فیلد سفارشی"></div>
<div><input type="text" placeholder="custom_field"></div>
<div><input type="text" placeholder="فیلد سفارشی"></div>
                                                       
<div class="btn-select select-filed">
<input type="checkbox" class="switch" id="switch1">
</div>
<div class="btn-select select-filed">
<input type="checkbox" class="switch" id="switch1">
</div>
<div class="btn-select select-filed">
<input type="checkbox" class="switch" id="switch1">
</div>
<div>
<button class="delete-btn"><img src="./img/trash.svg" alt=""></button>
</div>
</div>
`;


        $(".peyment-fields").append(newItem);
    });


    $(document).on('click', '.delete-btn', function () {
        $(this).closest('.field-item').remove();
    });
});

// for focus and hover input
$(document).ready(function () {
    $('input[type="text"]').hover(function () {
        $(this).addClass('hovered');
    });

    $('input[type="text"]').focus(function () {
        $(this).removeClass('hovered');

    });
});



$(document).ready(function () {
    if( $('.js-example-basic-multiple').length )
    {
        $('.js-example-basic-multiple').select2();
    }
});


$(document).ready(function(){

    if( !$('.multi-select-category').length ){
        return;
    }
    
    $('.multi-select-category').select2({
        ajax: {
          url: ajaxurl + "?action=wplus_get_categories",
          //type: 'POST',
          dataType: "json",
          delay: 250,
          data: function (params) {
            return {
              search: params.term,
              page: params.page || 1,
            };
          },
          processResults: function (data) {
            data.page = data.page || 1;
            return {
              results: data.items,
              pagination: {
                more: data.pagination,
              },
            };
          },
        },
        placeholder: dashboardScript.select2.productCatSearch,
        allowClear: true,
        cache: true,
        language: {
            errorLoading: () => dashboardScript.select2.errorLoading,
            loadingMore: () => dashboardScript.select2.loadingMore,
            noResults: () => dashboardScript.select2.noResults,
            searching: () => dashboardScript.select2.searching,
            removeAllItems: () => dashboardScript.select2.removeAllItems,
            removeItem: () => dashboardScript.select2.removeItem
          }
      }
    );

});

$(document).ready(function(){

    if( !$('.multi-select-user').length ){
        return;
    }
    
    $('.multi-select-user').select2({
        ajax: {
          url: ajaxurl + "?action=wplus_get_users",
          //type: 'POST',
          dataType: "json",
          delay: 250,
          data: function (params) {
            return {
              search: params.term,
              page: params.page || 1,
            };
          },
          processResults: function (data) {
            data.page = data.page || 1;
            return {
              results: data.items,
              pagination: {
                more: data.pagination,
              },
            };
          },
        },
        placeholder: dashboardScript.select2.userSearch,
        allowClear: true,
        cache: true,
        language: {
            errorLoading: () => dashboardScript.select2.errorLoading,
            loadingMore: () => dashboardScript.select2.loadingMore,
            noResults: () => dashboardScript.select2.noResults,
            searching: () => dashboardScript.select2.searching,
            removeAllItems: () => dashboardScript.select2.removeAllItems,
            removeItem: () => dashboardScript.select2.removeItem
          }
      }
    );

});



$('.iner-btns .imp-clipboard').on('click', function () {
    $('.text-input').stop(true, true).slideDown(200);
})
$('.iner-btns .imp-file').on('click', function () {
    $('.file-name').stop(true, true).slideDown(200);

})


// 
$(document).ready(function () {
    // افزودن ورودی جدید با اسلاید
    $('.postal-companies .add-time').on('click', function () {
        let newInput = `
        <div class="hours-time names-postal-companies" style="display: none;">
            <input type="text" placeholder="شرکت ملی پست" class="hovered">
            <a class="delete-btn">
                <img src="./img/trash.svg" alt="">
            </a>
        </div>`;

        // اضافه کردن به HTML
        let $newElement = $(newInput).prependTo('.postal-companies');

        // اسلاید کردن به سمت پایین برای نمایش عنصر
        $newElement.slideDown(200);
    });

    // حذف ورودی هنگام کلیک روی دکمه حذف
    $(document).on('click', '.delete-btn', function () {
        var postal_parent = $(this).closest('.names-postal-companies');
        postal_parent.slideUp(100, function() {
            postal_parent.remove();
        });
    });
});

if( $('.sliders_section,.offer_section,.notif_section,.repeater-container').length )
{
    $('.sliders_section,.offer_section,.notif_section,.repeater-container').repeater({
        isFirstItemUndeletable: false,
        initEmpty: false,
        show: function () {
            var currentTimeStamp = Math.floor(Date.now() / 1000);
            $(this).find('.date_notif_class').attr('value',currentTimeStamp);
            $(this).addClass('opened');
            $('.upload_image', this).html('');
            $('.upload-image-button', this).removeClass('blue-btn upload-btn').html('ویرایش');
            $('.upload-image-button', this).addClass('blue-btn upload-btn').html('آپلود');
            $('.remove-image-button', this).hide();
            $(this).slideDown();
            
            if( $('.js-example-basic-multiple').length )
            {
                $('.js-example-basic-multiple').select2();
            }
            
            if( $('.color_picke').length )
            {
                $('.color_picke').wpColorPicker();
            }
            
        },
        hide: function (deleteElement) {
            //if(confirm(pgs_woo_api.delete_msg)) {
                $(this).slideUp(deleteElement);
            //}
        },
        ready: function (setIndexes) {
            
        }
    });
}

$('.btn-select input').on('click',function(e){
    if ($(this).is(':checked')) {

        $(this).val( 1 ).trigger( 'change' );
    }else{
        $(this).val( 0 ).trigger( 'change' );
    }
});


$(document).ready(function($) {
    $('.show-content-btn').click(function() {
        $('.content-popup').fadeIn();
    });

    $('.close-btn').click(function() {
        $('.content-popup').fadeOut();
    });

    $('.content-popup').click(function(e) {
        if ($(e.target).hasClass('content-popup')) {
            $(this).fadeOut();
        }
    });
});

$(document).ready(function(){
    $('.state_how_sell+.dropdown .dropdown-menu-item').on('click',function(){
        
        var $this = $(this);
        var $value = $this.data('value');
        if( 'unique_state' === $value )
        {
            $('body .unique_state').show();
        }else{
            $('body .unique_state').hide();
        }
        
    });

    var $value = $('.state_how_sell+.dropdown .dropdown-menu-item.is-select');
    var $fined = $value.data('value')
    if( 'unique_state' === $fined )
    {
        $('body .unique_state').show();
    }
    
});

$(document).ready(function(){
    $('body').on('click','.generate-pattern-customer',function(e){
        e.preventDefault();
        
        var $button = $(this);
        var $buttonContainer = $button.closest('div');
        
        // غیرفعال کردن دکمه و اضافه کردن لودر
        $button.prop('disabled', true).addClass('loading');
        $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();
        
        $.ajax({
            dataType:'json',type:'POST', url : ajaxurl,
            data : {
                action : 'generate_pattern_customer',
                nonce : dashboardScript.nonce
            },
            success:function(response){
                if(response.data){
                    var patternMapping = {
                        'customer_pending_now': {
                            class: 'customer_pending_now',
                            patternName: 'pattern-pending-now',
                            variablesName: 'variables-pending-now'
                        },
                        'customer_pending': {
                            class: 'customer_pending',
                            patternName: 'pattern-pending',
                            variablesName: 'variables-pending'
                        },
                        'customer_processing': {
                            class: 'customer_processing',
                            patternName: 'pattern-processing',
                            variablesName: 'variables-processing'
                        },
                        'customer_onhold': {
                            class: 'customer_onhold',
                            patternName: 'pattern-on-hold',
                            variablesName: 'variables-on-hold'
                        },
                        'customer_completed': {
                            class: 'customer_completed',
                            patternName: 'pattern-completed',
                            variablesName: 'variables-completed'
                        },
                        'customer_cancelled': {
                            class: 'customer_cancelled',
                            patternName: 'pattern-cancelled',
                            variablesName: 'variables-cancelled'
                        },
                        'customer_refunded': {
                            class: 'customer_refunded',
                            patternName: 'pattern-refunded',
                            variablesName: 'variables-refunded'
                        },
                        'customer_failed': {
                            class: 'customer_failed',
                            patternName: 'pattern-failed',
                            variablesName: 'variables-failed'
                        },
                        'customer_checkout_draft': {
                            class: 'customer_checkout_draft',
                            patternName: 'pattern-checkout-draft',
                            variablesName: 'variables-checkout-draft'
                        }
                    };
                    
                    for(var key in response.data){
                        if(response.data.hasOwnProperty(key) && patternMapping[key]){
                            var patternData = response.data[key];
                            var mapping = patternMapping[key];
                            
                            // قرار دادن code در input pattern
                            var patternInput = $('input[name*="[notif_customer][' + mapping.patternName + ']"]');
                            if(patternInput.length && patternData.code){
                                patternInput.val(patternData.code);
                            }
                            
                            // پیدا کردن repeater container مربوط به variables
                            var repeaterContainer = $('.' + mapping.class).find('[data-repeater-list*="' + mapping.variablesName + '"]');
                            
                            if(repeaterContainer.length && patternData.variables && patternData.variables.length > 0){
                                // گرفتن مسیر تصویر trash از یک آیتم موجود (اگر وجود داشته باشد)
                                var trashImgSrc = '';
                                var existingItem = repeaterContainer.find('[data-repeater-item]').first();
                                if(existingItem.length){
                                    trashImgSrc = existingItem.find('[data-repeater-delete] img').attr('src') || '';
                                } else {
                                    // اگر آیتمی وجود نداشت، از یک repeater دیگر استفاده کن
                                    var otherRepeater = $('[data-repeater-item]').first();
                                    if(otherRepeater.length){
                                        trashImgSrc = otherRepeater.find('[data-repeater-delete] img').attr('src') || '';
                                    }
                                }
                                
                                // اگر مسیر تصویر پیدا نشد، از مسیر پیش‌فرض استفاده کن
                                if(!trashImgSrc){
                                    trashImgSrc = '/wp-content/plugins/theme-plus/assets/admin/img/dashboard/trash.svg';
                                }
                                
                                // گرفتن data-repeater-list برای ساخت name های داینامیک
                                var repeaterListName = repeaterContainer.attr('data-repeater-list') || '';
                                
                                // پاک کردن آیتم‌های موجود در repeater
                                repeaterContainer.find('[data-repeater-item]').remove();
                                
                                // اضافه کردن variables به repeater
                                patternData.variables.forEach(function(variable, index){
                                    // تبدیل نام متغیر به فرمت shortcode
                                    var shortcode = '[' + variable.name + ']';
                                    
                                    // Escape کردن مقادیر برای جلوگیری از XSS
                                    var escapedVariableName = $('<div>').text(variable.name || '').html();
                                    var escapedShortcode = $('<div>').text(shortcode || '').html();
                                    
                                    // ساخت name های داینامیک بر اساس data-repeater-list
                                    // مثال: themeplus_settings[notif_customer][variables-pending-now][0][variable]
                                    var variableName = repeaterListName + '[' + index + '][variable]';
                                    var shortcodeName = repeaterListName + '[' + index + '][shortcode]';
                                    
                                    // ایجاد HTML برای آیتم جدید
                                    var itemHtml = '<div data-repeater-item>' +
                                        '<div class="send-time">' +
                                            '<div>' +
                                                '<input type="text" name="' + variableName + '" placeholder="متغیر" value="' + escapedVariableName + '">' +
                                                '<input type="text" name="' + shortcodeName + '" placeholder="شورتکد" value="' + escapedShortcode + '">' +
                                                '<a data-repeater-delete class="delete-btn">' +
                                                    '<img src="' + trashImgSrc + '" alt="">' +
                                                '</a>' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>';
                                    
                                    // اضافه کردن به repeater
                                    repeaterContainer.append(itemHtml);
                                });
                            }
                        }
                    }
                }
                
                // نمایش پیغام موفقیت
                $buttonContainer.find('.pattern-error-message').remove();
                var adminUrl = response.pattern_url;
                var successMessage = '<div class="pattern-success-message">' +
                    '<p>پترن های شما ایجاد شد. از این <a href="' + adminUrl + '" target="_blank">لینک</a> وضعیت پترن های خود را بررسی کنید.</p>' +
                    '</div>';
                $buttonContainer.append(successMessage);
            },
            error: function(error){
                console.error('Error generating pattern:', error);
                var txtErrorMessage = error?.responseJSON?.message; 

                if( !txtErrorMessage )
                {
                    txtErrorMessage = 'خطا در ایجاد پترن ها. لطفا دوباره تلاش کنید';
                }
                
                var errorMessage = '<div class="pattern-error-message">' +
                    '<p>'+txtErrorMessage+'</p>' +
                '</div>';
                
                $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();
                $buttonContainer.append(errorMessage);
            },
            complete: function(){
                // فعال کردن دکمه و حذف لودر
                $button.prop('disabled', false).removeClass('loading');
            }
        });
    });

    $('body').on('click','.generate-pattern-manager',function(e){

        e.preventDefault();

        var $button = $(this);
        var $buttonContainer = $button.closest('div');

        $button.prop('disabled', true).addClass('loading');
        $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();

        $.ajax({
            dataType:'json',type:'POST', url : ajaxurl,
            data : {
                action : 'generate_pattern_manager',
                nonce : dashboardScript.nonce
            },
            success:function(response){
                if(response.data){
                    var patternMapping = {
                        'manager_pending_now': {
                            class: 'manager_pending_now',
                            patternName: 'pattern-pending-now',
                            variablesName: 'variables-pending-now'
                        },
                        'manager_pending': {
                            class: 'manager_pending',
                            patternName: 'pattern-pending',
                            variablesName: 'variables-pending'
                        },
                        'manager_processing': {
                            class: 'manager_processing',
                            patternName: 'pattern-processing',
                            variablesName: 'variables-processing'
                        },
                        'manager_onhold': {
                            class: 'manager_onhold',
                            patternName: 'pattern-on-hold',
                            variablesName: 'variables-on-hold'
                        },
                        'manager_completed': {
                            class: 'manager_completed',
                            patternName: 'pattern-completed',
                            variablesName: 'variables-completed'
                        },
                        'manager_cancelled': {
                            class: 'manager_cancelled',
                            patternName: 'pattern-cancelled',
                            variablesName: 'variables-cancelled'
                        },
                        'manager_refunded': {
                            class: 'manager_refunded',
                            patternName: 'pattern-refunded',
                            variablesName: 'variables-refunded'
                        },
                        'manager_failed': {
                            class: 'manager_failed',
                            patternName: 'pattern-failed',
                            variablesName: 'variables-failed'
                        },
                        'manager_checkout_draft': {
                            class: 'manager_checkout_draft',
                            patternName: 'pattern-checkout-draft',
                            variablesName: 'variables-checkout-draft'
                        }
                    };
                    
                    for(var key in response.data){
                        if(response.data.hasOwnProperty(key) && patternMapping[key]){
                            var patternData = response.data[key];
                            var mapping = patternMapping[key];
                            
                            // قرار دادن code در input pattern
                            var patternInput = $('input[name*="[notif_manager][' + mapping.patternName + ']"]');
                            if(patternInput.length && patternData.code){
                                patternInput.val(patternData.code);
                            }
                            
                            // پیدا کردن repeater container مربوط به variables
                            var repeaterContainer = $('.' + mapping.class).find('[data-repeater-list*="' + mapping.variablesName + '"]');
                            
                            if(repeaterContainer.length && patternData.variables && patternData.variables.length > 0){
                                // گرفتن مسیر تصویر trash از یک آیتم موجود (اگر وجود داشته باشد)
                                var trashImgSrc = '';
                                var existingItem = repeaterContainer.find('[data-repeater-item]').first();
                                if(existingItem.length){
                                    trashImgSrc = existingItem.find('[data-repeater-delete] img').attr('src') || '';
                                } else {
                                    // اگر آیتمی وجود نداشت، از یک repeater دیگر استفاده کن
                                    var otherRepeater = $('[data-repeater-item]').first();
                                    if(otherRepeater.length){
                                        trashImgSrc = otherRepeater.find('[data-repeater-delete] img').attr('src') || '';
                                    }
                                }
                                
                                // اگر مسیر تصویر پیدا نشد، از مسیر پیش‌فرض استفاده کن
                                if(!trashImgSrc){
                                    trashImgSrc = '/wp-content/plugins/theme-plus/assets/admin/img/dashboard/trash.svg';
                                }
                                
                                // گرفتن data-repeater-list برای ساخت name های داینامیک
                                var repeaterListName = repeaterContainer.attr('data-repeater-list') || '';
                                
                                // پاک کردن آیتم‌های موجود در repeater
                                repeaterContainer.find('[data-repeater-item]').remove();
                                
                                // اضافه کردن variables به repeater
                                patternData.variables.forEach(function(variable, index){
                                    // تبدیل نام متغیر به فرمت shortcode
                                    var shortcode = '[' + variable.name + ']';
                                    
                                    // Escape کردن مقادیر برای جلوگیری از XSS
                                    var escapedVariableName = $('<div>').text(variable.name || '').html();
                                    var escapedShortcode = $('<div>').text(shortcode || '').html();
                                    
                                    // ساخت name های داینامیک بر اساس data-repeater-list
                                    // مثال: themeplus_settings[notif_customer][variables-pending-now][0][variable]
                                    var variableName = repeaterListName + '[' + index + '][variable]';
                                    var shortcodeName = repeaterListName + '[' + index + '][shortcode]';
                                    
                                    // ایجاد HTML برای آیتم جدید
                                    var itemHtml = '<div data-repeater-item>' +
                                        '<div class="send-time">' +
                                            '<div>' +
                                                '<input type="text" name="' + variableName + '" placeholder="متغیر" value="' + escapedVariableName + '">' +
                                                '<input type="text" name="' + shortcodeName + '" placeholder="شورتکد" value="' + escapedShortcode + '">' +
                                                '<a data-repeater-delete class="delete-btn">' +
                                                    '<img src="' + trashImgSrc + '" alt="">' +
                                                '</a>' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>';
                                    
                                    // اضافه کردن به repeater
                                    repeaterContainer.append(itemHtml);
                                });
                            }
                        }
                    }
                }
                
                // نمایش پیغام موفقیت
                $buttonContainer.find('.pattern-error-message').remove();
                var adminUrl = response.pattern_url;
                var successMessage = '<div class="pattern-success-message">' +
                    '<p>پترن های شما ایجاد شد. از این <a href="' + adminUrl + '" target="_blank">لینک</a> وضعیت پترن های خود را بررسی کنید.</p>' +
                    '</div>';
                $buttonContainer.append(successMessage);
            },
            error: function(error){
                console.error('Error generating pattern:', error);
                var txtErrorMessage = error?.responseJSON?.message; 

                if( !txtErrorMessage )
                {
                    txtErrorMessage = 'خطا در ایجاد پترن ها. لطفا دوباره تلاش کنید';
                }
                
                var errorMessage = '<div class="pattern-error-message">' +
                    '<p>'+txtErrorMessage+'</p>' +
                '</div>';
                $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();
                $buttonContainer.append(errorMessage);
            },
            complete: function(){
                // فعال کردن دکمه و حذف لودر
                $button.prop('disabled', false).removeClass('loading');
            }
        });
    });

    $('body').on('click','.generate-pattern-ordertracking',function(e){
        e.preventDefault();

        var $button = $(this);
        var $buttonContainer = $button.closest('div');

        $button.prop('disabled', true).addClass('loading');
        $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();

        $.ajax({
            dataType:'json',type:'POST', url : ajaxurl,
            data : {
                action : 'generate_pattern_ordertracking',
                nonce : dashboardScript.nonce
            },
            success:function(response){
                if(response.data){
                    var patternMapping = {
                        'order_tracking_post': {
                            class: 'order_tracking_post',
                            patternName: 'pattern-post',
                            variablesName: 'variables-post'
                        },
                        'order_tracking_delivery': {
                            class: 'order_tracking_delivery',
                            patternName: 'pattern-delivery',
                            variablesName: 'variables-delivery'
                        },
                    };
                    
                    for(var key in response.data){
                        if(response.data.hasOwnProperty(key) && patternMapping[key]){
                            var patternData = response.data[key];
                            var mapping = patternMapping[key];
                            
                            // قرار دادن code در input pattern
                            var patternInput = $('input[name*="[order_tracking][' + mapping.patternName + ']"]');
                            if(patternInput.length && patternData.code){
                                patternInput.val(patternData.code);
                            }
                            
                            // پیدا کردن repeater container مربوط به variables
                            var repeaterContainer = $('.' + mapping.class).find('[data-repeater-list*="' + mapping.variablesName + '"]');
                            
                            if(repeaterContainer.length && patternData.variables && patternData.variables.length > 0){
                                // گرفتن مسیر تصویر trash از یک آیتم موجود (اگر وجود داشته باشد)
                                var trashImgSrc = '';
                                var existingItem = repeaterContainer.find('[data-repeater-item]').first();
                                if(existingItem.length){
                                    trashImgSrc = existingItem.find('[data-repeater-delete] img').attr('src') || '';
                                } else {
                                    // اگر آیتمی وجود نداشت، از یک repeater دیگر استفاده کن
                                    var otherRepeater = $('[data-repeater-item]').first();
                                    if(otherRepeater.length){
                                        trashImgSrc = otherRepeater.find('[data-repeater-delete] img').attr('src') || '';
                                    }
                                }
                                
                                // اگر مسیر تصویر پیدا نشد، از مسیر پیش‌فرض استفاده کن
                                if(!trashImgSrc){
                                    trashImgSrc = '/wp-content/plugins/theme-plus/assets/admin/img/dashboard/trash.svg';
                                }
                                
                                // گرفتن data-repeater-list برای ساخت name های داینامیک
                                var repeaterListName = repeaterContainer.attr('data-repeater-list') || '';
                                
                                // پاک کردن آیتم‌های موجود در repeater
                                repeaterContainer.find('[data-repeater-item]').remove();
                                
                                // اضافه کردن variables به repeater
                                patternData.variables.forEach(function(variable, index){
                                    // تبدیل نام متغیر به فرمت shortcode
                                    var shortcode = '[' + variable.name + ']';
                                    
                                    // Escape کردن مقادیر برای جلوگیری از XSS
                                    var escapedVariableName = $('<div>').text(variable.name || '').html();
                                    var escapedShortcode = $('<div>').text(shortcode || '').html();
                                    
                                    // ساخت name های داینامیک بر اساس data-repeater-list
                                    // مثال: themeplus_settings[notif_customer][variables-pending-now][0][variable]
                                    var variableName = repeaterListName + '[' + index + '][variable]';
                                    var shortcodeName = repeaterListName + '[' + index + '][shortcode]';
                                    
                                    // ایجاد HTML برای آیتم جدید
                                    var itemHtml = '<div data-repeater-item>' +
                                        '<div class="send-time">' +
                                            '<div>' +
                                                '<input type="text" name="' + variableName + '" placeholder="متغیر" value="' + escapedVariableName + '">' +
                                                '<input type="text" name="' + shortcodeName + '" placeholder="شورتکد" value="' + escapedShortcode + '">' +
                                                '<a data-repeater-delete class="delete-btn">' +
                                                    '<img src="' + trashImgSrc + '" alt="">' +
                                                '</a>' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>';
                                    
                                    // اضافه کردن به repeater
                                    repeaterContainer.append(itemHtml);
                                });
                            }
                        }
                    }
                }
                
                // نمایش پیغام موفقیت
                $buttonContainer.find('.pattern-error-message').remove();
                var adminUrl = response.pattern_url;
                var successMessage = '<div class="pattern-success-message">' +
                    '<p>پترن های شما ایجاد شد. از این <a href="' + adminUrl + '" target="_blank">لینک</a> وضعیت پترن های خود را بررسی کنید.</p>' +
                    '</div>';
                $buttonContainer.append(successMessage);
            },
            error: function(error){
                console.error('Error generating pattern:', error);
                var txtErrorMessage = error?.responseJSON?.message; 

                if( !txtErrorMessage )
                {
                    txtErrorMessage = 'خطا در ایجاد پترن ها. لطفا دوباره تلاش کنید';
                }
                
                var errorMessage = '<div class="pattern-error-message">' +
                    '<p>'+txtErrorMessage+'</p>' +
                '</div>';

                $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();
                $buttonContainer.append(errorMessage);
            },
            complete: function(){
                // فعال کردن دکمه و حذف لودر
                $button.prop('disabled', false).removeClass('loading');
            }
        });
    });
    
    $('body').on('click','.generate-pattern-ticket',function(e){
        e.preventDefault();

        var $button = $(this);
        var $buttonContainer = $button.closest('div');

        $button.prop('disabled', true).addClass('loading');
        $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();

        $.ajax({
            dataType:'json',type:'POST', url : ajaxurl,
            data : {
                action : 'generate_pattern_ticket',
                nonce : dashboardScript.nonce
            },
            success:function(response){
                if(response.data){
                    var patternMapping = {
                        'ticket_new_to_manager': {
                            class: 'ticket_new_to_manager',
                            patternName: 'pattern_new_ticket_manager',
                            variablesName: 'variable_new_ticket_manager'
                        },
                        'ticket_new_to_customer': {
                            class: 'ticket_new_to_customer',
                            patternName: 'pattern_new_ticket_customer',
                            variablesName: 'variable_new_ticket_customer'
                        },
                        'ticket_answer_to_manager': {
                            class: 'ticket_answer_to_manager',
                            patternName: 'pattern_ticket_answer_manager',
                            variablesName: 'variable_ticket_answer_manager'
                        },
                        'ticket_answer_to_customer': {
                            class: 'ticket_answer_to_customer',
                            patternName: 'pattern_ticket_answer_customer',
                            variablesName: 'variable_ticket_answer_customer'
                        },
                        'ticket_touser': {
                            class: 'ticket_touser',
                            patternName: 'pattern_touser',
                            variablesName: 'variable_touser'
                        },
                        'ticket_from_admin_to_user': {
                            class: 'ticket_from_admin_to_user',
                            patternName: 'pattern_from_admin_touser',
                            variablesName: 'variable_from_admin_touser'
                        },
                    };
                    
                    for(var key in response.data){
                        if(response.data.hasOwnProperty(key) && patternMapping[key]){
                            var patternData = response.data[key];
                            var mapping = patternMapping[key];
                            
                            // قرار دادن code در input pattern
                            var patternInput = $('input[name*="[ticket_notif][' + mapping.patternName + ']"]');
                            if(patternInput.length && patternData.code){
                                patternInput.val(patternData.code);
                            }
                            
                            // پیدا کردن repeater container مربوط به variables
                            var repeaterContainer = $('.' + mapping.class).find('[data-repeater-list*="' + mapping.variablesName + '"]');
                            
                            if(repeaterContainer.length && patternData.variables && patternData.variables.length > 0){
                                // گرفتن مسیر تصویر trash از یک آیتم موجود (اگر وجود داشته باشد)
                                var trashImgSrc = '';
                                var existingItem = repeaterContainer.find('[data-repeater-item]').first();
                                if(existingItem.length){
                                    trashImgSrc = existingItem.find('[data-repeater-delete] img').attr('src') || '';
                                } else {
                                    // اگر آیتمی وجود نداشت، از یک repeater دیگر استفاده کن
                                    var otherRepeater = $('[data-repeater-item]').first();
                                    if(otherRepeater.length){
                                        trashImgSrc = otherRepeater.find('[data-repeater-delete] img').attr('src') || '';
                                    }
                                }
                                
                                // اگر مسیر تصویر پیدا نشد، از مسیر پیش‌فرض استفاده کن
                                if(!trashImgSrc){
                                    trashImgSrc = '/wp-content/plugins/theme-plus/assets/admin/img/dashboard/trash.svg';
                                }
                                
                                // گرفتن data-repeater-list برای ساخت name های داینامیک
                                var repeaterListName = repeaterContainer.attr('data-repeater-list') || '';
                                
                                // پاک کردن آیتم‌های موجود در repeater
                                repeaterContainer.find('[data-repeater-item]').remove();
                                
                                // اضافه کردن variables به repeater
                                patternData.variables.forEach(function(variable, index){
                                    // تبدیل نام متغیر به فرمت shortcode
                                    var shortcode = '[' + variable.name + ']';
                                    
                                    // Escape کردن مقادیر برای جلوگیری از XSS
                                    var escapedVariableName = $('<div>').text(variable.name || '').html();
                                    var escapedShortcode = $('<div>').text(shortcode || '').html();
                                    
                                    // ساخت name های داینامیک بر اساس data-repeater-list
                                    // مثال: themeplus_settings[notif_customer][variables-pending-now][0][variable]
                                    var variableName = repeaterListName + '[' + index + '][variable]';
                                    var shortcodeName = repeaterListName + '[' + index + '][shortcode]';
                                    
                                    // ایجاد HTML برای آیتم جدید
                                    var itemHtml = '<div data-repeater-item>' +
                                        '<div class="send-time">' +
                                            '<div>' +
                                                '<input type="text" name="' + variableName + '" placeholder="متغیر" value="' + escapedVariableName + '">' +
                                                '<input type="text" name="' + shortcodeName + '" placeholder="شورتکد" value="' + escapedShortcode + '">' +
                                                '<a data-repeater-delete class="delete-btn">' +
                                                    '<img src="' + trashImgSrc + '" alt="">' +
                                                '</a>' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>';
                                    
                                    // اضافه کردن به repeater
                                    repeaterContainer.append(itemHtml);
                                });
                            }
                        }
                    }
                }
                
                // نمایش پیغام موفقیت
                $buttonContainer.find('.pattern-error-message').remove();
                var adminUrl = response.pattern_url;
                var successMessage = '<div class="pattern-success-message">' +
                    '<p>پترن های شما ایجاد شد. از این <a href="' + adminUrl + '" target="_blank">لینک</a> وضعیت پترن های خود را بررسی کنید.</p>' +
                    '</div>';
                $buttonContainer.append(successMessage);
            },
            error: function(error){
                console.error('Error generating pattern:', error);
                var txtErrorMessage = error?.responseJSON?.message; 

                if( !txtErrorMessage )
                {
                    txtErrorMessage = 'خطا در ایجاد پترن ها. لطفا دوباره تلاش کنید';
                }
                
                var errorMessage = '<div class="pattern-error-message">' +
                    '<p>'+txtErrorMessage+'</p>' +
                '</div>';
                $buttonContainer.find('.pattern-success-message, .pattern-error-message').remove();
                $buttonContainer.append(errorMessage);
            },
            complete: function(){
                // فعال کردن دکمه و حذف لودر
                $button.prop('disabled', false).removeClass('loading');
            }
        });
    });
});

$(document).ready(function() {
    const fileUploadArea = $('#file-upload-area');
    const fileInput = $('#import-file-input');
    const selectedFile = $('#selected-file');
    const fileName = $('#file-name');
    const fileSize = $('#file-size');
    const removeFileBtn = $('#remove-file-btn');
    const importBtn = $('#import-settings-btn');
    const exportBtn = $('#export-settings-btn');

    // File upload area click
    fileUploadArea.on('click', function(e) {
        e.stopPropagation();
        fileInput.click();
    });

    // Drag and drop functionality
    fileUploadArea.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });

    fileUploadArea.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
    });

    fileUploadArea.on('drop', function(e) {
         e.preventDefault();
        $(this).removeClass('dragover');

        const files = e.originalEvent.dataTransfer.files;
        if (files.length > 0) {

            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(files[0]);
            fileInput[0].files = dataTransfer.files;

            handleFileSelection(files[0]);
        }
    });

    // File input change
    fileInput.on('change', function() {
        const file = this.files[0];
        if (file) {
            handleFileSelection(file);
        }
    });

    function handleFileSelection(file) {
        if (file.type !== 'application/json' && !file.name.endsWith('.json')) {
            // alert('<?php #esc_js_e('Please select a valid JSON file.', 'woodmartplus'); ?>');
            return;
        }
        fileName.text(file.name);
        fileSize.text(formatFileSize(file.size));
        selectedFile.show();
        importBtn.prop('disabled', false);
        fileUploadArea.hide();
    }

    // Remove file
    removeFileBtn.on('click', function() {
        fileInput.val('');
        selectedFile.hide();
        fileUploadArea.show();
        importBtn.prop('disabled', true);
    });

    // Import settings
    importBtn.on('click', function() {
        if (!fileInput[0].files[0]) {
            alert("لطفاً یک فایل انتخاب کنید.");
            return;
        }

        $(this).addClass('loading');

        let formData = new FormData();
        formData.append('file', fileInput[0].files[0]);

        formData.append('action', 'import_options'); // برای وردپرس Ajax
        // formData.append('security', my_ajax_object.nonce); // nonce امنیتی

        $.ajax({
            url: ajaxurl, 
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false, 
            success: function(response) {
                importBtn.removeClass('loading');
                window.location.href = response.redirect;
            },
            error: function(xhr, status, error) {
                importBtn.removeClass('loading');
                console.error('خطا:', error);
            }
        });
    });

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
});

})( jQuery );