(function($){

    $(document).ready(function(){

        $('.delete-translate').on('click',function(){
            var $this = $(this);
            var id = $(this).data('delete_translate');
            var $parent = $this.parents('ul');
            var $li = $this.parent('li.translation-item');
            var nonce = $parent.find('#delete_translate_nonce').val();
            var action = 'remove_translate';
            var data = {
                action: action,
                id: id,
                nonce: nonce
            };
            
            $li.addClass('delete-loading')
            $.post(ajaxurl, data, function(response) {

                if( !response.success )
                {
                    $li.removeClass('delete-loading')
                   return console.log(response.data);
                }
                
                $($li).remove();
            });
        });
    });
})(jQuery);