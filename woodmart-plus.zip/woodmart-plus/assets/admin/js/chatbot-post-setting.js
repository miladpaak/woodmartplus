(function($){

    $(document).ready(function(){

        $('#get_post_rag').on('click',function(e){

            var $this = $(this);
            var post_id = $this.data('post_id');
            var post_type = $this.data('post_type');
            var wrapper_message = $('.message-rag-notice');
            
            var btn_txt = $this.text();
            $this.text('درحال انجام...');
            

            $.ajax({
                dataType:'json', type : 'POST', url : ajaxurl,
                data:{
                    action : 'start_rag_post',
                    post_id : post_id,
                    post_type : post_type,
                    nonce : postObjectChatbot.nonce
                },
                success:function(response){
                    wrapper_message.find('.rag-message').text( response.message );
                    wrapper_message.show();
                    $this.text(btn_txt);

                    setTimeout(() => {
                        wrapper_message.find('.rag-message').empty();
                        wrapper_message.hide();
                    }, 3000);
                },
                error : function(error){
                    
                    wrapper_message.find('.rag-message').text( error.responseJSON?.message );
                    wrapper_message.show();
                    $this.text(btn_txt);

                    setTimeout(() => {
                        wrapper_message.find('.rag-message').empty();
                        wrapper_message.hide();
                    }, 3000);
                }
            });
        });
        
        $('#update_post_rag').on('click',function(e){

            var $this = $(this);
            var post_id = $this.data('post_id');
            var wrapper_message = $('.message-rag-notice');
            var post_type = $this.data('post_type');

            var btn_txt = $this.text();
            $this.text('درحال انجام...');
            
            $.ajax({
                dataType:'json', type : 'POST', url : ajaxurl,
                data:{
                    action : 'update_rag_post',
                    post_id : post_id,
                    post_type : post_type,
                    nonce : postObjectChatbot.nonce
                },
                success:function(response){
                    
                    wrapper_message.find('.rag-message').text( response.message );
                    wrapper_message.show();
                    $this.text(btn_txt);

                    setTimeout(() => {
                        wrapper_message.find('.rag-message').empty();
                        wrapper_message.hide();
                    }, 3000);
                },
                error : function(error){
                    
                    wrapper_message.find('.rag-message').text( error.responseJSON?.message );
                    wrapper_message.show();
                    $this.text(btn_txt);

                    setTimeout(() => {
                        wrapper_message.find('.rag-message').empty();
                        wrapper_message.hide();
                    }, 3000);
                }
            });
        });

    });


})(jQuery);
