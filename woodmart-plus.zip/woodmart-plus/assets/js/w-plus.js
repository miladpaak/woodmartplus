(function($){
    
    $(window).on("elementor/frontend/init", function() {
            
        elementorFrontend.hooks.addAction( "frontend/element_ready/woodplus_my_account_slider_dashboard_elementor.default",function( $scope ){
                
                if( $('.swiper_homepage').length && window.elementor )
                {
                    var swiperHomepage = new Swiper(".swiper_homepage", {
                        slidesPerView: 1,
                        loop: true,
                        paginationClickable: true,
                        navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                        },
                        pagination: {
                            el: ".swiper-pagination",
                            clickable: true
                        },
                    });     
                }
        });
    });
    
    $(document).ready(function(){

        $('#avatar_image').on('change',function(e){
            e.preventDefault();
            var file_input = $(this);
            var file = this.files[0];
            var reader = new FileReader();
            reader.onload = function(e){
                var $avatar_image = file_input.parents('.dashboard_container').find('.avatar_image_account');
                $avatar_image.find('img').attr('src',e.target.result);
            };
            reader.readAsDataURL(file);
        });
    });
    
    $(document).ready(function(){

        $('.input_container').each(function(index,value){
            var $this = $(this),
                btn_clear = $this.find('.btn_clear'),
                input_form = $this.find('input');
                
            $(btn_clear).on('click',function(e){
                e.preventDefault();
                input_form.val("");
            });

        });
    });

    $(document).ready(function(){
        
        if( $('.swiper_homepage').length )
        {
             var swiperHomepage = new Swiper(".swiper_homepage", {
                slidesPerView: 1,
                loop: true,
                paginationClickable: true,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true
                },
            }); 
        }
    });


  $(document).ready(function(){
    $('.add_ticket__form').on('submit',function(e){

        var $this = $(this);    
        var select = $this.find('.ticket_select_items');
        var hasError = false;
        select.each(function(index,element){
            if( $(element).attr('data-required') != 0 )
            {
                $(element).css({
                    'border' : '1px solid red'
                });
                hasError = true;
            }
        });

        if( hasError )
        {
            e.preventDefault();
        }else{
            $this.submit();
        }
    });

    $('.ticket_select_items').each(function(index,element){

        $(element).on('change',function(){
            var $nextThis = $(this);
            if( $nextThis.val() !== 'default' || $nextThis.val() !== 'departman_default' || $nextThis.val() !== 'priority_default' )
            {
                $(element).attr('data-required',0);
                $(element).css('border','');
            }
        });
    });
  });


  $(document).ready(function(){
        
      $('body').on('submit','form.aramis_login', function(e){

          e.preventDefault();
          var $this = $(this);
          var alert = $('body').find('.alert');
          var btn_sub = $(this).find('button');
          
          var $user_name = $(this).find('input[name="username"]').val();
          var $password = $(this).find('input[name="password"]').val();
          var $phone = $(this).find('input[name="phone_login"]').val();
          var $nonce = $(this).find('.nonce_login_register').val();
          var $checkRemember = $(this).find('#checkRemember').val();
          var verify_otp = $('body').find('.verify_otp_login');
          var $btn_form = $this.find('.aramis__login_btn');
              $btn_form.addClass('loading');
          var btn_text = $btn_form.html();

            $btn_form.empty();

          btn_sub.addClass('btn-loading');

          $.ajax({

              dataType:'json',type:'post',url : optionarray.woodplus_url,

              data:{
                  action:'process_login',
                  user_name : $user_name,
                  password : $password,
                  phone : $phone,
                  nonce : $nonce,
                  checkRemember : $checkRemember
              },
              success:function(response)
              {
                
                  $btn_form.html(btn_text);
                  $btn_form.removeClass('loading');
                  btn_sub.removeClass('btn-loading');
                  

                  alert.addClass('badge_green--border');
                  alert.children().find('p').append(response.message);
                  alert.show();
                  btn_sub.removeClass('btn-loading');

                  
                  window.location.href = response.redirect_url;
              },
              error:function(error)
              {
                    $btn_form.html(btn_text);
                    $btn_form.removeClass('loading');

                  alert.addClass('badge_danger--border');
                  alert.children().find('p').append(error.responseJSON.message);
                  alert.show();
                  btn_sub.removeClass('btn-loading');
                  
                  setTimeout(function(){
                      alert.removeClass('badge_danger--border');
                      alert.children().find('p').empty();
                      alert.hide();
                  },3000);
              } 
          

          });
  
      });
      
  
  });

  // register
  $(document).ready(function(){

      $('body').on('submit','.aramis_register_form', function(e){
          e.preventDefault();

          var $this = $(this);
          var detail_register = $('body').find('.detail_register');
          var alert = $('body').find('.alert');
          var $phone = $(this).find('input[name="phone"]').val();
          var $nonce = $(this).find('#nonce_woodplus_register').val();
          var verify_form = $('body').find('.verify_otp');
          var btn_sub = $(this).find('button');

          var $username = $(this).find('input[name="username"]').val();
          var $password = $(this).find('input[name="password"]').val();
          var $email = $(this).find('input[name="email"]').val();
          var action = 'register_with_phone';

          var $form_btn = $this.find('.aramis__register_btn');
          var $form_btn_text = $form_btn.html();

              $form_btn.addClass('loading');
              $form_btn.empty();

          if( $(this).find('input[name="email"]').length)
          {
              action = '_woocmmerce_register';    
          }
          
          
          btn_sub.addClass('btn-loading');
          

          $.ajax({

              type:'post', dataType:'json', url: optionarray.woodplus_url,
              data:{
                  action: action,
                  phone_number: $phone,
                  nonce_register: $nonce,
                  email : $email,
                  password : $password,
                  username : $username,
                  role: 'customer'
                  
              },
              success: function(response)
              {
                $form_btn.removeClass('loading');
                $form_btn.html( $form_btn_text );
                  if(response.register)
                  {
                    
                      alert.children().find('p').append(response.msg);
                      alert.addClass('badge_green--border');
                      alert.show();
                      
                      setTimeout(function(){
                          window.location.href = response.redirect_url;
                      },1000)

                      return;
                  }
                  $this.hide();
                  detail_register.hide();
                  verify_form.show();
                  verify_form.children().find('.msg_detail_number').append(response.msg);
                  verify_form.find('.phone_number').attr('data-phone_number',$phone);
                  btn_sub.removeClass('btn-loading');
                  var resendTime      = parseInt( optionarray.wating_time_resend_otp );
                  var $timer          = verify_form.find('.time_resend');
                  
                  if( resendTime > 0 ) {
                      // $resendLink.addClass('disabled');
                      var resendTimer;
                      clearInterval( resendTimer );
                      $timer.addClass('disable');
                      resendTimer = setInterval(function(){

                          $timer.html('('+resendTime+') ثانیه');

                          if( resendTime <= 0 ){
                              clearInterval( resendTimer );
                              
                              $timer.removeClass('disable');
                              // $resendLink.removeClass('disabled');
                              $timer.html('');
                              $timer.append('<a href="javascript:void(0);" class="resend_otp_sms">ارسال مجدد</a>');
                          }
                          resendTime--;

                      },1000);
                  }

              },
              error: function(error)
              {

                $form_btn.removeClass('loading');
                $form_btn.html( $form_btn_text );
                 
                  btn_sub.removeClass('btn-loading');

                  if(error.responseJSON.user_exists)
                  {
                      alert.children().find('p').append(error.responseJSON.msg + '<a href="'+optionarray.WcPage.myacc+'" > '+error.responseJSON.msg_login+' </a>');

                  }else{

                      alert.children().find('p').append(error.responseJSON.msg);
                  }

                  alert.addClass('badge_danger--border');
                  alert.show();

                  setTimeout(function(){
                      alert.removeClass('badge_danger--border');
                      alert.children().find('p').empty();
                      alert.hide();
                  },3000);
              }

          });

      })
  });

  // verify_otp register
  $(document).ready(function(){

      $('body').on('submit', '.verify_otp', function(e){
          e.preventDefault();
          var $this = $(this);
          var otp = '';
          var $nonce = $(this).find('.nonce_verify_otp').val();
          var $phone = $(this).find('.phone_number').data('phone_number');
          var alert = $('body').find('.alert');
          var btn_sub = $(this).find('button');
          btn_sub.addClass('btn-loading');
            
          $this.find('.phone_validate').each( function( index, input ){
            
              otp += $(this).val();
          });

          $.ajax({
              dataType: 'json', type:'post', url: optionarray.woodplus_url,
              data:{
                  action: 'verify_otp',
                  otp_sended : otp,
                  phone : $phone,
                  nonce_verify_otp: $nonce
              },
              success:function(response)
              {
                  alert.addClass('badge_green--border');
                  alert.children().find('p').append(response.msg);
                  alert.show();
                  btn_sub.removeClass('btn-loading');

                  window.location.href = optionarray.WcPage.myacc;
              },

              error:function(error)
              {
                

                alert.children().find('p').append(error.responseJSON.msg);

                  alert.addClass('badge_danger--border');
                  alert.show();
                  btn_sub.removeClass('btn-loading');
                  setTimeout(function(){
                      alert.removeClass('badge_danger--border');
                      alert.children().find('p').empty();
                      alert.hide();
                  },5000);
              }

          });
      });

  });


  //resend_otp_sms

  $(document).ready(function(){

      $('body').on('click','.resend_otp_sms',function(e){
          e.preventDefault();
          var $this = $(this);
          var parent = $this.parents('.form-box');
          var hashed = parent.find('.step_otp').attr('data-hashed');

          var verify_form = $('body').find('.verify_otp_all,.login_register_otp,.login_register_otp_email,.form-box');
       
          parent.addClass('loading-resend');
          $.ajax({
              dataType:'json',type:'post',url:optionarray.woodplus_url,
              data:{
                  action:'action_resend_otp',
                  nonce_resend: optionarray.aramis_script_nonce,
                  hashed : hashed
              },
              success:function(response)
              {
                
                timer_resend(verify_form);
                show_alert(parent,response.msg,'success');
                  
              },
              error:function(error)
              {
                show_alert(parent,error.responseJSON.msg,'error');
               
              }
              
          });

      });

  });

  // edit nummber section

  $(document).ready(function(){

      $('body').on('click','.edit_number', function(e){

          var parent = $(this).closest('.verify_otp_all');
          var detail_register = $('body').find('.detail_register');
          var register_form  = $('body').find('.aramis_register_form');
          var login_form = $('body').find('.parrent_aramis_login');
          var cod_for_phone = $('body').find('.msg_detail_number');

          var login_register_together = $(this).closest('.login_register_otp');

          var time_resend = login_register_together.find('.time_resend');

          var timerId = parseInt(time_resend.attr('data-timer_time'));
          
          clearInterval(timerId);
          
          cod_for_phone.empty();
          

          if( login_register_together.length )
          {
                login_register_together.hide();
                $('body').find('.form__login_register').show();
                return;
          }


          if(register_form.length)
          {
              register_form.css('display','flex');

              parent.css('display','none');

              detail_register.show();

              return;
          }

          if(login_form.length)
          {
              login_form.css('display','block');
              $('body').find('.verify_otp_login').css('display','none');
              return;
          }

      });

  });

  //login and register now

  $(document).ready(function(){

    
    $('body').on('submit','.form__login_register',function(e){
        e.preventDefault();
        var $this = $(this);
        var $value = $(this).find('input[name="username"]').val();
        var $nonce = $(this).find('.nonce_login_register').val();

        var captcha_val = false;
        
        var $captcha = $(this).find('textarea[name="g-recaptcha-response"]');

        if( optionarray.captcha_is_enable )
        {
            captcha_val = $captcha.val();
        }

        var $parents = $this.closest('.login_register__body,.login_register_smart');
        var btn = $this.find('.login_register__submitbtn');
            btn.addClass('loading');
        var text_btn = btn.html();
            btn.empty();
        
        $.ajax({
            type: 'POST',dataType :'json', url: optionarray.woodplus_url,
            data:{
                action:'login_register_together',
                value : $value,
                captcha : captcha_val,
                nonce : $nonce
            },
            success: function(response)
            {
                $this.hide();
                btn.removeClass('loading');
                btn.html(text_btn);

                if( 'email_login' === response.status || 'account_login' === response.status )
                {
                    var $login_form = $parents.find('.form_login_email');
                    $login_form.find('.login_register__description').empty();
                    $login_form.find('.login_register__description').html( response.msg );
                    $login_form.show();
                    $login_form.append('<input name="username_sended" type="hidden" value="'+$value+'">');
                    
                }
                
                if( 'email_register' === response.status )
                {

                    var $register_otp_form = $parents.find('.login_register_otp_email');

                    $register_otp_form.find('.msg_detail_number').append(response.msg)
                    
                    var resendTime      = parseInt( optionarray.wating_time_resend_otp );
                    var $timer          = $register_otp_form.find('.time_resend');
                    
                    if( resendTime > 0 ) {
                        // $resendLink.addClass('disabled');
                        var resendTimer;
                        clearInterval( resendTimer );
                        
                        resendTimer = setInterval(function(){

                            $timer.html('('+resendTime+') ثانیه');
                            
                            if( resendTime <= 0 ){
                                clearInterval( resendTimer );
                                // $timer.empty().append('<a href="#" class="resend_otp_sms">ارسال مجدد</a>');
                                // $resendLink.removeClass('disabled');
                                $timer.html('');
                                $timer.append('<a href="javascript:void(0);" class="resend_otp_sms" data-type_value="email">ارسال مجدد</a>');
                            }
                            resendTime--;

                        },1000);
                        $timer.attr('data-timer_time',resendTimer);

                    }

                    $register_otp_form.show();
                    $register_otp_form.append('<input name="username_sended" type="hidden" value="'+$value+'">');
                }

                if( 'mobile' === response.status )
                {
                    var $form_otp = $parents.find('.login_register_otp');
                    $form_otp.find('.msg_detail_number').append(response.msg)
                    
                    var resendTime      = parseInt( optionarray.wating_time_resend_otp );
                    var $timer          = $form_otp.find('.time_resend');
                    
                    if( resendTime > 0 ) {
                        
                        var resendTimer;
                        clearInterval( resendTimer );
                        
                        resendTimer = setInterval(function(){

                            $timer.html('('+resendTime+') ثانیه');
                            
                            if( resendTime <= 0 ){
                                clearInterval( resendTimer );
                                // $timer.empty().append('<a href="#" class="resend_otp_sms">ارسال مجدد</a>');
                                // $resendLink.removeClass('disabled');
                                $timer.html('');
                                $timer.append('<a href="javascript:void(0);" class="resend_otp_sms" data-type_value="mobile" >ارسال مجدد</a>');
                            }
                            resendTime--;

                        },1000);
                        $timer.attr('data-timer_time',resendTimer);

                    }

                    $form_otp.show();
                    $form_otp.append('<input name="username_sended" type="hidden" value="'+$value+'">');
                }
            },
            error:function( error )
            {
                btn.removeClass('loading');
                btn.html(text_btn);
                
                if( 'error' === error.responseJSON.status )
                {
                    $this.find('.login_register__description').after(show_alert_message( error.responseJSON.msg,error.responseJSON.status ));

                    setTimeout(function(e){
                        $('body').find('.alert_message').remove();
                    },3000);
                    
                    if ( optionarray.captcha_is_enable ) {
                        if (!window.grecaptcha) {
                        } else {
                            grecaptcha.reset();
                        }
                    }
                }
            }
        });
    });

    $('body').on('submit','.form_login_email',function(e){
        e.preventDefault();
        var $this = $(this);
        var $password = $this.find('input[name="password"]').val();
        var $nonce = $this.find('.nonce_login_email').val();
        var $value = $this.find('input[name="username_sended"]').val();

        var btn = $this.find('.login_register__submitbtn');
        btn.addClass('loading');
        var text_btn = btn.html();
        btn.empty();
      
        $.ajax({
            type: 'POST',dataType :'json', url: optionarray.woodplus_url,
            data : {
                action : 'email_or_account_login',
                nonce : $nonce,
                value : $value,
                password : $password
            },
            success:function(response)
            {
                btn.removeClass('loading');
                btn.html(text_btn);
                if( 'success' === response.status )
                {
                    $this.find('.login_register__description').after(show_alert_message( response.msg,response.status ));
                    window.location.href = optionarray.WcPage.myacc;
                }
            },
            error:function( error )
            {
                btn.removeClass('loading');
                btn.html(text_btn);
                if( 'error' === error.responseJSON.status )
                {
                    $this.find('.login_register__description').after(show_alert_message( error.responseJSON.msg,error.responseJSON.status ));

                    setTimeout(function(e){
                        $('body').find('.alert_message').remove();
                    },3000);
                    
                }
            }
        });

    });

  });

  function show_alert_message( $msg , $class )
  {
     return $('<div class="alert_message '+$class+'"> <i class="fa-light fa-square-exclamation"></i> '+$msg+' </div>');
  }

  async function copyToClipboard(text) {
    if (text === "") return;
    try {
      await navigator.clipboard.writeText(text);
    } catch (err) {
      console.error("Failed to copy: ", err);
    }
  }

  const btn_copy__codes = document.querySelectorAll(".btn_copy__code");

  const tabbar_buttons_container = document.querySelector(
    ".tabbar_container__buttons"
  );

  const tabbar_contents_container = document.querySelector(
    ".tabbar_container__contents"
  );

  const accordion_containers = document.querySelectorAll(".accordion_container");
  
  if (tabbar_buttons_container && tabbar_contents_container) {
    const tabbar_buttons = Array.from(tabbar_buttons_container.children);
    const tabbar_contents = Array.from(tabbar_contents_container.children);
    tabbar_buttons.forEach((button, index) => {
      const selectedTab = tabbar_contents[index];
      button.addEventListener("click", () => {
        tabbar_buttons.forEach((item) => item.classList.remove("show"));
        tabbar_contents.forEach((item) => item.classList.remove("show"));
        button.classList.add("show");
        selectedTab.classList.add("show");
      });
    });
  }

  if (accordion_containers.length > 0) {
    accordion_containers.forEach((menu) => {
      const btn_open = menu.querySelector(".accordion_button");
      btn_open.addEventListener("click", () => {
        menu.classList.toggle("opened");
      });
    });
  }
  
  if (btn_copy__codes.length > 0) {
    btn_copy__codes.forEach((button) => {
        const content = button.querySelector(".content");
        const status = button.querySelector('.status');
        button.addEventListener("click", () => {
        copyToClipboard(content.innerHTML)
        status.innerHTML = "کپی شد"
        button.classList.add('active');
        setTimeout(() => {
            status.innerHTML = "کپی کردن"
            button.classList.remove('active');
        }, 5000);
        });
    });
 }

 $('.dashboard_sidebar__container .btn_toggle__sidebar').click(function() {
    $('.dashboard_sidebar__container').toggleClass('opened');
    $('.dashboard_sidebar__container').find(".blob").toggleClass('d-none');
 });


  //new form login register
  $(document).ready(function(){

    $('.first_step').on('submit',function(e){
        e.preventDefault();
        var $this = $(this);
        var from_parent = $this.parents('.form-box');
        var $value = $this.find('.username').val();
        var $nonce = $(this).find('.nonce_login_register').val();

        var captcha_val = false;
        var $captcha = $(this).find('textarea[name="g-recaptcha-response"]');

        //otp form
        var form_otp = $('.step_otp');
        var parent_formotp = form_otp.parents('.form-box');

        if( optionarray.captcha_is_enable )
        {
            captcha_val = $captcha.val();
        }

        var passwod_form = $('.step_password');
        var password_from_parent = passwod_form.parents('.form-box');

        var register_form = $('.register_step');
        var parent_register_form = register_form.parents('.form-box');
        $this.find('.submit-btn').addClass('loading');
        $this.find('.submit-btn').attr('disabled',true);
        remove_show_password();
        $.ajax({
            type: 'POST',dataType :'json', url: optionarray.woodplus_url,
            data:{
                action:'login_register_together',
                value : $value,
                captcha : captcha_val,
                nonce : $nonce
            },
            success:function(response){

                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                if( 'register_mobile' === response.status || 'register_email' === response.status || 'login' === response.status )
                {
                    if( 'login' === response.status )
                    {
                        show_password(parent_formotp);
                        password_from_parent.find('.title_password').html(response.msg);
                    }

                    timer_resend(parent_formotp)
                    from_parent.hide();
                    parent_formotp.find('.title_otp').html(response.msg);
                    parent_formotp.show();
                    form_otp.attr('data-hashed',response.hashed);
                    back_to_start(parent_formotp,from_parent,response.back_to_start);
                    
                    return;
                }

                if( !response?.tooltip_text?.step )
                {
                    $('a.tooltip.go_to_otp_auth').remove();
                    $('a.tooltip.reset_pass').remove();
                }else{
                    $('a.tooltip.go_to_otp_auth').attr('data-tooltip',response.tooltip_text.send_otp);
                    $('a.tooltip.reset_pass').attr('data-tooltip',response.tooltip_text.reset_password);
                }
                
                from_parent.hide();
                password_from_parent.show();
                password_from_parent.find('.title_password').html(response.msg);
                passwod_form.find('.go_to_otp_auth').attr('data-hashed',response.hashed);
                show_alert(from_parent,response.msg,'success');
                back_to_start(password_from_parent,from_parent,response.back_to_start);
            },
            error : function(error){
                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);
                show_alert(from_parent,error.responseJSON.msg,'error');
            }
        });

    });

    $('.step_password').on('submit',function(e){
        e.preventDefault();
        var $this = $(this);
        var from_parent = $this.parents('.form-box');
        var $nonce = $this.find('.nonce_login_email').val();
        var $value = from_parent.find('.msg_strong').text();

        var $password = $this.find('.password').val();

        $this.find('.submit-btn').addClass('loading');
        $this.find('.submit-btn').attr('disabled',true);
  
        $.ajax({
            type: 'POST',dataType :'json', url: optionarray.woodplus_url,
            data : {
                action : 'email_or_account_login',
                nonce : $nonce,
                value : $value,
                password : $password
            },
            success: function(response){

                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                show_alert(from_parent,response.msg,'success');
                
                setTimeout(() => {
                    if( $('body.wdplus_is_checkout').length ){
                        window.location.href = optionarray.checkout_url;
                    }else{
                        window.location.href = response.redirect_url;
                    }
                }, 1000);
            },
            error : function(error){
                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                show_alert(from_parent,error.responseJSON.msg,'error');
            }
        });

    });

    var ajax_start = false;
    $('.go_to_otp_auth').on('click',function(e){
        e.preventDefault();
        if( ajax_start )
        {
            return;
        }

        var $this = $(this);
        var from  = $this.parents('.step_password');
        var parents = from.parents('.form-box');
        var $nonce = from.find('.nonce_login_email').val();
        var form_otp = $('.step_otp');
        var parent_otp = form_otp.parents('.form-box');
        var hashed = $this.attr('data-hashed');

        from.find('.submit-btn').addClass('loading');
        from.find('.submit-btn').attr('disabled',true);
        $this.attr('disabled',true);
        ajax_start = true;
        $.ajax({
            type: 'POST',dataType :'json', url: optionarray.woodplus_url,
            data : {
                action : 'send_otp',
                nonce : $nonce,
                hashed_data : hashed
            },
            success : function(response)
            {
                from.find('.submit-btn').removeClass('loading');
                from.find('.submit-btn').attr('disabled',false);
                $this.attr('disabled',false);
                form_otp.attr('data-hashed',response.hashed);
                from.parents('.form-box').hide();
                parent_otp.show();
                timer_resend(parent_otp);
                parent_otp.find('.title_otp').html(response.msg);
                ajax_start = false;
                back_to_start(parent_otp,$('body .first_step'),response.back_to_start)
            },
            error : function(error){
                from.find('.submit-btn').removeClass('loading');
                from.find('.submit-btn').attr('disabled',false);
                $this.attr('disabled',false);
                show_alert(parents,error.responseJSON.msg,'error');
                ajax_start = false;
                back_to_start(parent_otp,$('body .first_step'))
            }
        });
        
        
    });

    $('.step_otp').on('submit',function(e){

        e.preventDefault();
        var $this = $(this);
        var parent_otp = $this.parents('.form-box');
        var hashed = $this.attr('data-hashed');
        var $nonce = $(this).find('.nonce_verify_otp').val();
        var otp = '';
        
        //register
        var register_form = $('.register_step');
        var parent_register_form = register_form.parents('.form-box');
        
        $this.find('.otp-input').each( function( index, input ){
            
            otp += $(this).val();
        });

        otp = toEnglishDigits(otp);
        
        $this.find('.submit-btn').addClass('loading');
        $this.find('.submit-btn').attr('disabled',true);
        $.ajax({
            dataType: 'json', type:'post', url: optionarray.woodplus_url,
              data:{
                  action: 'verify_otp',
                  otp_sended : otp,
                  hashed : hashed,
                  nonce_verify_otp: $nonce
              },
              success: function(response){

                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);
                 if('register' === response.step)
                 {
                    if( 'email' === response.register )
                    {
                        register_form.find('.email_here').empty();
                        $(`${'<input type="text" id="phone" name="phone" required autocomplete="off"><label for="phone">شماره موبایل</label><svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M5 4H9L11 9L8.5 10.5C9.57096 12.6715 11.3285 14.429 13.5 15.5L15 13L20 15V19C20 19.5304 19.7893 20.0391 19.4142 20.4142C19.0391 20.7893 18.5304 21 18 21C14.0993 20.763 10.4202 19.1065 7.65683 16.3432C4.8935 13.5798 3.23705 9.90074 3 6C3 5.46957 3.21071 4.96086 3.58579 4.58579C3.96086 4.21071 4.46957 4 5 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /> </svg></div>'}`).appendTo('.email_here');
                    }
                    parent_otp.hide();
                    register_form.attr('data-hashed',response.hashed);
                    parent_register_form.show();
                    return;
                 }

                 if( 'rest_pass'=== response.step )
                 {
                    parent_otp.hide();
                    const from_rest_pass = $('.reset_password');
                    const parent_rest_pass = from_rest_pass.parents('.form-box');
                    from_rest_pass.attr('data-hashed',response.hashed);
                    parent_rest_pass.show();
                    return;
                 }
                 
                show_alert(parent_otp,response.msg,'success');

                setTimeout(() => {
                    if( $('body.wdplus_is_checkout').length ){
                        window.location.href = optionarray.checkout_url;
                    }else{
                        window.location.href = response.redirect_url;
                    }
                    
                }, 1000);

              },
              error : function(error){

                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                show_alert(parent_otp,error.responseJSON.msg,'error');
              },
        });
    });

    var isAjaxLoading = false;
    $('.reset_pass').on('click',function(e){
        e.preventDefault();

        if (isAjaxLoading) {
            return; 
        }
        var $this = $(this);
        var parent = $this.parents('.step_password');
        var parents = parent.parents('.form-box');
        var hashed = parent.find('.go_to_otp_auth').attr('data-hashed');

        var form_otp = $('.step_otp');
        var parent_otp = form_otp.parents('.form-box');
        
        parent.find('.submit-btn').addClass('loading');
        parent.find('.submit-btn').attr('disabled',true);

        isAjaxLoading = true;
        $.ajax({
            dataType: 'json', type:'post', url: optionarray.woodplus_url,
              data:{
                  action: 'lets_reset_password',
                  hashed : hashed,
                  nonce_lets_reset : optionarray.nonce
              },
              success: function(response){
              
                parent.find('.submit-btn').removeClass('loading');
                parent.find('.submit-btn').attr('disabled',false);
                
                form_otp.attr('data-hashed',response.hashed);
                parent.parents('.form-box').hide();
                parent_otp.show();
                timer_resend(parent_otp);
                parent_otp.find('.title_otp').html(response.msg);
                isAjaxLoading = false;
              },
              error : function(error){
                
                parent.find('.submit-btn').removeClass('loading');
                parent.find('.submit-btn').attr('disabled',false);

                show_alert(parents,error.responseJSON.msg,'error');
                isAjaxLoading = false;
              },
        });

    });

    $('.reset_password').on('submit',function(e){
        e.preventDefault();
        var $this = $(this);
        var newpassword = $this.find('.newpassword').val();
        var repatpassword = $this.find('.repeatpassword').val();
        var parent = $this.parents('.form-box');

        if( newpassword !== repatpassword )
        {
            return show_alert(parent,'رمزعبور یکسان نیست','error');
        }

        if(newpassword.length < 6) 
        {
            return show_alert(parent,'رمز عبور نمیتواند کوچک تر از 6 رقم باشد','error');
        }

        var nonce_reset_password = $this.find('.nonce_reset_password').val();
        var hashed = $this.attr('data-hashed');

        $this.find('.submit-btn').addClass('loading');
        $this.find('.submit-btn').attr('disabled',true);

        $.ajax({
            dataType: 'json', type:'post', url: optionarray.woodplus_url,
              data:{
                  action: 'reset_password',
                  hashed : hashed,
                  nonce_reset_password: nonce_reset_password,
                  newpassword : newpassword
              },
              success: function(response){

                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                show_alert(parent,response.msg,'success');

                setTimeout(() => {
                    if( $('body.wdplus_is_checkout').length ){
                        window.location.href = optionarray.checkout_url;
                    }else{
                        window.location.href = response.redirect_url;
                    }
                    
                }, 1000);
              },
              error : function(error){
                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);
                show_alert(parent,error.responseJSON.msg,'error');
              },
        });
   });
   
   $('.register_step').on('submit',function(e){
        e.preventDefault();
        var $this = $(this);
        var parent = $this.parent('.form-box');
        var username = $this.find('.user_name').val();
        var email = $this.find('.email').val();
        var phone = $this.find('#phone').val();
        var birth_day = $this.find('#birth_day').val();
        var newpassword = $this.find('.new_password').val();
        var repatpassword = $this.find('.repate_password').val();
        var nonce_register_form = $this.find('.nonce_form_register').val();
        var hashed = $this.attr('data-hashed');

        var isValid = /^[a-zA-Z0-9_]+$/.test(username); 

        if( !isValid )
        {
            return show_alert(parent,optionarray.errors.latinUsername,'error');
        }

        if( newpassword !== repatpassword )
        {
            return show_alert(parent,optionarray.errors.passwordNotSame,'error');
        }
        
        if(newpassword.length < 6) 
        {
            return show_alert(parent,optionarray.errors.passwordLessThan,'error');
        }

        $this.find('.submit-btn').addClass('loading');
        $this.find('.submit-btn').attr('disabled',true);

        $.ajax({

            dataType: 'json', type:'post', url: optionarray.woodplus_url,
              data:{
                  action: 'register_form',
                  hashed : hashed,
                  nonce_register_form: nonce_register_form,
                  username : username,
                  email : email,
                  phone : phone,
                  password : newpassword,
                  birth_day : birth_day
              },
              success:function(response){

                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                show_alert(parent,response.msg,'success');
                
                setTimeout(() => {
                    if( $('body.wdplus_is_checkout').length ){
                        window.location.href = optionarray.checkout_url;
                    }else{
                        window.location.href = response.redirect_url;
                    }
                }, 1000);
        
              },
              error : function(error){
                $this.find('.submit-btn').removeClass('loading');
                $this.find('.submit-btn').attr('disabled',false);

                show_alert(parent,error.responseJSON.msg,'error');
              }
        });
   });

   if( $('#birth_day').length )
    {
        $("#birth_day").on("change", function () {
                if ($(this).val().trim() !== "") {
                $(this).addClass("has-value");
            } else {
                $(this).removeClass("has-value");
            }
        });

        if ($("#birth_day").val().trim() !== "") {
            $("#birth_day").addClass("has-value");
        }
        kamaDatepicker('birth_day',
            {
                twodigit : false
            }
        );
    }
  });

  function toEnglishDigits(str) {
    return str
        .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
        .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
 }

 function back_to_start($current,$back,$text)
 {
    $('body').find('.back_to_start').text($text);

    $('body').on('click','.back_to_start',function(){
        let $this = $(this);
        let current = $this.parents('.form-box');

        var alert =  $back.find('.alert');

        if( alert.length )
        {
            alert.hide();
        }
        current.hide();

        $back.show();
    });
 }

  function timer_resend( $form_otp )
  {
      var resendTime      = parseInt( optionarray.wating_time_resend_otp );
      var $timer          = $form_otp.find('.timer');
      
      if( resendTime > 0 ) {
          
          var resendTimer;

          clearInterval( resendTimer );
          
          resendTimer = setInterval(function(){

            if( !$timer.find('#countdown').length )
            {
                $timer.html(optionarray.resend_text+' <span id="countdown"></span>');
            }
              $timer.find('#countdown').html('('+resendTime+') ثانیه');
              
              if( resendTime <= 0 ){
                  clearInterval( resendTimer );
                  $timer.html('');
                  $timer.append('<a href="javascript:void(0);" class="resend_otp_sms" data-type_value="mobile" >ارسال مجدد</a>');
              }
              resendTime--;

          },1000);
          $timer.attr('data-timer_time',resendTimer);
      }
  }

  function show_alert( form,msg,type )
  {
    var alert =  form.find('.alert');
    var msg_box = alert.find('.alert_msg');

    if( type == 'error' )
    {
        msg_box.html(msg);    
        alert.addClass('alert-error');
        alert.show();

    }

    if( type === 'success' )
    {
        msg_box.html(msg);    
        alert.addClass('alert-success');
        alert.show();
    }
    setTimeout(function(){
        if( alert.hasClass('alert-error') ){
            alert.removeClass('alert-error');
        }
        if( alert.hasClass('alert-success') ){
            alert.removeClass('alert-success');
        }
        alert.hide();
    },3000);
      
  }

  function show_password($need_to_append)
  {
    
     $need_to_append.find('.extra-links').append('<a href="#" class="show_password" onclick="event.preventDefault();">'+optionarray.login_whit_password+'</a>');

     $('body').on('click','.show_password',function(){
        let password_step = $('.step_password').parent('.form-box');
        password_step.find('.go_to_otp_auth').remove();
        password_step.show();

        $(this).parents('.form-box').hide();
     });
  }
  function remove_show_password()
  {
    $('body').find('.extra-links .show_password').remove();
  }
  //checkout fixed

    if( $('body.wdplus_is_checkout').length )
    {
    
        let login_register_wd = $('.wd-dropdown-register');
        let login_register_wd_side = $('.login-form-side');
        let wd_button_login = $('.wd-header-my-account');

        if( login_register_wd.length || login_register_wd_side.length )
        {
            login_register_wd.remove();
            login_register_wd_side.remove();
            wd_button_login.removeClass('wd-with-overlay');
        }
    }
  
})( jQuery );

function onloadCallbackCaptcha()
{
   if( optionarray.captcha_is_enable )
   {
       if (!window.grecaptcha) {
       } else {
           setTimeout(function(){
               var recaptchas = document.getElementsByClassName("ga-recaptcha");
               for(var i=0; i<recaptchas.length; i++) {
                   var recaptcha = recaptchas[i];
                   var sitekey = recaptcha.dataset.sitekey;

                   grecaptcha.render(recaptcha, {
                       'sitekey' : sitekey
                   });
               }
           }, 500);
       }
   }
}


function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
  
  // Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
}
