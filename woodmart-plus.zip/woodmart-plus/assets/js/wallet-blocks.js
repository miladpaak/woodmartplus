registerPaymentMethod( {
    name: 'wc_wallet_gateway',
    label: wp.i18n.__( 'پرداخت با کیف پول', 'woodmartplus' ),
    content: <p>{ wp.i18n.__( 'پرداخت سریع از موجودی کیف پول شما.', 'woodmartplus' ) }</p>,
    edit: <p>{ wp.i18n.__( 'پرداخت سریع از موجودی کیف پول شما.', 'woodmartplus' ) }</p>,
    canMakePayment: () => true,
    ariaLabel: wp.i18n.__( 'پرداخت با کیف پول', 'woodmartplus' ),
    supports: {
        features: [ 'products' ]
    }
});