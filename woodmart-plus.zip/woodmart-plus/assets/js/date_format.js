(function($){

    $(document).ready(function(e){

        $('.wc_extra_field.wc_extra_field_date input[type="text"]').each(function(index,element){

            if( optionDate.is_garegorian )
            {
                $(element).datepicker({
                    dateFormat: "DD d MM yy",
                    minDate: 0
                });
            }else{
                $(element).persianDatepicker({
                    formatDate: "ND DD NM YYYY", 
                    startDate: "today",
                    endDate: new Date().toISOString()
                })
            }
        });
    });

})( jQuery );