(function($){

    $(document).ready(function(){

        $('body').on('click','.get-prefactor',function(e){
            e.preventDefault();
            let $btn = $(this);
            let originalText = $btn.html();
            $btn.html('<i class="fa fa-spinner fa-spin"></i> در حال پردازش...');
            $btn.prop('disabled', true);

            $.ajax({
                dataType : 'json', type : 'POST' , url : preFactorScript.ajaxUrl,
                data:{
                    action : 'start_pre_factor',
                    nonceF : preFactorScript.nonceF
                },
                success:function(response){
                    window.open(response.pre_factor_url, '_blank');

                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                },
                error : function(error)
                {
                    console.log( error );
                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                }
            });
        });
        

    });
    
})(jQuery);