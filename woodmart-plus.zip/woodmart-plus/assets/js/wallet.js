(function($){


     $(document).ready(function(e){
        
        
        $('.woocommerce-checkout').on('change','.wallet_calc input[type="checkbox"]',function(e){

            var $this = $(this);

            $.ajax({
                type: 'POST', dataTye : 'json', url: walletDep.ajaxUrl,
                data:{
                    action: 'calc_wallet',
                    'is_checked': $this.is(':checked')
                },
                success: function(response){

                    
                    if( response.status )
                    {
                        $(document.body).trigger('update_checkout');
                    }
                },
                error : function(response){},
            });
        });

        
    });

 

})( jQuery );