<?php
    if( !defined('ABSPATH') ) exit;
?>

<div class="popup-overlay" id="popupOverlay"></div>

<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-content">
        <div class="loading-spinner"></div>
        <p class="loading-message" id="loadingMessage"><?php esc_html_e( 'در حال ایجاد طرح...', 'woodmartplus' ); ?></p>
    </div>
</div>

<div class="popup-modal" id="popupModal">
    <div class="popup-header">
        <h2><?php esc_html_e( 'ایجاد طرح المنتوری جدید', 'woodmartplus' ); ?></h2>
        <button class="close-popup-btn" id="closePopupBtn">&times;</button>
    </div>
    
    <div class="popup-body">
        <div class="form-group">
            <label for="templateType"><?php esc_html_e( 'نوع طرح *', 'woodmartplus' ); ?></label>
            <select id="templateType" name="templateType" required>
                <option value=""><?php esc_html_e( '-- انتخاب کنید --', 'woodmartplus' ); ?></option>
                <?php foreach( $types as $type_key => $type_value ): ?>
                    <option value="<?php echo esc_attr( $type_key ); ?>"><?php echo esc_html( $type_value ); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="templateName"><?php esc_html_e( 'نام طرح *', 'woodmartplus' ); ?></label>
            <input type="text" id="templateName" name="templateName" placeholder="<?php esc_html_e( 'مثال: صفحه جزئیات محصول شماره 1', 'woodmartplus' ); ?>" required>
        </div>

        <div class="templates-section" id="templatesSection">
            <div class="form-group">
                <label><?php esc_html_e( 'طرح های از پیش تعریف شده', 'woodmartplus' ); ?></label>
                <div class="templates-grid" id="templatesGrid">
                </div>
            </div>
        </div>
    </div>

    <div class="popup-footer">
        <button type="button" class="btn btn-secondary" id="cancelBtn"><?php esc_html_e( 'انصراف', 'woodmartplus' ); ?></button>
        <button type="button" class="btn btn-primary" id="submitBtn"><?php esc_html_e( 'ایجاد طرح', 'woodmartplus' ); ?></button>
    </div>
</div>