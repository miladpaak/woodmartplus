<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن چت بات', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('فعال سازی سیستم چت بات', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_ai_chabot_system]'); ?>" <?php echo wplus_helper::show_value('enable_ai_chabot_system', false) ? 'checked' : '' ?> data-condition="chatbot-start-rag">
   </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php esc_html_e('عنوان ابتدای گفتگو', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('عنوان ابتدای صفحه گفته برای مثال : پشتیبانی انلاین','woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[ai_chatbot_title]'); ?>" value="<?php wplus_helper::show_value('ai_chatbot_title'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php esc_html_e('نام هوش مصنوعی', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('با چه نامی گفتگو انجام شود ؟ برای مثال : دستیار سایت','woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[ai_chatbot_name]'); ?>" value="<?php wplus_helper::show_value('ai_chatbot_name'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('متن پیشفرض در صفحه گفت گو', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('زمان باز شدن گفتگو یک متن پیشفرض و قبل از شروع گفتگو میتوانید قرار دهید' , 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[ai_chatbot_description]'); ?>"><?php wplus_helper::show_value('ai_chatbot_description') ?? ''; ?></textarea>
   </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php esc_html_e('متن اینپوت ورودی', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('متن اینپوت ورودی ، برای مثال : پیام خود را بنویسید','woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[ai_chatbot_input]'); ?>" value="<?php wplus_helper::show_value('ai_chatbot_input'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('دستور العمل و قوانین سیستم (system instruction)', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('در این قسمت میتوانید قوانین خود را قرار دهید که همراه با اطلاعات برای هوش مصنوعی ارسال میشود ، برای مثال لحن خوبی داشته باش و...' , 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[ai_chatbot_system_instruction]'); ?>"><?php wplus_helper::show_value('ai_chatbot_system_instruction') ?? ''; ?></textarea>
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('محدودیت های ارسال پیام', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('این محدودیت ها بر روی IP کاربر ثبت میشود', 'woodmartplus'); ?></p>
   <div class="progress-wrapper br-radius-8 m-t-18">
      <div class="progress-content">
         <div class="progress-bar-left">
            <p><?php esc_html_e('چند پیام برای هر IP', 'woodmartplus') ?></p>
            <div class="inp-rang p-top-18">
               <input type="range" class="rang" min="1" max="5000" value="<?php wplus_helper::show_value('ai_chatbot_number_sent_message'); ?>" name="<?php echo wplus_helper::generate_option('[ai_chatbot_number_sent_message]'); ?>">
               <div class="br-radius-8 rang-number d-center">
                  <span class="num">1200</span><span class="text-num"><?php esc_html_e('تعداد', 'woodmartplus'); ?></span>
               </div>
            </div>
         </div>
         <div class="progress-bar-right">
            <p><?php esc_html_e('مدت زمان بلاک برای هر IP', 'woodmartplus'); ?></p>
            <div class="inp-rang p-top-18">
               <input type="range" class="rang" min="1" max="5000" value="<?php wplus_helper::show_value('ai_chatbot_ban_userip'); ?>" name="<?php echo wplus_helper::generate_option('[ai_chatbot_ban_userip]'); ?>">
               <div class="br-radius-8 rang-number d-center">
                  <span class="num">1200</span><span class="text-num"><?php esc_html_e('دقیقه', 'woodmartplus'); ?></span>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="item p-top-18 offer_section">
   <span class="title"><?php esc_html_e('سوالات آماده','woodmartplus') ?></span>
   <p class="des"><?php esc_html_e('اضافه کردن سوالات اماده برای چت بات','woodmartplus'); ?></p>
      <section class="repeater-sections-slider-images add-suggestions m-t-18"  >
            <div class="br-radius-8 opened">
               <div class="suggestion-title">
                  <span class="suggestion-menu">
                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/menu.svg" alt="">
                        <p><?php esc_html_e('سوالات','woodmartplus'); ?></p>
                  </span>
                  <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
               </div>
            
                  <div data-repeater-list="<?php echo wplus_helper::generate_option('[chatbot_pre_question_answer]'); ?>" >
                        <?php foreach( wplus_helper::get_setting( 'chatbot_pre_question_answer',[
                              'default_slider' => [
                                 'question' => '',
                                 'answer' => '',
                              ]
                        ] ) as $question_answer ): ?>
                           <div class="suggestion-content" data-repeater-item>
                              <div class="suggestion-inputs">
                                 <div>
                                    <input type="text" name="question" id="" placeholder="<?php esc_html_e('سوال','woodmartplus'); ?>" value="<?php echo $question_answer['question'] ?>">
                                 </div>
                                 <div>
                                    <textarea name="answer" placeholder="<?php esc_html_e('پاسخ','woodmartplus'); ?>" id=""><?php echo $question_answer['answer'] ?></textarea>
                                 </div>
                                 <div class="suggestion-btns">
                                       <input class="delete-btn" data-repeater-delete type="button" value="<?php esc_html_e('حذف سوال','woodmartplus') ?>" >
                                 </div>
                              </div>
                              
                           </div>
                        <?php endforeach; ?>
                  </div>
                  <input class="add-btn blue-btn m-t-18" style="display:inline-block" data-repeater-create type="button" value="<?php esc_html_e('افزودن سوال','woodmartplus') ?>" >
            </div>
      </section>
</div>