<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن موجود شد خبرم کن', 'woodmartplus'); ?></span> 
   <p class="des"><?php esc_html_e('با فعال کردم این ویژگی ،در صفحه جزئیات هر محصول که ناموجود هست ، دکمه (موجود شد خبرم کن) نمایش داده خواهد شد', 'woodmartplus'); ?></p>  
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_waitlist]'); ?>" <?php echo wplus_helper::show_value('enable_waitlist', false) ? 'checked' : '' ?> data-condition="enable_waitlist">
   </div>
</div>


<div class="item br-bottom p-18 enable_waitlist">
    <span class="title"><?php echo esc_html_e('متن دکمه', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('متن دکمه خبرم کن در صفحه محصول', 'woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[waitlist_button_title]'); ?>" value="<?php wplus_helper::show_value('waitlist_button_title'); ?>">
    </div>
</div>
<?php $waitlist = wplus_helper::get_setting('waitlist', []); ?>
<div class="item">
    <div class="manager-sms-wrapper">
        <div class="br-bottom" style="padding-bottom: 18px;">
            <div class="sms-sent-post m-t-18">
                <div class="short-code-text">
                    <span class="title"><?php esc_html_e('متن پیامک موجود شد','woodmartplus') ?></span>
                    <p class="des"><?php esc_html_e('می توانید از این شورت کد ها در متن پیامک استفاده کنید','woodmartplus') ?></p>
                </div>
                <div class="sms-sent-post-detailes br-radius-8">
                    <p>[shop_name] = نام فروشگاه</p>
                    <p>[full_name] = نام و نام خانوادگی</p>
                    <p>[product_name] = نام محصول</p>
                    <p>[coupon_code] = کدتخفیف</p>
                    <p>[product_link] = لینک محصول</p>
                </div>
            </div>

            <div class="add-suggestions open_acard opened" style="margin-top:20px;">
                <div class="suggestion-title">
                    <span class="suggestion-menu">
                        <p><?php esc_html_e('متن پیامک موجود شد', 'woodmartplus'); ?></p>
                    </span>
                    <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
                </div>
                <div class="suggestion-content">
                    <div class="suggestion-inputs gray-inp">
                        <!-- Pattern Input -->
                        <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                            <input type="text" name="<?php echo wplus_helper::generate_option('[waitlist][pattern]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($waitlist['pattern']) && !empty($waitlist['pattern']) ? esc_html($waitlist['pattern']) : '' ?>">
                        </div>
                        <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                            <input type="text" name="<?php echo wplus_helper::generate_option('[waitlist][coupon]'); ?>" placeholder="<?php esc_html_e('اگر از شورتکد کد تخفیف در متغییر ها استفاده شد ، کد تخفیف خود را در این قسمت قرار دهید', 'woodmartplus'); ?>" value="<?php echo isset($leave_cart['coupon']) && !empty($leave_cart['coupon']) ? esc_html($leave_cart['coupon']) : '' ?>">
                        </div>
                        <!-- Variables Repeater -->
                        <div class="repeater-container">
                            <div data-repeater-list="<?php echo wplus_helper::generate_option('[waitlist][variables]'); ?>">
                                <?php if (isset($waitlist['variables']) && !empty($waitlist['variables'])) : ?>
                                    <?php foreach ($waitlist['variables'] as $key => $value) : ?>

                                        <div data-repeater-item>
                                            <div class="send-time">
                                                <div>
                                                    <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                    <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                    <a data-repeater-delete class="delete-btn">
                                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر','woodmartplus') ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد','woodmartplus') ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="add-time">
                                <button data-repeater-create type="button">
                                    <p><?php esc_html_e('افزودن متغیر جدید','woodmartplus') ?></p>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>