
<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('متای کی موبایل', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('.نام  متاکی،  که شماره موبایل با آن در دیتابیس ذخیره شده (در پلاگین های قبلی)', 'woodmartplus'); ?></p>
   <p class="des"><?php esc_html_e('هر متا را با (,) جدا کنید.', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea placeholder="<?php esc_html_e('برای مثال : _woodmartplus,digits_phone_no') ?>" name="<?php echo wplus_helper::generate_option('[phone_meta_compatible]'); ?>"><?php wplus_helper::show_value('phone_meta_compatible') ?? ''; ?></textarea>
   </div>

   <p><?php esc_html_e('با این روش شما میتوانید ، کاربرانی که از قبل در وبسایت شما با پلاگین های دیگیری ثبت نام کرده اند ، با ثبت نام ورود وودمارت پلاس هم امکان ورود داشته باشند','woodmartplus') ?></p>
</div>