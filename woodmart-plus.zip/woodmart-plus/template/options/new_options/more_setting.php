<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('فعال کردن دسته بندی ویژگی های محصول', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('با فعال کردن این گزینه ، شما زمانی ساخت محصول میتوانید برای هر ویژگی دسته بندی خود را انتخاب کنید', 'woodmartplus'); ?></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_group_attr]'); ?>" <?php echo wplus_helper::show_value('enable_group_attr', false) ? 'checked' : '' ?>>
    </div>
</div>