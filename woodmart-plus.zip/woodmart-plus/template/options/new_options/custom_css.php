<?php $custom_css = wplus_helper::get_setting('wplus_custom_css'); ?>
<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('Css سفارشی', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('اضافه کردن کد CSS سفارشی', 'woodmartplus') ?></p>
    <p class="des"><?php esc_html_e('توجه داشته باشید ، که این Css ها صرفا در برگه حساب کاربری خود را نمایش می دهد', 'woodmartplus') ?></p>
    <div class="custom-css-panel br-radius-8">
        <textarea name="<?php echo wplus_helper::generate_option('[wplus_custom_css]'); ?>" id="wplus_custom_css" rows="10" placeholder="<?php esc_attr_e('استایل های خود را در این قسمت وارد کنید', 'woodmartplus'); ?>"><?php echo isset($custom_css) && !empty($custom_css) ? esc_textarea($custom_css) : ''; ?></textarea>
    </div>
</div>
<style>
    
</style>