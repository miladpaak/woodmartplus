<?php $notif_customer = wplus_helper::get_setting('notif_customer', []); ?>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('فعال کردن اعلان سفارش مشتری', 'woodmartplus'); ?></span>
    <p class="des"></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable-order-notification-customer]'); ?>" <?php echo wplus_helper::show_value('enable-order-notification-customer', false) ? 'checked' : '' ?>>
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php esc_html_e('انتخاب وضعیت های ارسال پیامک', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('انتخاب کنید که در کدام یک از وضعیت های زیر پیامک ارسال شود.', 'woodmartplus'); ?></p>
    <div class="select-sms-setting">
        <div>
            <input type="checkbox" id="Immediately_purchase-cust-customer" class="customer-" name="<?php echo wplus_helper::generate_option('[notif_customer][pending_now]'); ?>" <?php echo isset($notif_customer['pending_now']) && !empty($notif_customer['pending_now']) ? 'checked' : '' ?>>
            <label for="Immediately_purchase-cust-customer"><?php esc_html_e('(بلافاصله بعد از خرید) در انتظار پرداخت', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="awaiting_payment_cust-customer" name="<?php echo wplus_helper::generate_option('[notif_customer][pending]'); ?>" <?php echo isset($notif_customer['pending']) && !empty($notif_customer['pending']) ? 'checked' : '' ?>>
            <label for="awaiting_payment_cust-customer"><?php esc_html_e('در انتظار پرداخت', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="in_progress_cust-customer" name="<?php echo wplus_helper::generate_option('[notif_customer][processing]'); ?>" <?php echo isset($notif_customer['processing']) && !empty($notif_customer['processing']) ? 'checked' : '' ?>>
            <label for="in_progress_cust-customer"><?php esc_html_e('در حال انجام', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="awaiting_review_customer" name="<?php echo wplus_helper::generate_option('[notif_customer][on-hold]'); ?>" <?php echo isset($notif_customer['on-hold']) && !empty($notif_customer['on-hold']) ? 'checked' : '' ?>>
            <label for="awaiting_review_customer"><?php esc_html_e('در انتظار بررسی', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="completed_status_customer" name="<?php echo wplus_helper::generate_option('[notif_customer][completed]'); ?>" <?php echo isset($notif_customer['completed']) && !empty($notif_customer['completed']) ? 'checked' : '' ?>>
            <label for="completed_status_customer"><?php esc_html_e('تکمیل شده', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="canceled_status_customer" name="<?php echo wplus_helper::generate_option('[notif_customer][cancelled]'); ?>" <?php echo isset($notif_customer['cancelled']) && !empty($notif_customer['cancelled']) ? 'checked' : '' ?>>
            <label for="canceled_status_customer"><?php esc_html_e('لغو شده', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="returned_status_customer" name="<?php echo wplus_helper::generate_option('[notif_customer][refunded]'); ?>" <?php echo isset($notif_customer['refunded']) && !empty($notif_customer['refunded']) ? 'checked' : '' ?>>
            <label for="returned_status_customer"><?php esc_html_e('مسترد شده', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="unsuccessful-conditions_customer" name="<?php echo wplus_helper::generate_option('[notif_customer][failed]'); ?>" <?php echo isset($notif_customer['failed']) && !empty($notif_customer['failed']) ? 'checked' : '' ?>>
            <label for="unsuccessful-conditions_customer"><?php esc_html_e('ناموفق', 'woodmartplus'); ?></label>
        </div>
        <div>
            <input type="checkbox" id="draft_sms_customer" name="<?php echo wplus_helper::generate_option('[notif_customer][checkout-draft]'); ?>" <?php echo isset($notif_customer['checkout-draft']) && !empty($notif_customer['checkout-draft']) ? 'checked' : '' ?>>
            <label for="draft_sms_customer"><?php esc_html_e('پیشنویس', 'woodmartplus'); ?></label>
        </div>
    </div>
</div>

<div class="item">
    <div class="manager-sms-wrapper">
        <div class="short-code br-bottom p-18">
            <div class="short-code-text">
                <span class="title"><?php esc_html_e('شورت کد های قابل استفاده', 'woodmartplus'); ?></span>
                <p class="des"><?php esc_html_e('می توانید از این شورت کد ها در متن پیامک استفاده کنید', 'woodmartplus'); ?></p>
            </div>
            <div class="short-code-detailes br-radius-8">
                <p>
                    <?php esc_html_e('جزییات سفارش:', 'woodmartplus'); ?> <br>
                    <?php esc_html_e('نام فروشگاه', 'woodmartplus'); ?> = [shop_name]    <br>
                    <?php esc_html_e('شماره تلفن مشتری', 'woodmartplus'); ?> = [billing_phone]    <br>
                    <?php esc_html_e('ایمیل مشتری', 'woodmartplus'); ?> = [billing_email] <br>
                    <?php esc_html_e('وضعیت سفارش', 'woodmartplus'); ?> = [billing_status] <br>
                    <?php esc_html_e('محصولات سفارش', 'woodmartplus'); ?> = [billing_items] <br>
                    <?php esc_html_e('محصولات سفارش بهمراه تعداد', 'woodmartplus'); ?> = [billing_all_items_qty] <br>
                    <?php esc_html_e('تعداد محصولات سفارش', 'woodmartplus'); ?> = [billing_count_items] 
                </p>
                <br>
                <p> 
                <?php esc_html_e('مبلغ سفارش بدون احتساب مالیات و حمل و نقل و...', 'woodmartplus'); ?> = [billing_price] <br> 
                <?php esc_html_e('مبلغ کل سفارش', 'woodmartplus'); ?> = [billing_price_total] <br> 
                <?php esc_html_e('شماره سفارش', 'woodmartplus'); ?> = [billing_order_id] <br>
                    <?php esc_html_e('تاریخ سفارش', 'woodmartplus'); ?> = [billing_date] <br> 
                    <?php esc_html_e('توضیحات مشتری', 'woodmartplus'); ?> = [billing_customer_not] <br>
                    <?php esc_html_e('روش پرداخت', 'woodmartplus'); ?> = [billing_payment_method] <br> 
                    <?php esc_html_e('روش ارسال', 'woodmartplus'); ?> = [billing_shipping_method] </p>
                <br>
                <p><?php esc_html_e('جزییات صورت حساب :', 'woodmartplus'); ?><br>
                    <?php esc_html_e('نام مشتری', 'woodmartplus'); ?> = [billing_first_name] <br>
                    <?php esc_html_e('نام خانوادگی مشتری', 'woodmartplus'); ?> = [billing_last_name] <br>
                    <?php esc_html_e('نام شرکت', 'woodmartplus'); ?> = [billing_company] <br> 
                    <?php esc_html_e('کشور', 'woodmartplus'); ?> = [billing_country] <br>
                    <?php esc_html_e('استان', 'woodmartplus'); ?> = [billing_state] <br>
                    <?php esc_html_e('شهر', 'woodmartplus'); ?> = [billing_city] <br>
                    <?php esc_html_e('آدرس 1', 'woodmartplus'); ?> = [billing_address_1] <br>
                    <?php esc_html_e('آدرس 2', 'woodmartplus'); ?> = [billing_address_2] <br>
                    <?php esc_html_e('کد پستی', 'woodmartplus'); ?> = [billing_postcode] </p>
                <br>
                <p><?php esc_html_e('جزییات حمل و نقل :', 'woodmartplus'); ?><br>
                    <?php esc_html_e('نام مشتری', 'woodmartplus'); ?> = [shipping_first_name] <br> 
                    <?php esc_html_e('نام خانوادگی مشتری', 'woodmartplus'); ?> = [shipping_last_name] <br>
                    <?php esc_html_e('نام شرکت', 'woodmartplus'); ?> = [shipping_company] <br>
                    <?php esc_html_e('کشور', 'woodmartplus'); ?> = [shipping_country] <br>
                    <?php esc_html_e('استان', 'woodmartplus'); ?> = [shipping_state] <br>
                    <?php esc_html_e('شهر', 'woodmartplus'); ?> = [shipping_city] <br>
                    <?php esc_html_e('آدرس 1', 'woodmartplus'); ?> = [shipping_address_1] <br>
                    <?php esc_html_e('آدرس 2', 'woodmartplus'); ?> = [shipping_address_2] <br>
                    <?php esc_html_e('کد پستی', 'woodmartplus'); ?> = [shipping_postcode] </p>
                <br>
            </div>
        </div>
        <?php if( wplus_helper::is_online_payamak_selected() ): ?>
        <div style="margin-top: 20px;">
            <button type="button" class="generate-pattern-customer" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; font-weight: 500; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="" style="width: 18px; height: 18px; display: block;">
                <span><?php esc_html_e('ایجاد پترن های از پیش آماده شده','woodmartplus'); ?></span>
            </button>
        </div>
        <?php endif; ?>
        <div class="add-suggestions open_acard opened" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('(بلافاصله بعد از خرید) در انتظار', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_pending_now">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-pending-now]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-pending-now']) && !empty($notif_customer['pattern-pending-now']) ? esc_html($notif_customer['pattern-pending-now']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-pending-now]'); ?>">
                            <?php if (isset($notif_customer['variables-pending-now']) && !empty($notif_customer['variables-pending-now'])) : ?>
                                <?php foreach ($notif_customer['variables-pending-now'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('در انتظار پرداخت', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_pending">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-pending]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-pending']) && !empty($notif_customer['pattern-pending']) ? esc_html($notif_customer['pattern-pending']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-pending]'); ?>">
                            <?php if (isset($notif_customer['variables-pending']) && !empty($notif_customer['variables-pending'])) : ?>
                                <?php foreach ($notif_customer['variables-pending'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('در حال انجام', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_processing">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-processing]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-processing']) && !empty($notif_customer['pattern-processing']) ? esc_html($notif_customer['pattern-processing']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-processing]'); ?>">
                            <?php if (isset($notif_customer['variables-processing']) && !empty($notif_customer['variables-processing'])) : ?>
                                <?php foreach ($notif_customer['variables-processing'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('در انتظیار بررسی', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_onhold">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-on-hold]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-on-hold']) && !empty($notif_customer['pattern-on-hold']) ? esc_html($notif_customer['pattern-on-hold']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-on-hold]'); ?>">
                            <?php if (isset($notif_customer['variables-on-hold']) && !empty($notif_customer['variables-on-hold'])) : ?>
                                <?php foreach ($notif_customer['variables-on-hold'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('تکمیل شده', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_completed">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-completed]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-completed']) && !empty($notif_customer['pattern-completed']) ? esc_html($notif_customer['pattern-completed']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-completed]'); ?>">
                            <?php if (isset($notif_customer['variables-completed']) && !empty($notif_customer['variables-completed'])) : ?>
                                <?php foreach ($notif_customer['variables-completed'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('لغو شده', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_cancelled">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-cancelled]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-cancelled']) && !empty($notif_customer['pattern-cancelled']) ? esc_html($notif_customer['pattern-cancelled']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-cancelled]'); ?>">
                            <?php if (isset($notif_customer['variables-cancelled']) && !empty($notif_customer['variables-cancelled'])) : ?>
                                <?php foreach ($notif_customer['variables-cancelled'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('مسترد شده', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_refunded">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-refunded]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-refunded']) && !empty($notif_customer['pattern-refunded']) ? esc_html($notif_customer['pattern-refunded']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-refunded]'); ?>">
                            <?php if (isset($notif_customer['variables-refunded']) && !empty($notif_customer['variables-refunded'])) : ?>
                                <?php foreach ($notif_customer['variables-refunded'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('ناموفق', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_failed">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-failed]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-failed']) && !empty($notif_customer['pattern-failed']) ? esc_html($notif_customer['pattern-failed']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-failed]'); ?>">
                            <?php if (isset($notif_customer['variables-failed']) && !empty($notif_customer['variables-failed'])) : ?>
                                <?php foreach ($notif_customer['variables-failed'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <!-- <img src="path/to/plus.svg" alt="add"> -->
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
                <span class="suggestion-menu">
                    <p><?php esc_html_e('پیشنویس', 'woodmartplus'); ?></p>
                </span>
                <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
                <div class="suggestion-inputs gray-inp customer_checkout_draft">
                    <!-- Pattern Input -->
                    <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                        <input type="text" name="<?php echo wplus_helper::generate_option('[notif_customer][pattern-checkout-draft]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($notif_customer['pattern-checkout-draft']) && !empty($notif_customer['pattern-checkout-draft']) ? esc_html($notif_customer['pattern-checkout-draft']) : '' ?>">
                    </div>
                    <!-- Variables Repeater -->
                    <div class="repeater-container">
                        <div data-repeater-list="<?php echo wplus_helper::generate_option('[notif_customer][variables-checkout-draft]'); ?>">
                            <?php if (isset($notif_customer['variables-checkout-draft']) && !empty($notif_customer['variables-checkout-draft'])) : ?>
                                <?php foreach ($notif_customer['variables-checkout-draft'] as $key => $value) : ?>

                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div data-repeater-item>
                                    <div class="send-time">
                                        <div>
                                            <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                            <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                            <a data-repeater-delete class="delete-btn">
                                                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="add-time">
                            <button data-repeater-create type="button">
                                <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>