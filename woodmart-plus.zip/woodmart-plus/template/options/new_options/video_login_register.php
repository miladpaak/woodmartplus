<div class="item p-18 br-bottom">
    <h3><?php esc_html_e('آموزش ویدئوی ثبت نام و ورود', 'woodmartplus'); ?></h3>

    <video  height="500" controls preload="none" poster="https://file.lordwp.site/learning-woodmartpluss/wodpluss-min.png">
        <source src="https://file.lordwp.site/learning-woodmartpluss/Dashboard/2-register-mobile.mp4" type="video/mp4" >
        <?php esc_html_e('مرورگر شما از ویدئو پشتیبانی نمی کند', 'woodmartplus'); ?>
    </video>
</div>