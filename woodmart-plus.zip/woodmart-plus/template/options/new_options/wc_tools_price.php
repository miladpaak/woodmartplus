<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('فعال سازی تماس برای قیمت', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('فعال سازی برچسب تماس بگیرید بجای قیمت', 'woodmartplus') ?></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[tag_phone_product]'); ?>" <?php echo wplus_helper::show_value('tag_phone_product', false) ? 'checked' : '' ?>>
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان برچسب در صفحه محصول', 'woodmartplus'); ?></span>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_tag_singleproduct]'); ?>" value="<?php wplus_helper::show_value('title_tag_singleproduct'); ?>">
    </div>
</div>
<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان برچسب در صفحه فروشگاه', 'woodmartplus'); ?></span>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_tag_shop]'); ?>" value="<?php wplus_helper::show_value('title_tag_shop'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان برچسب بر روی محصولات مرتبط', 'woodmartplus'); ?></span>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_tag_related]'); ?>" value="<?php wplus_helper::show_value('title_tag_related'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان برچسب بر روی محصولات زمانی که ناموجود است', 'woodmartplus'); ?></span>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_tag_outofstuck]'); ?>" value="<?php wplus_helper::show_value('title_tag_outofstuck'); ?>">
    </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('سازگاری بیشتر', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('این گزینه را زمانی فعال کنید که موارد بالا را قرار داده اید اما برچسب شما نمایش داده نمی شود', 'woodmartplus') ?></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[tag_problem]'); ?>" <?php echo wplus_helper::show_value('tag_problem', false) ? 'checked' : '' ?>>
    </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('نمایش اعداد فارسی در قیمت', 'woodmartplus'); ?></span>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[persian_number]'); ?>" <?php echo wplus_helper::show_value('persian_number', false) ? 'checked' : '' ?>>
    </div>
</div>