<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن پاسخ دهی خودکار', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('سیستم پاسخ دهی خودکار هوش مصنوعی', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_ai_review_setting]'); ?>" <?php echo wplus_helper::show_value('enable_ai_review_setting', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php esc_html_e('نام هوش مصنوعی', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('زمان پاسخ دهی نام هوش مصنوعی چه باشد؟ پیشفرض (AI BOT)','woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[ai_review_name]'); ?>" value="<?php wplus_helper::show_value('ai_review_name'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('دستور العمل و قوانین سیستم (system instruction)', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('در این قسمت میتوانید قوانین خود را قرار دهید که همراه با اطلاعات برای هوش مصنوعی ارسال میشود ، برای مثال لحن خوبی داشته باش و...' , 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[ai_review_system_instruction]'); ?>"><?php wplus_helper::show_value('ai_review_system_instruction') ?? ''; ?></textarea>
   </div>
</div>
