
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن سبد خرید رها شده', 'woodmartplus'); ?></span>
   <p class="des"></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[setting_leave_cart_enable]'); ?>" <?php echo wplus_helper::show_value('setting_leave_cart_enable', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('سبد خرید رها شده', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('از این قسمت میتوانید پیامک های سبد خرید رها شده را قرار دهید', 'woodmartplus'); ?></p>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('متای موبایل', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('شماره موبایل کاربران با چه متای در دیتا بیس ثبت شده است؟', 'woodmartplus'); ?></p>

    <div class="suggestion-inputs gray-inp">
        <input type="text" name="<?php echo wplus_helper::generate_option('[phone_meta]'); ?>" placeholder="<?php esc_html_e('نام متای کاربر ثبت نام شده', 'woodmartplus'); ?>" value="<?php echo wplus_helper::show_value('phone_meta');  ?>">
    </div>
</div>

<?php $leave_cart = wplus_helper::get_setting('leave_cart', []); ?>

<div class="item">
    <div class="manager-sms-wrapper">
        <div class="br-bottom" style="padding-bottom: 18px;">
            <div class="sms-sent-post m-t-18">
                <div class="short-code-text">
                    <span class="title"><?php esc_html_e('متن پیامک ارسال پستی','woodmartplus') ?></span>
                    <p class="des"><?php esc_html_e('می توانید از این شورت کد ها در متن پیامک استفاده کنید','woodmartplus') ?></p>
                </div>
                <div class="sms-sent-post-detailes br-radius-8">
                    <p>[shop_name] = نام فروشگاه</p>
                    <p>[full_name] = نام و نام خانوادگی</p>
                    <p>[phone_number] = شماره موبایل</p>
                    <p>[cart_total] = جمع سبد خرید</p>
                    <p>[product_name] = نام محصولات</p>
                    <p>[quantity_cart] = تعداد اقلام سبد خرید</p>
                    <p>[coupon_code] = کدتخفیف</p>
                </div>
            </div>

            <div class="add-suggestions open_acard opened" style="margin-top:20px;">
                <div class="suggestion-title">
                    <span class="suggestion-menu">
                        <p><?php esc_html_e('متن پیامک سبد خرید رها شده', 'woodmartplus'); ?></p>
                    </span>
                    <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
                </div>
                <div class="suggestion-content">
                    <div class="suggestion-inputs gray-inp">
                        <!-- Pattern Input -->
                        <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                            <input type="text" name="<?php echo wplus_helper::generate_option('[leave_cart][pattern]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($leave_cart['pattern']) && !empty($leave_cart['pattern']) ? esc_html($leave_cart['pattern']) : '' ?>">
                        </div>
                        <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                            <input type="text" name="<?php echo wplus_helper::generate_option('[leave_cart][coupon]'); ?>" placeholder="<?php esc_html_e('اگر از شورتکد کد تخفیف در متغییر ها استفاده شد ، کد تخفیف خود را در این قسمت قرار دهید', 'woodmartplus'); ?>" value="<?php echo isset($leave_cart['coupon']) && !empty($leave_cart['coupon']) ? esc_html($leave_cart['coupon']) : '' ?>">
                        </div>
                        <!-- Variables Repeater -->
                        <div class="repeater-container">
                            <div data-repeater-list="<?php echo wplus_helper::generate_option('[leave_cart][variables]'); ?>">
                                <?php if (isset($leave_cart['variables']) && !empty($leave_cart['variables'])) : ?>
                                    <?php foreach ($leave_cart['variables'] as $key => $value) : ?>

                                        <div data-repeater-item>
                                            <div class="send-time">
                                                <div>
                                                    <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                                    <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                                    <a data-repeater-delete class="delete-btn">
                                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <div data-repeater-item>
                                        <div class="send-time">
                                            <div>
                                                <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر','woodmartplus') ?>">
                                                <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد','woodmartplus') ?>">
                                                <a data-repeater-delete class="delete-btn">
                                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="add-time">
                                <button data-repeater-create type="button">
                                    <p><?php esc_html_e('افزودن متغیر جدید','woodmartplus') ?></p>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>