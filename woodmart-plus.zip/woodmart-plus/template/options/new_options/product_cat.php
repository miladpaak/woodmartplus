<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('نمایش محصولات در حاسب کاربری', 'woodmartplus'); ?></span>
    <p class="des"></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[recenlty_viwed_enable]'); ?>" <?php echo wplus_helper::show_value('recenlty_viwed_enable', false) ? 'checked' : '' ?> data-condition="productcat_section_condition">
    </div>
    
    <div class="item br-bottom p-18 productcat_section_condition">
        <span class="title"><?php echo esc_html_e('عنوان', 'woodmartplus'); ?></span>
        <p class="des"><?php esc_html_e('عنوان سکشن دسته بندی در داشبورد', 'woodmartplus'); ?></p>
        <div class="suggestion-inputs gray-inp">
            <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_section_product_cat]'); ?>" value="<?php wplus_helper::show_value('title_section_product_cat'); ?>">
        </div>
    </div>

    <div class="inp-rang p-top-18 productcat_section_condition">
        <h4><?php esc_html_e('تعداد نمایش', 'woodmartplus'); ?></h4>
        <input type="range" class="rang" min="1" max="6" name="<?php echo wplus_helper::generate_option('[recenlty_viewed_show_nummber]'); ?>" value="<?php wplus_helper::show_value('recenlty_viewed_show_nummber'); ?>">
        <div class="br-radius-8 rang-number d-center">
            <span class="num">4</span><span class="text-num"><?php esc_html_e('مقدار', 'woodmartplus'); ?></span>
        </div>
    </div>
</div>

<div class="item p-18 br-bottom select2_category productcat_section_condition">
    <span class="title"><?php esc_html_e('نمایش بر اساس دسته بندی', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('دسته بندی مورد نظر را برای نمایش محصولات در حساب کاربری انتخاب کنید ، توجه کنید که حتما محصول در دسته بندی موجود باشد!!.', 'woodmartplus'); ?></p>
    <div>
        <?php $selected = wplus_helper::show_value('category_myaccount',false);  ?>
        <select class="multi-select-category" name="<?php echo wplus_helper::generate_option('[category_myaccount]'); ?>" >
            <option value="<?php echo $selected; ?>" selected="selected"><?php echo wplus_helper::get_cat_name($selected) ?></option>
        </select>
    </div>
</div>


