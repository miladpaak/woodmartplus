<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن کش بک', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('برای فعال کردن کش بک مطمئن شوید که کیف پول فعال باشد.', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_cashback]'); ?>" <?php echo wplus_helper::show_value('enable_woo_cashback', false) ? 'checked' : '' ?>>
   </div>
</div>


<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('بعد از پرداخت', 'woodmartplus') ?></span>
   <p class="des"><?php esc_html_e('بعد از پرداخت از چه درگاهی کش بک محاسبه نشود!!!؟', 'woodmartplus'); ?></p>
   <div>
      <?php $cashback = wplus_helper::get_setting('cashback_payment_enable', []); ?>
      <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[cashback_payment_enable][]'); ?>" multiple="multiple" dir="rtl">
         <?php foreach (wplus_helper::get_enabled_payments_method() as $key => $value): ?>
            <option value="<?php echo esc_attr($key) ?>" <?php echo in_array($key, $cashback) ? 'selected' : '' ?>><?php echo esc_html($value); ?></option>
         <?php endforeach; ?>
      </select>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('محاسبه کش بک برای کیف پول', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('زمان شارژ کیف پول کش بک محاسبه شود؟', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_cashback_for_wallet]'); ?>" <?php echo wplus_helper::show_value('enable_woo_cashback_for_wallet', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('محاسبه کش بک برای کیف پول', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('اگر مانده کیف پول از کل سفارش کسر شد کش بک برای سفارش محاسبه شود؟', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_cashback_for_balance]'); ?>" <?php echo wplus_helper::show_value('enable_woo_cashback_for_balance', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('محاسبه کش بک برای سفارش تخفیف دار؟', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('زمانی که در سفارش از کدتخفیف استفاده شد ، کش بک برای آن سفارش هم محاسبه شود؟', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_cashback_for_orders_discount]'); ?>" <?php echo wplus_helper::show_value('enable_woo_cashback_for_orders_discount', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('زمان کش بک', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('بعد از چند روز اگر کاربر از کش بک استفاده نکرد کش بک حذف شود؟ (اگر نیازی ندارید غیرفعال باشد)', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_cashback_timer]'); ?>" <?php echo wplus_helper::show_value('enable_woo_cashback_timer', false) ? 'checked' : '' ?> data-condition="cashback_timer">
   </div>
</div>

<div class="item br-bottom p-18 cashback_timer">
   <span class="title"><?php esc_html_e('زمان (بر اساس روز)', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('زمان حذف کش بک را تعیین کنید اگر (0) قرار دهید این زمان حساب نمی شود', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="number" class="left-text" name="<?php echo wplus_helper::generate_option('[woo_cashback_timer]'); ?>" value="<?php wplus_helper::show_value('woo_cashback_timer'); ?>">
   </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('محاسبه کش بک', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('کش بک برای چه مبلغی محسابه شود؟', 'woodmartplus'); ?></p>
    <div>
        <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[how_calc_cashback]'); ?>">
            <option value="calc_total" <?php selected('calc_subtotal', wplus_helper::show_value('how_calc_cashback', false)) ?>><?php esc_html_e('مبلغ پرداختی (جمع کل)') ?></option>
            <option value="calc_subtotal" <?php selected('calc_subtotal', wplus_helper::show_value('how_calc_cashback', false)) ?>><?php esc_html_e('مجموع سبد خرید؟ (جمع جزء)') ?></option>
        </select>
    </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('کش بک در سبد خرید', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('آیا محاسبه کش بک به کاربر در سبد خرید نمایش داده شود؟', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_cashback_show_incart]'); ?>" <?php echo wplus_helper::show_value('enable_woo_cashback_show_incart', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('بیش از چه مبلغی کش بک محاسبه شود؟', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('برای مثال بیش از 1 میلیون تومان کش بک محاسبه شود', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="number" class="left-text" name="<?php echo wplus_helper::generate_option('[more_than_purchase_cashback]'); ?>" value="<?php wplus_helper::show_value('more_than_purchase_cashback'); ?>">
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('درصد کش بک', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('چند درصد از مبلغ کل سفارش کش بک شود؟', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="number" class="left-text" name="<?php echo wplus_helper::generate_option('[percentage_cashback]'); ?>" value="<?php wplus_helper::show_value('percentage_cashback'); ?>">
   </div>
</div>


<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال سازی اطلاع رسانی', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('بعد از دریافت کش بک از خرید برای کاربر پیام موفقیت ارسال شود؟', 'woodmartplus') ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_notif_cashback]'); ?>" <?php echo wplus_helper::show_value('enable_notif_cashback', false) ? 'checked' : '' ?> data-condition="enabled_cashback_notif">
   </div>
</div>

<div class="item enabled_cashback_notif">
   <div class="manager-sms-wrapper">
      <div class="short-code br-bottom p-18">
            <div class="short-code-text">
                <span class="title"><?php esc_html_e('شورت کد های قابل استفاده', 'woodmartplus'); ?></span>
                <p class="des"><?php esc_html_e('می توانید از این شورت کد ها در متن پیامک استفاده کنید', 'woodmartplus'); ?></p>
            </div>
            <div class="short-code-detailes br-radius-8">
                <p>
                    <?php esc_html_e('جزییات سفارش:', 'woodmartplus'); ?> <br>
                    <?php esc_html_e('نام فروشگاه', 'woodmartplus'); ?> = [shop_name]    <br>
                    <?php esc_html_e('شماره تلفن مشتری', 'woodmartplus'); ?> = [billing_phone]    <br>
                    <?php esc_html_e('ایمیل مشتری', 'woodmartplus'); ?> = [billing_email] <br>
                    <?php esc_html_e('وضعیت سفارش', 'woodmartplus'); ?> = [billing_status] <br>
                    <?php esc_html_e('محصولات سفارش', 'woodmartplus'); ?> = [billing_items] <br>
                    <?php esc_html_e('محصولات سفارش بهمراه تعداد', 'woodmartplus'); ?> = [billing_all_items_qty] <br>
                    <?php esc_html_e('تعداد محصولات سفارش', 'woodmartplus'); ?> = [billing_count_items] 
                </p>
                <br>
                <p> 
                <?php esc_html_e('مبلغ سفارش', 'woodmartplus'); ?> = [billing_price] <br> 
                <?php esc_html_e('شماره سفارش', 'woodmartplus'); ?> = [billing_order_id] <br>
                    <?php esc_html_e('تاریخ سفارش', 'woodmartplus'); ?> = [billing_date] <br> 
                    <?php esc_html_e('توضیحات مشتری', 'woodmartplus'); ?> = [billing_customer_not] <br>
                    <?php esc_html_e('روش پرداخت', 'woodmartplus'); ?> = [billing_payment_method] <br> 
                    <?php esc_html_e('روش ارسال', 'woodmartplus'); ?> = [billing_shipping_method] </p>
                <br>
                <p><?php esc_html_e('جزییات صورت حساب :', 'woodmartplus'); ?><br>
                    <?php esc_html_e('نام مشتری', 'woodmartplus'); ?> = [billing_first_name] <br>
                    <?php esc_html_e('نام خانوادگی مشتری', 'woodmartplus'); ?> = [billing_last_name] <br>
                    <?php esc_html_e('نام شرکت', 'woodmartplus'); ?> = [billing_company] <br> 
                    <?php esc_html_e('کشور', 'woodmartplus'); ?> = [billing_country] <br>
                    <?php esc_html_e('استان', 'woodmartplus'); ?> = [billing_state] <br>
                    <?php esc_html_e('شهر', 'woodmartplus'); ?> = [billing_city] <br>
                    <?php esc_html_e('آدرس 1', 'woodmartplus'); ?> = [billing_address_1] <br>
                    <?php esc_html_e('آدرس 2', 'woodmartplus'); ?> = [billing_address_2] <br>
                    <?php esc_html_e('کد پستی', 'woodmartplus'); ?> = [billing_postcode] </p>
                <br>
                <p><?php esc_html_e('جزییات حمل و نقل :', 'woodmartplus'); ?><br>
                    <?php esc_html_e('نام مشتری', 'woodmartplus'); ?> = [shipping_first_name] <br> 
                    <?php esc_html_e('نام خانوادگی مشتری', 'woodmartplus'); ?> = [shipping_last_name] <br>
                    <?php esc_html_e('نام شرکت', 'woodmartplus'); ?> = [shipping_company] <br>
                    <?php esc_html_e('کشور', 'woodmartplus'); ?> = [shipping_country] <br>
                    <?php esc_html_e('استان', 'woodmartplus'); ?> = [shipping_state] <br>
                    <?php esc_html_e('شهر', 'woodmartplus'); ?> = [shipping_city] <br>
                    <?php esc_html_e('آدرس 1', 'woodmartplus'); ?> = [shipping_address_1] <br>
                    <?php esc_html_e('آدرس 2', 'woodmartplus'); ?> = [shipping_address_2] <br>
                    <?php esc_html_e('کد پستی', 'woodmartplus'); ?> = [shipping_postcode] </p>
                <br>

                <p>
                   <?php esc_html_e('جزییات کش بک :', 'woodmartplus'); ?><br>
                   <?php esc_html_e('کش بک', 'woodmartplus'); ?> = [cashback] <br>
                </p>
            </div>
      </div>
   </div>
</div>

<?php $cashback_notif = wplus_helper::get_setting('cashback_notif',[]); ?>
<div class="add-suggestions open_acard opened enabled_cashback_notif" style="margin-top:20px;">
   <div class="suggestion-title">
         <span class="suggestion-menu">
            <p><?php esc_html_e('(بلافاصله بعد از خرید) در انتظار', 'woodmartplus'); ?></p>
         </span>
         <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
   </div>
   <div class="suggestion-content">
         <div class="suggestion-inputs gray-inp">
            <!-- Pattern Input -->
            <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
               <input type="text" name="<?php echo wplus_helper::generate_option('[cashback_notif][pattern]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($cashback_notif['pattern']) && !empty($cashback_notif['pattern']) ? esc_html($cashback_notif['pattern']) : '' ?>">
            </div>
            <!-- Variables Repeater -->
            <div class="repeater-container">
               <div data-repeater-list="<?php echo wplus_helper::generate_option('[cashback_notif][variables]'); ?>">
                     <?php if (isset($cashback_notif['variables']) && !empty($cashback_notif['variables'])) : ?>
                        <?php foreach ($cashback_notif['variables'] as $key => $value) : ?>

                           <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                             <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                           </div>
                        <?php endforeach; ?>
                     <?php else : ?>
                        <div data-repeater-item>
                           <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="<?php esc_html_e('متغیر', 'woodmartplus'); ?>">
                                    <input type="text" name="shortcode" placeholder="<?php esc_html_e('شورتکد', 'woodmartplus'); ?>">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                           </div>
                        </div>
                     <?php endif; ?>
               </div>
               <div class="add-time">
                     <button data-repeater-create type="button">
                        <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                     </button>
               </div>
            </div>
         </div>
   </div>
</div>
