<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن فاکتور', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('فاکتور را فعال و یا غیر فعال کنید', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[setting_factor_enable]'); ?>" <?php echo wplus_helper::show_value('setting_factor_enable', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('نمایش دکمه فاکتور پس از سفارش', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('با فعال کردن این گزینه بعد از سفارش دکمه فاکتور نمایش داده میشود', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[show_factor_btn_after_order]'); ?>" <?php echo wplus_helper::show_value('show_factor_btn_after_order', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('نمایش فاکتور در حساب کاربری کاربر', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('با فعال کردن این گزینه دکمه فاکتور در حساب کاربری کاربر نمایش داده میشود', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[show_factor_btn_myaccount_order]'); ?>" <?php echo wplus_helper::show_value('show_factor_btn_myaccount_order', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('انتخاب عرض فاکتور ، پیش فرض ۱۳۵۰', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('عرض صفحه فاکتور را میتوانید تغییر دهید', 'woodmartplus'); ?></p>
   <div class="inp-rang p-top-18">
      <input type="range" class="rang" min="1200" max="1500" name="<?php echo wplus_helper::generate_option('[width_factor]'); ?>" value="<?php wplus_helper::show_value('width_factor'); ?>">
      <div class="br-radius-8 rang-number d-center">
         <span class="num">4</span><span class="text-num"><?php esc_html_e('px', 'woodmartplus'); ?></span>
      </div>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('انتخاب رنگ', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('انتخاب رنگ فاکتور', 'woodmartplus') ?></p>
   <div class="chose-color">
      <div class="color-palet"><input class="color_picke" type="text" name="<?php echo wplus_helper::generate_option('[color_factor]'); ?>" value="<?php wplus_helper::show_value('color_factor'); ?>"></div>
      <div class="color-icon">
         <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="brush">
      </div>
   </div>
</div>

<?php $not_displayed = wplus_helper::get_setting('factor_detials_not_displayed'); ?>
<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('نمایش فیلد (جدول محصول)', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('در فاکتور چه اطلاعاتی از محصول نمایش داده نشود؟', 'woodmartplus'); ?></p>
    <div>
        <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[factor_detials_not_displayed][]'); ?>" multiple="multiple" dir="rtl">
            <?php foreach (wplus_factory::dont_show_detial() as $key => $value): ?>
                <option value="<?php echo esc_attr($key) ?>"
                  <?php echo is_array($not_displayed) && in_array($key, $not_displayed) ? 'selected' : '' ?>
                ><?php echo esc_html($value); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<?php $seller_info = wplus_factory::get_config_factor('seller_info'); ?>
<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('نمایش فیلد (اطلاعات فروشنده)', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('در فاکتور چه اطلاعاتی از فروشنده نمایش داده نشود؟', 'woodmartplus'); ?></p>
    <div>
        <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[factor][seller_info][info_displayed][]'); ?>" multiple="multiple" dir="rtl">
            <?php foreach (wplus_factory::information_displayed() as $key => $value): ?>
                <option value="<?php echo esc_attr($key) ?>"
                  <?php echo  isset($seller_info['info_displayed']) && is_array($seller_info['info_displayed']) && in_array($key, $seller_info['info_displayed']) ? 'selected' : '' ?>
                ><?php echo esc_html($value); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<?php $buyer_dont_displayed = wplus_helper::get_setting('dont_displayed_buyer_info'); ?>
<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('نمایش فیلد (اطلاعات خریدار)', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('در فاکتور چه اطلاعاتی از خریدار نمایش داده نشود؟', 'woodmartplus'); ?></p>
    <div>
        <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[dont_displayed_buyer_info][]'); ?>" multiple="multiple" dir="rtl">
            <?php foreach (wplus_factory::dont_displayed_buyer_info() as $key => $value): ?>
                <option value="<?php echo esc_attr($key) ?>"
                  <?php echo isset( $buyer_dont_displayed ) && is_array($buyer_dont_displayed) && in_array($key, $buyer_dont_displayed) ? 'selected' : '' ?>
                ><?php echo esc_html($value); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<?php $logo_factor_id = wplus_helper::get_setting('logo_factor') ?>
<div class="item p-18">
   <span class="title"><?php esc_html_e('لوگوی فاکتور', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('آپلود لوگوی فاکتور', 'woodmartplus'); ?></p>
   <div class="logo_login_register <?php echo isset($logo_factor_id) && !empty($logo_factor_id) ? 'upload-loding' : ''  ?>">
      <?php if (isset($logo_factor_id) && !empty($logo_factor_id)): ?>
         <?php
         $img_src = wp_get_attachment_image_src($logo_factor_id);
         ?>
         <div class="upload-loding-img upload_image ">
            <img src="<?php echo isset($img_src[0]) ? $img_src[0] : '' ?>" class="img-responsive" alt="logo-factor">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button">
               <img class="img-responisve" src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo wplus_helper::generate_option('[logo_factor]'); ?>" class="upload_image_id" value="<?php echo $logo_factor_id ?>" />
         </div>
      <?php else: ?>

         <div class=" upload_image">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button" style="display: none;">
               <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo wplus_helper::generate_option('[logo_factor]'); ?>" class="upload_image_id" value="" />
         </div>
      <?php endif; ?>
   </div>
</div>

<?php $image_signature_id = wplus_helper::get_setting('image_signature_factor') ?>
<div class="item p-18">
   <span class="title"><?php esc_html_e('تصویر مهر و امضای فروشگاه', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('آپلود مهر و امضا', 'woodmartplus'); ?></p>
   <div class="logo_login_register <?php echo isset($image_signature_id) && !empty($image_signature_id) ? 'upload-loding' : ''  ?>">
      <?php if (isset($image_signature_id) && !empty($image_signature_id)): ?>
         <?php
         $img_src_signature = wp_get_attachment_image_src($image_signature_id);
         ?>
         <div class="upload-loding-img upload_image ">
            <img src="<?php echo isset($img_src_signature[0]) ? $img_src_signature[0] : '' ?>" class="img-responsive" alt="logo-factor">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button">
               <img class="img-responisve" src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo wplus_helper::generate_option('[image_signature_factor]'); ?>" class="upload_image_id" value="<?php echo $image_signature_id ?>" />
         </div>
      <?php else: ?>

         <div class=" upload_image">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button" style="display: none;">
               <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo wplus_helper::generate_option('[image_signature_factor]'); ?>" class="upload_image_id" value="" />
         </div>
      <?php endif; ?>
   </div>
</div>

<div class="add-suggestions open_acard opened" style="margin-top:20px;">
<div class="suggestion-title">
    <span class="suggestion-menu">
        <p><?php esc_html_e('اضافه کردن توضیحات', 'woodmartplus'); ?></p>
    </span>
    <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
</div>
<?php $factor_additional_info = wplus_helper::get_setting('factor_additional_info', []); ?>
<div class="suggestion-content">
    <div class="suggestion-inputs gray-inp">
        <!-- Pattern Input -->
        <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
        </div>
        <!-- Variables Repeater -->
        <div class="repeater-container">
            <div data-repeater-list="<?php echo wplus_helper::generate_option('[factor_additional_info]'); ?>">
                <?php if (isset($factor_additional_info) && !empty($factor_additional_info)) : ?>
                    <?php foreach ($factor_additional_info as $key => $value) : ?>

                        <div data-repeater-item>
                            <div class="send-time">
                                <input type="text" name="title" placeholder="<?php esc_html_e('متن توضیحات', 'woodmartplus'); ?>" value="<?php echo isset($value['title']) && !empty($value['title']) ? esc_html($value['title']) : '' ?>">
                                <div>
                                    <a data-repeater-delete class="delete-btn">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <div data-repeater-item>
                        <div class="send-time">
                                <div>
                                    <input type="text" name="title" placeholder="<?php esc_html_e('متن توضیحات', 'woodmartplus'); ?>">
                                <a data-repeater-delete class="delete-btn">
                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="add-time">
                <button data-repeater-create type="button">
                    <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                </button>
            </div>
        </div>
    </div>
</div>
</div>