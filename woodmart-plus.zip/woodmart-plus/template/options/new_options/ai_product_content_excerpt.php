<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن خلاصه سازی متن های محصول', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('سیستم خلاصه سازی متن محصول', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_ai_product_content_excerpt_setting]'); ?>" <?php echo wplus_helper::show_value('enable_ai_product_content_excerpt_setting', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('دستور العمل سیستم', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('دستور العمل سیستم (پرامت) را بنویسید' , 'woodmartplus'); ?></p>
   <p><stron><?php esc_html_e('برای مثال : ','woodmartplus') ?></strong><?php esc_html_e('لطفاً متن زیر را در چند جمله کوتاه و روان برای معرفی محصول خلاصه کن:','woodmartplus') ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[ai_product_content_excerpt_prompt]'); ?>"><?php wplus_helper::show_value('ai_product_content_excerpt_prompt') ?? ''; ?></textarea>
   </div>
</div>
