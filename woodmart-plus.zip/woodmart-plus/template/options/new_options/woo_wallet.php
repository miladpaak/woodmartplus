<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن کیف پول','woodmartplus'); ?></span>
   <p class="des"></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_wallet]'); ?>"  <?php echo wplus_helper::show_value('enable_woo_wallet',false) ? 'checked' : '' ?> >
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('کسر از کیف پول','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('در صورتی که جمع سفارش از کیف پول بیشتر باشد ، مانده کیف پول از سفارش کم شود؟', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_wallet_balance]'); ?>"  <?php echo wplus_helper::show_value('enable_woo_wallet_balance',false) ? 'checked' : '' ?> >
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('محاسبه مالیات','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('آیا زمان شارژ کیف پول مالیات محاسبه شود؟', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_woo_wallet_tax]'); ?>"  <?php echo wplus_helper::show_value('enable_woo_wallet_tax',false) ? 'checked' : '' ?> >
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php  esc_html_e('حداقل مبلغ افزایش','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('حداقل مبلغ افزایشی در کیف پول را ثبت کنید','woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="number" class="left-text" name="<?php echo wplus_helper::generate_option('[min_increase_wallet]'); ?>" value="<?php wplus_helper::show_value( 'min_increase_wallet' ); ?>">
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php  esc_html_e('حداکثر مبلغ افزایش','woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('حداکثر مبلغ افزایشی در کیف پول را ثبت کنید','woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="number" class="left-text" name="<?php echo wplus_helper::generate_option('[max_increase_wallet]'); ?>" value="<?php wplus_helper::show_value( 'max_increase_wallet' ); ?>">
   </div>
</div>
