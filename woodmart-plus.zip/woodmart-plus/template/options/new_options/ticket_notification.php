<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('متن قبل از ارسال تیکت', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('این متن قبل از ارسال تیکت (صفحه ارسال تیکت جدید) نمایش داده میشود.' , 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[text_before_send_ticket]'); ?>"><?php wplus_helper::show_value('text_before_send_ticket') ?? ''; ?></textarea>
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('انتخاب وضعیت های ارسال پیامک', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('انتخاب کنید که در کدام یک از وضعیت های زیر پیامک ارسال شود.', 'woodmartplus'); ?></p>
   <div class="select-sms-setting">

      <div>
         <input type="checkbox" id="new_ticket_manager_opened" class="customer-" name="<?php echo wplus_helper::generate_option('[ticket_notif][new_ticket_manager]'); ?>" <?php echo isset($ticket_notif['new_ticket_manager']) && !empty($ticket_notif['new_ticket_manager']) ? 'checked' : '' ?>>
         <label for="new_ticket_manager_opened"><?php esc_html_e('زمانی که کاربر یک تیکت جدید باز کرد(ارسال به مدیر)', 'woodmartplus'); ?></label>
      </div>

      <div>
         <input type="checkbox" id="new_ticket_cutomer_opened" class="customer-" name="<?php echo wplus_helper::generate_option('[ticket_notif][new_ticket_customer]'); ?>" <?php echo isset($ticket_notif['new_ticket_customer']) && !empty($ticket_notif['new_ticket_customer']) ? 'checked' : '' ?>>
         <label for="new_ticket_cutomer_opened"><?php esc_html_e('زمانی که کاربر یک تیکت جدید باز کرد(ارسال به کاربر)', 'woodmartplus'); ?></label>
      </div>

      <div>
         <input type="checkbox" id="ticket_answer_manager" class="customer-" name="<?php echo wplus_helper::generate_option('[ticket_notif][ticket_answer_manager]'); ?>" <?php echo isset($ticket_notif['ticket_answer_manager']) && !empty($ticket_notif['ticket_answer_manager']) ? 'checked' : '' ?>>
         <label for="ticket_answer_manager"><?php esc_html_e('زمانی کاربر تیکت را پاسخ داد(ارسال به مدیر)', 'woodmartplus'); ?></label>
      </div>

      <div>
         <input type="checkbox" id="ticket_answer_customer" class="customer-" name="<?php echo wplus_helper::generate_option('[ticket_notif][ticket_answer_customer]'); ?>" <?php echo isset($ticket_notif['ticket_answer_customer']) && !empty($ticket_notif['ticket_answer_customer']) ? 'checked' : '' ?>>
         <label for="ticket_answer_customer"><?php esc_html_e('زمانی کاربر تیکت را پاسخ داد(ارسال به کاربر)', 'woodmartplus'); ?></label>
      </div>

      <div>
         <input type="checkbox" id="touser" class="customer-" name="<?php echo wplus_helper::generate_option('[ticket_notif][touser]'); ?>" <?php echo isset($ticket_notif['touser']) && !empty($ticket_notif['touser']) ? 'checked' : '' ?>>
         <label for="touser"><?php esc_html_e('زمانی که تیکت کاربر پاسخ داده میشود(ارسال به کاربر)', 'woodmartplus'); ?></label>
      </div>
      
      <div>
         <input type="checkbox" id="from_admin_touser" class="customer-" name="<?php echo wplus_helper::generate_option('[ticket_notif][from_admin_touser]'); ?>" <?php echo isset($ticket_notif['from_admin_touser']) && !empty($ticket_notif['from_admin_touser']) ? 'checked' : '' ?>>
         <label for="from_admin_touser"><?php esc_html_e('متن پیامک (زمانی که مدیر یک تیکت جدید باز میکند )(ارسال به کاربر)', 'woodmartplus'); ?></label>
      </div>

   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('انتخاب شماره تماس مدیران', 'woodmartplus') ?></span>
   <p class="des"><?php esc_html_e('شماره تماس مدیران را جهت ارسال پیامک وارد کنید.', 'woodmartplus'); ?></p>
   <div>
      <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[ticket_notif][managers-to-send-sms-ticket]'); ?>">
         <?php foreach (woodmartPlusInit::get_manager_phone_detail() as $key => $value): ?>
            <?php $selected = isset($ticket_notif['managers-to-send-sms-ticket']) && !empty($ticket_notif['managers-to-send-sms-ticket']) ? $ticket_notif['managers-to-send-sms-ticket'] : []; ?>
            <option value="<?php echo esc_attr($key) ?>" <?php echo $selected === $key ? 'selected' : '' ?>><?php echo esc_html($value); ?></option>
         <?php endforeach; ?>
      </select>
   </div>
</div>

<div class="item">
   <div class="manager-sms-wrapper">
      <div class="br-bottom" style="padding-bottom: 18px;">
         <div class="sms-sent-post m-t-18" style="margin-bottom: 15px;">
            <div class="short-code-text">
               <span class="title"><?php esc_html_e('شورتکد ها', 'woodmartplus'); ?></span>
               <p class="des"><?php esc_html_e('از شورتکد های روبه رو میتوانید در متن پیامک استفاده کنید', 'woodmartplus'); ?></p>
            </div>
            <div class="sms-sent-post-detailes br-radius-8">               
               <p>شماره تیکت = [ticket_id]</p>
               <p>دپارتمان تیکت = [ticket_departman]</p>
               <p>اولویت تیکت = [ticket_priority]</p>
               <p>نام تیکت دهنده = [ticket_fullname]</p>
               <p>وبسایت = [home_url]</p>
               <p>نام فروشگاه = [shop_name]</p>
            </div>
         </div>
         <?php if( wplus_helper::is_online_payamak_selected() ): ?>
         <div style="margin-top: 20px;">
            <button type="button" class="generate-pattern-ticket" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; font-weight: 500; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="" style="width: 18px; height: 18px; display: block;">
                <span><?php esc_html_e('ایجاد پترن های از پیش آماده شده','woodmartplus'); ?></span>
            </button>
         </div>
        <?php endif; ?>
         <div class="add-suggestions open_acard opened">
            <div class="suggestion-title">
               <span class="suggestion-menu">
                  <p><?php esc_html_e('متن پیامک (زمانی که کاربر یک تیکت جدید باز کرد مدیر)', 'woodmartplus'); ?></p>
               </span>
               <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
               <div class="suggestion-inputs gray-inp ticket_new_to_manager">
                  <!-- Pattern Input -->
                  <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                     <input type="text" name="<?php echo wplus_helper::generate_option('[ticket_notif][pattern_new_ticket_manager]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($ticket_notif['pattern_new_ticket_manager']) && !empty($ticket_notif['pattern_new_ticket_manager']) ? esc_html($ticket_notif['pattern_new_ticket_manager']) : '' ?>">
                  </div>
                  <!-- Variables Repeater -->
                  <div class="repeater-container">
                     <div data-repeater-list="<?php echo wplus_helper::generate_option('[ticket_notif][variable_new_ticket_manager]'); ?>">
                        <?php if (isset($ticket_notif['variable_new_ticket_manager']) && !empty($ticket_notif['variable_new_ticket_manager'])) : ?>
                           <?php foreach ($ticket_notif['variable_new_ticket_manager'] as $key => $value) : ?>

                              <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                          <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           <?php endforeach; ?>
                        <?php else : ?>
                           <div data-repeater-item>
                              <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="متغیر">
                                    <input type="text" name="shortcode" placeholder="شورتکد">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                              </div>
                           </div>
                        <?php endif; ?>
                     </div>
                     <div class="add-time">
                        <button data-repeater-create type="button">
                           <!-- <img src="path/to/plus.svg" alt="add"> -->
                           <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
               <span class="suggestion-menu">
                  <p><?php esc_html_e('متن پیامک (زمانی که کاربر یک تیکت جدید باز کرد کاربر)', 'woodmartplus'); ?></p>
               </span>
               <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
               <div class="suggestion-inputs gray-inp ticket_new_to_customer">
                  <!-- Pattern Input -->
                  <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                     <input type="text" name="<?php echo wplus_helper::generate_option('[ticket_notif][pattern_new_ticket_customer]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($ticket_notif['pattern_new_ticket_customer']) && !empty($ticket_notif['pattern_new_ticket_customer']) ? esc_html($ticket_notif['pattern_new_ticket_customer']) : '' ?>">
                  </div>
                  <!-- Variables Repeater -->
                  <div class="repeater-container">
                     <div data-repeater-list="<?php echo wplus_helper::generate_option('[ticket_notif][variable_new_ticket_customer]'); ?>">
                        <?php if (isset($ticket_notif['variable_new_ticket_customer']) && !empty($ticket_notif['variable_new_ticket_customer'])) : ?>
                           <?php foreach ($ticket_notif['variable_new_ticket_customer'] as $key => $value) : ?>

                              <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                          <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           <?php endforeach; ?>
                        <?php else : ?>
                           <div data-repeater-item>
                              <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="متغیر">
                                    <input type="text" name="shortcode" placeholder="شورتکد">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                              </div>
                           </div>
                        <?php endif; ?>
                     </div>
                     <div class="add-time">
                        <button data-repeater-create type="button">
                           <!-- <img src="path/to/plus.svg" alt="add"> -->
                           <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
               <span class="suggestion-menu">
                  <p><?php esc_html_e('متن پیامک (زمانی که کاربر تیکت را پاسخ داد مدیر)', 'woodmartplus'); ?></p>
               </span>
               <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
               <div class="suggestion-inputs gray-inp ticket_answer_to_manager">
                  <!-- Pattern Input -->
                  <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                     <input type="text" name="<?php echo wplus_helper::generate_option('[ticket_notif][pattern_ticket_answer_manager]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($ticket_notif['pattern_ticket_answer_manager']) && !empty($ticket_notif['pattern_ticket_answer_manager']) ? esc_html($ticket_notif['pattern_ticket_answer_manager']) : '' ?>">
                  </div>
                  <!-- Variables Repeater -->
                  <div class="repeater-container">
                     <div data-repeater-list="<?php echo wplus_helper::generate_option('[ticket_notif][variable_ticket_answer_manager]'); ?>">
                        <?php if (isset($ticket_notif['variable_ticket_answer_manager']) && !empty($ticket_notif['variable_ticket_answer_manager'])) : ?>
                           <?php foreach ($ticket_notif['variable_ticket_answer_manager'] as $key => $value) : ?>

                              <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable'])  ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                          <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           <?php endforeach; ?>
                        <?php else : ?>
                           <div data-repeater-item>
                              <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="متغیر">
                                    <input type="text" name="shortcode" placeholder="شورتکد">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                              </div>
                           </div>
                        <?php endif; ?>
                     </div>
                     <div class="add-time">
                        <button data-repeater-create type="button">
                           <!-- <img src="path/to/plus.svg" alt="add"> -->
                           <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
               <span class="suggestion-menu">
                  <p><?php esc_html_e('متن پیامک (زمانی که کاربر تیکت را پاسخ داد کاربر)', 'woodmartplus'); ?></p>
               </span>
               <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
               <div class="suggestion-inputs gray-inp ticket_answer_to_customer">
                  <!-- Pattern Input -->
                  <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                     <input type="text" name="<?php echo wplus_helper::generate_option('[ticket_notif][pattern_ticket_answer_customer]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($ticket_notif['pattern_ticket_answer_customer']) && !empty($ticket_notif['pattern_ticket_answer_customer']) ? esc_html($ticket_notif['pattern_ticket_answer_customer']) : '' ?>">
                  </div>
                  <!-- Variables Repeater -->
                  <div class="repeater-container">
                     <div data-repeater-list="<?php echo wplus_helper::generate_option('[ticket_notif][variable_ticket_answer_customer]'); ?>">
                        <?php if (isset($ticket_notif['variable_ticket_answer_customer']) && !empty($ticket_notif['variable_ticket_answer_customer'])) : ?>
                           <?php foreach ($ticket_notif['variable_ticket_answer_customer'] as $key => $value) : ?>

                              <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                          <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           <?php endforeach; ?>
                        <?php else : ?>
                           <div data-repeater-item>
                              <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="متغیر">
                                    <input type="text" name="shortcode" placeholder="شورتکد">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                              </div>
                           </div>
                        <?php endif; ?>
                     </div>
                     <div class="add-time">
                        <button data-repeater-create type="button">
                           <!-- <img src="path/to/plus.svg" alt="add"> -->
                           <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
               <span class="suggestion-menu">
                  <p><?php esc_html_e('متن پیامک (زمانی که تیکت کاربر پاسخ داده میشود به کاربر)', 'woodmartplus'); ?></p>
               </span>
               <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
               <div class="suggestion-inputs gray-inp ticket_touser">
                  <!-- Pattern Input -->
                  <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                     <input type="text" name="<?php echo wplus_helper::generate_option('[ticket_notif][pattern_touser]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($ticket_notif['pattern_touser']) && !empty($ticket_notif['pattern_touser']) ? esc_html($ticket_notif['pattern_touser']) : '' ?>">
                  </div>
                  <!-- Variables Repeater -->
                  <div class="repeater-container">
                     <div data-repeater-list="<?php echo wplus_helper::generate_option('[ticket_notif][variable_touser]'); ?>">
                        <?php if (isset($ticket_notif['variable_touser']) && !empty($ticket_notif['variable_touser'])) : ?>
                           <?php foreach ($ticket_notif['variable_touser'] as $key => $value) : ?>

                              <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                          <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           <?php endforeach; ?>
                        <?php else : ?>
                           <div data-repeater-item>
                              <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="متغیر">
                                    <input type="text" name="shortcode" placeholder="شورتکد">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                              </div>
                           </div>
                        <?php endif; ?>
                     </div>
                     <div class="add-time">
                        <button data-repeater-create type="button">
                           <!-- <img src="path/to/plus.svg" alt="add"> -->
                           <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         
         <div class="add-suggestions open_acard" style="margin-top:20px;">
            <div class="suggestion-title">
               <span class="suggestion-menu">
                  <p><?php esc_html_e('متن پیامک (زمانی که مدیر یک تیکت جدید باز میکند )(ارسال به کاربر)', 'woodmartplus'); ?></p>
               </span>
               <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
            </div>
            <div class="suggestion-content">
               <div class="suggestion-inputs gray-inp ticket_from_admin_to_user">
                  <!-- Pattern Input -->
                  <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
                     <input type="text" name="<?php echo wplus_helper::generate_option('[ticket_notif][pattern_from_admin_touser]'); ?>" placeholder="<?php esc_html_e('پترن پیامک را وارد کنید', 'woodmartplus'); ?>" value="<?php echo isset($ticket_notif['pattern_from_admin_touser']) && !empty($ticket_notif['pattern_from_admin_touser']) ? esc_html($ticket_notif['pattern_from_admin_touser']) : '' ?>">
                  </div>
                  <!-- Variables Repeater -->
                  <div class="repeater-container">
                     <div data-repeater-list="<?php echo wplus_helper::generate_option('[ticket_notif][variable_from_admin_touser]'); ?>">
                        <?php if (isset($ticket_notif['variable_from_admin_touser']) && !empty($ticket_notif['variable_from_admin_touser'])) : ?>
                           <?php foreach ($ticket_notif['variable_from_admin_touser'] as $key => $value) : ?>

                              <div data-repeater-item>
                                 <div class="send-time">
                                    <div>
                                       <input type="text" name="variable" placeholder="متغیر" value="<?php echo isset($value['variable']) ? esc_html($value['variable']) : '' ?>">
                                       <input type="text" name="shortcode" placeholder="شورتکد" value="<?php echo isset($value['shortcode']) && !empty($value['shortcode']) ? esc_html($value['shortcode']) : '' ?>">
                                       <a data-repeater-delete class="delete-btn">
                                          <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           <?php endforeach; ?>
                        <?php else : ?>
                           <div data-repeater-item>
                              <div class="send-time">
                                 <div>
                                    <input type="text" name="variable" placeholder="متغیر">
                                    <input type="text" name="shortcode" placeholder="شورتکد">
                                    <a data-repeater-delete class="delete-btn">
                                       <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                 </div>
                              </div>
                           </div>
                        <?php endif; ?>
                     </div>
                     <div class="add-time">
                        <button data-repeater-create type="button">
                           <!-- <img src="path/to/plus.svg" alt="add"> -->
                           <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>