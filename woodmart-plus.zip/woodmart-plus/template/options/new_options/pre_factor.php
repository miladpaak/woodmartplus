<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال شدن پیش فاکتور', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('با فعال کردن این گزینه پیش فاکتور فعال میشود', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[setting_pre_factor_enable]'); ?>" <?php echo wplus_helper::show_value('setting_pre_factor_enable', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('پیش فاکتور در سبد خرید', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('با فعال کردن این گزینه پیش فاکتور در سبد خرید نمایش داده میشود', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[show_pre_factor_in_cart]'); ?>" <?php echo wplus_helper::show_value('show_pre_factor_in_cart', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('پیش فاکتور در صفحه سفارشات', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('با فعال کردن این گزینه پیش فاکتور در صفحه سفارشات نمایش داده میشود', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[show_pre_factor_in_orders]'); ?>" <?php echo wplus_helper::show_value('show_pre_factor_in_orders', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('حتما کاربر باید وارد سایت شود', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('برای دریافت پیش فاکتور کاربر باید وارد سایت شود', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[pre_factor_require_login]'); ?>" <?php echo wplus_helper::show_value('pre_factor_require_login', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('مدت زمان انقضا پیش فاکتور', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('مدت زمان انقضا پیش فاکتور را میتوانید تغییر دهید', 'woodmartplus'); ?></p>
   <div class="inp-rang p-top-18">
      <input type="range" class="rang" min="1" max="30" name="<?php echo wplus_helper::generate_option('[pre_factor_expire_time]'); ?>" value="<?php wplus_helper::show_value('pre_factor_expire_time'); ?>">
      <div class="br-radius-8 rang-number d-center">
         <span class="num"><?php echo wplus_helper::show_value('pre_factor_expire_time'); ?></span><span class="text-num"><?php esc_html_e('روز', 'woodmartplus'); ?></span>
      </div>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('انتخاب رنگ', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('انتخاب رنگ پیش فاکتور', 'woodmartplus') ?></p>
   <div class="chose-color">
      <div class="color-palet"><input class="color_picke" type="text" name="<?php echo wplus_helper::generate_option('[color_pre_factor]'); ?>" value="<?php wplus_helper::show_value('color_pre_factor'); ?>"></div>
      <div class="color-icon">
         <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/brush.svg" alt="brush">
      </div>
   </div>
</div>

<?php $signature_pre_factor_id = wplus_helper::get_setting('signature_pre_factor') ?>
<div class="item p-18">
   <span class="title"><?php esc_html_e('تصویر مهر و امضا پیش فاکتور', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('آپلود تصویر مهر و امضا پیش فاکتور', 'woodmartplus'); ?></p>
   <div class="logo_login_register <?php echo isset($signature_pre_factor_id) && !empty($signature_pre_factor_id) ? 'upload-loding' : '' ?>">
      <?php if (isset($signature_pre_factor_id) && !empty($signature_pre_factor_id)): ?>
         <?php
         $img_src = wp_get_attachment_image_src($signature_pre_factor_id);
         ?>
         <div class="upload-loding-img upload_image">
            <img src="<?php echo isset($img_src[0]) ? $img_src[0] : '' ?>" class="img-responsive" alt="signature-pre-factor">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('ویرایش', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button">
               <img class="img-responisve" src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo wplus_helper::generate_option('[signature_pre_factor]'); ?>" class="upload_image_id" value="<?php echo $signature_pre_factor_id ?>" />
         </div>
      <?php else: ?>

         <div class="upload_image">
         </div>
         <div class="upload-loding-btns">
            <span class="blue-btn upload-btn upload-image-button"><?php esc_html_e('آپلود', 'woodmartplus'); ?></span>
            <span class="delete-btn remove-image-button" style="display: none;">
               <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="trash">
            </span>
            <input type="hidden" name="<?php echo wplus_helper::generate_option('[signature_pre_factor]'); ?>" class="upload_image_id" value="" />
         </div>
      <?php endif; ?>
   </div>
</div>

<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('توضیحات پیش فاکتور', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('در پیش فاکتور میتوانید توضیحات اضافه قرار دهید ، اگر خالی بگذارید این قسمت در پیش فاکتور نمایش داده نمیشود', 'woodmartplus'); ?></p>
</div>

<div class="add-suggestions open_acard opened" style="margin-top:20px;">
<div class="suggestion-title">
    <span class="suggestion-menu">
        <p><?php esc_html_e('اضافه کردن توضیحات', 'woodmartplus'); ?></p>
    </span>
    <span class="arrow-icon"><img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/arrow-down2.svg" alt=""></span>
</div>
<?php $pre_factor_additional_info = wplus_helper::get_setting('pre_factor_additional_info', []); ?>
<div class="suggestion-content">
    <div class="suggestion-inputs gray-inp">
        <!-- Pattern Input -->
        <div class="suggestion-inputs gray-inp" style="margin-bottom:.8rem;">
        </div>
        <!-- Variables Repeater -->
        <div class="repeater-container">
            <div data-repeater-list="<?php echo wplus_helper::generate_option('[pre_factor_additional_info]'); ?>">
                <?php if (isset($pre_factor_additional_info) && !empty($pre_factor_additional_info)) : ?>
                    <?php foreach ($pre_factor_additional_info as $key => $value) : ?>

                        <div data-repeater-item>
                            <div class="send-time">
                                <input type="text" name="title" placeholder="<?php esc_html_e('متن توضیحات', 'woodmartplus'); ?>" value="<?php echo isset($value['title']) && !empty($value['title']) ? esc_html($value['title']) : '' ?>">
                                <div>
                                    <a data-repeater-delete class="delete-btn">
                                        <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <div data-repeater-item>
                        <div class="send-time">
                                <div>
                                    <input type="text" name="title" placeholder="<?php esc_html_e('متن توضیحات', 'woodmartplus'); ?>">
                                <a data-repeater-delete class="delete-btn">
                                    <img src="<?php echo WOODPLUS_ASSET ?>admin/img/dashboard/trash.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="add-time">
                <button data-repeater-create type="button">
                    <p><?php esc_html_e('افزودن متغیر جدید', 'woodmartplus'); ?></p>
                </button>
            </div>
        </div>
    </div>
</div>
</div>