<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('فعال کردن داشبورد', 'woodmartplus'); ?></span>
    <p class="des"></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_dashboard]'); ?>" <?php echo wplus_helper::show_value('enable_dashboard', false) ? 'checked' : '' ?>>
    </div>
</div>


<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان فروشگاه', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('نام وبسایت خود را در این قسمت قرار بدید ، در تنظیمات وودمارت پلاس از شورتکد [shop_name] هر جای استفاده شد ، از این عنوان استفاده میشود', 'woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[website_name]'); ?>" value="<?php wplus_helper::show_value('website_name'); ?>">
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان ابتدایی داشبورد', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('عنوان در ابتدای صفحه داشبورد نمایش داده می شود', 'woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_page_dashboard]'); ?>" value="<?php wplus_helper::show_value('title_page_dashboard'); ?>">
    </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('نمایش تاریخ ها به میلادی', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('با فعال کردن این گزینه ، تاریخ ها به میلادی نمایش داده می شود (در حساب کاربری)', 'woodmartplus'); ?></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_miladi_date]'); ?>" <?php echo wplus_helper::show_value('enable_miladi_date', false) ? 'checked' : '' ?>>
    </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('چه مواردی در داشبورد کاربر نمایش داده نشود.', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('فیلد های زیر اگر نمایش داده نمی شود یکبار وارد صفحه پیشخوان کاربر شوید', 'woodmartplus'); ?></p>
    <div>
        <?php $dashboard_menu = wplus_helper::get_setting('dashboard_menu', []); ?>
        <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[dashboard_menu][]'); ?>" multiple="multiple" dir="rtl">
            <?php foreach (woodmartPlusInit::generate_all_dashboard_menu() as $key => $value): ?>
                <?php if (strpos($key, '%') !== false) {
                    $key = urldecode($key);
                } ?>
                <option value="<?php echo esc_attr($key) ?>" <?php echo in_array($key, $dashboard_menu) ? 'selected' : '' ?>><?php echo esc_html($value); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

