
<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('انتخاب هوش مصنوعی', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('هوش مصنوعی مورد نظر خود را انتخاب کنید', 'woodmartplus') ?></p>
    <div class="dropdown_select select_operator">
        <select name="<?php echo wplus_helper::generate_option('[ai_name]'); ?>" class="dropdown select_ai_models">
            <?php foreach( wplus_helper::get_ai_models() as $key => $operator ) : ?>
                <option value="<?php echo $key; ?>" <?php selected($key, wplus_helper::show_value('ai_name', false));  ?>><?php echo $operator; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('Gemini API', 'woodmartplus'); ?></span>
    <p class="des"><?php 
        printf(__('برای دریافت api هوش مصنوعی gemini از <a href="%s">اینجا</a> اقدام کنید','woodmartplus'),esc_url( 'https://aistudio.google.com/apikey' ));
    ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[api_gemini_ai]'); ?>" value="<?php wplus_helper::show_value('api_gemini_ai'); ?>">
    </div>
</div>

<?php $ai_gemeni_model = wplus_helper::get_setting('ai_gemeni_model'); ?>
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('انتخاب مدل', 'woodmartplus') ?></span>
   <p class="des"><?php esc_html_e('از مدل های هوش مصنوعی موجود ، یک مدل را انتخاب کنید', 'woodmartplus'); ?></p>
   <div>
      <select class="js-example-basic-multiple" name="<?php echo wplus_helper::generate_option('[ai_gemeni_model]'); ?>">
            <option value="gemini-2_5" <?php selected($ai_gemeni_model,'gemini-2_5') ?>> <?php esc_html_e('Gemini 2.5','woodmartplus') ?> </option>
            <option value="gemini-2_0" <?php selected($ai_gemeni_model,'gemini-2_0') ?>> <?php esc_html_e('Gemini 2.0','woodmartplus') ?> </option>
      </select>
   </div>
</div>
