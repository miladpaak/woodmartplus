
<?php
$tab_detials = [
    'login_register1' => [
        'tab_name' => __('پیکربندی','woodmartplus'),
    ],
    'additional_setting' => [
        'tab_name' => __('متن نگهدارنده','woodmartplus'),
    ],
    'captcha' => [
        'tab_name' => __('گوگل کپچا','woodmartplus'),
    ],
    'compatible-login-register' => [
        'tab_name' => __('سازگاری ثبت نام ورود','woodmartplus'),
    ],
    'error_handeling' => [
        'tab_name' => __('مدیریت خطایابی','woodmartplus'),
    ],
    'video_login_register' => [
      'tab_name' => __('فیلم آموزشی','woodmartplus')
    ]
];
?>
<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('تنظیمات ثبت نام و ورود', 'woodmartplus'); ?></span>

   <div class="importer-container">
      <div class="importer-tabs">

         <ul class="page-setting-tab-nav">
            <?php $i = 0;
            foreach ($tab_detials as $tab => $value): ?>
               <li class="<?php echo $i == 0 ? 'active' : '' ?>" data-tab="<?php echo $tab; ?>"><?php echo $value['tab_name']; ?></li>
            <?php $i++;
            endforeach; ?>
         </ul>

         <div class="importer-tab-content">
            <?php $b = 0;
            foreach ($tab_detials as $tab => $value):  ?>
               <div class="tab-pane-setting <?php echo $b == 0 ? 'active' : '' ?>" id="<?php echo $tab; ?>-tab">
                    <?php include $tab.'.php'; ?>
               </div>
            <?php $b++;
            endforeach; ?>

         </div>
      </div>
   </div>

   <div class="import-status">
      <div class="import-progress">
         <div class="progress-bar"></div>
      </div>
      <div class="import-message"></div>
   </div>

   <div class="btn-select show_dashboard_builder" style="display: none;">
      <a href="<?php echo admin_url('edit.php?post_type=dashboard_builder') ?>" class="chang-btn blue-btn-bg" name="import_myaccount" value="import"><?php esc_html_e('مشاهده صفحه ساخت حساب کاربری', 'woodmartplus'); ?></a>
   </div>
</div>


<script>
   jQuery(document).ready(function($) {
      $('.page-setting-tab-nav li').on('click', function() {
         var tabId = $(this).data('tab');

         $('.page-setting-tab-nav li').removeClass('active');
         $(this).addClass('active');

         $('.tab-pane-setting').removeClass('active');
         $('#' + tabId + '-tab').addClass('active');
      });
   });
</script>