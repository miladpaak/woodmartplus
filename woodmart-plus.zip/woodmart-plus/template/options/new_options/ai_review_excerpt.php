<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('فعال کردن خلاصه سازی دیدگاه', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('سیستم خلاصه سازی دیدگاه محصولات', 'woodmartplus'); ?></p>
   <div class="btn-select">
      <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[enable_ai_review_excerpt_setting]'); ?>" <?php echo wplus_helper::show_value('enable_ai_review_excerpt_setting', false) ? 'checked' : '' ?>>
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('دستور العمل سیستم', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('دستور العمل سیستم (پرامت) را بنویسید' , 'woodmartplus'); ?></p>
   <p><stron><?php esc_html_e('برای مثال : ','woodmartplus') ?></strong><?php esc_html_e('لطفاً تمام دیدگاه‌های زیر را در چند جمله خلاصه کن، طوری که مفهوم کلی و تجربه مشتریان مشخص شود:','woodmartplus') ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[ai_review_excerpt_prompt]'); ?>"><?php wplus_helper::show_value('ai_review_excerpt_prompt') ?? ''; ?></textarea>
   </div>
</div>
