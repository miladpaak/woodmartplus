<div class="item br-bottom p-18">
   <p class="des"><?php esc_html_e('از شورتکد [shop_name] در ورودی های میتوانید استفاده کنید، برای تنظیمات عنوان فروشگاه وارد سیستم داشبورد / پیکربندی شوید', 'woodmartplus'); ?></p>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('عنوان ثبت نام و ورود', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('عنوان ثبت نام و ورود خود را تنظیم کنید', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[title_login_register]'); ?>" value="<?php wplus_helper::show_value('title_login_register'); ?>">
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('توضیح نحوه ورود', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('این قسمت بعد از ثبت نام و ورود نمایش داده میشود', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <input type="text" class="left-text" name="<?php echo wplus_helper::generate_option('[after_title_text]'); ?>" value="<?php wplus_helper::show_value('after_title_text'); ?>">
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('توضیح قوانین و شرایط', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('متن قوانین', 'woodmartplus'); ?></p>
   <div class="suggestion-inputs gray-inp">
      <textarea name="<?php echo wplus_helper::generate_option('[description_login_register]'); ?>"><?php wplus_helper::show_value('description_login_register') ?? ''; ?></textarea>
   </div>
</div>

<div class="item br-bottom p-18">
   <span class="title"><?php esc_html_e('تغییر متن های فرم ورود و ثبت نام هوشمند', 'woodmartplus') ?></span>
   <p class="des"><?php esc_html_e('شما میتوانید متن های موجود در فرم ورود و ثبت نام هوشمند را تغییر دهید', 'woodmartplus') ?></p>
</div>
<div class="item">
   <div class="manager-sms-wrapper">

      <div class="awaiting-payment-immediately-cust br-radius-8 m-18">
         <div class="awaiting-payment-immediately-text-cust"><?php esc_html_e('متن های فرم ابتدایی ثبت نام ورود', 'woodmartplus') ?></div>
         <div class="awaiting-payment-immediately-inp-cust">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('ایمیل / موبایل / نام کاربری', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[first_placeholder]'); ?>" value="<?php wplus_helper::show_value('first_placeholder'); ?>">
            <p><?php esc_html_e('متن دکمه', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('ثبت نام / ورود', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[first_btn_text]'); ?>" value="<?php wplus_helper::show_value('first_btn_text'); ?>">
         </div>
      </div>

      <div class="awaiting-payment-immediately-cust br-radius-8 m-18">
         <div class="awaiting-payment-immediately-text-cust"><?php esc_html_e('متن های فرم وارد کردن رمزعبور', 'woodmartplus') ?></div>
         <div class="awaiting-payment-immediately-inp-cust">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('رمز عبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[two_placeholder_text]'); ?>" value="<?php wplus_helper::show_value('two_placeholder_text'); ?>">
            <p><?php esc_html_e('متن دکمه', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('ورود', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[two_btn_text]'); ?>" value="<?php wplus_helper::show_value('two_btn_text'); ?>">
            <p><?php esc_html_e('متن ورود با کد یکبار مصرف', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('ورود با کد یکبار مصرف', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[two_text_login_otp]'); ?>" value="<?php wplus_helper::show_value('two_text_login_otp'); ?>">
            <p><?php esc_html_e('متن فراموشی رمزعبور', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('آیا رمز عبور خود را فراموش کرده اید', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[first_text_forgetpassword]'); ?>" value="<?php wplus_helper::show_value('first_text_forgetpassword'); ?>">
         </div>
      </div>

      <div class="awaiting-payment-immediately-cust br-radius-8 m-18">
         <div class="awaiting-payment-immediately-text-cust"><?php esc_html_e('متن های فرم بازیابی رمزعبور', 'woodmartplus') ?></div>
         <div class="awaiting-payment-immediately-inp-cust">
            <p><?php esc_html_e('عنوان', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('بازیابی رمزعبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[three_placeholder_username]'); ?>" value="<?php wplus_helper::show_value('three_placeholder_username'); ?>">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('رمز عبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[three_placeholder_password]'); ?>" value="<?php wplus_helper::show_value('three_placeholder_password'); ?>">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('تکرار رمزعبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[three_placeholder_passwordreapet]'); ?>" value="<?php wplus_helper::show_value('three_placeholder_passwordreapet'); ?>">
            <p><?php esc_html_e('متن دکمه', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('بازیابی', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[three_btn_text]'); ?>" value="<?php wplus_helper::show_value('three_btn_text'); ?>">
         </div>
      </div>

      <div class="awaiting-payment-immediately-cust br-radius-8 m-18">
         <div class="awaiting-payment-immediately-text-cust"><?php esc_html_e('متن های فرم احراز هویت موبایل', 'woodmartplus') ?></div>
         <div class="awaiting-payment-immediately-inp-cust">

            <p><?php esc_html_e('متن دکمه', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('تایید موبایل', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[four_btn_text]'); ?>" value="<?php wplus_helper::show_value('four_btn_text'); ?>">
         </div>
      </div>

      <div class="awaiting-payment-immediately-cust br-radius-8 m-18">
         <div class="awaiting-payment-immediately-text-cust"><?php esc_html_e('متن های فرم ثبت نام', 'woodmartplus') ?></div>
         <div class="awaiting-payment-immediately-inp-cust">
            <p><?php esc_html_e('عنوان', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('ثبت نام', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[five_title_text]'); ?>" value="<?php wplus_helper::show_value('five_timeup_text'); ?>">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('نام کاربری', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[five_username_text]'); ?>" value="<?php wplus_helper::show_value('five_username_text'); ?>">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('رمزعبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[five_password_text]'); ?>" value="<?php wplus_helper::show_value('five_password_text'); ?>">
            <p><?php esc_html_e('متن نگهدارنده', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('تکرار رمزعبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[five_passwordrepat_text]'); ?>" value="<?php wplus_helper::show_value('five_passwordrepat_text'); ?>">
            <p><?php esc_html_e('متن دکمه', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('ثبت نام', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[five_btn_text]'); ?>" value="<?php wplus_helper::show_value('five_btn_text'); ?>">
         </div>
      </div>
      
      <div class="awaiting-payment-immediately-cust br-radius-8 m-18">
         <div class="awaiting-payment-immediately-text-cust"><?php esc_html_e('متن تولیپ ها', 'woodmartplus') ?></div>
         <div class="awaiting-payment-immediately-inp-cust">
            <p><?php esc_html_e('متن تولتیپ ورود با رمزیکبار مصرف', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('متن تولتیپ ورود با رمزیکبار مصرف', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[tooltip_login_otp]'); ?>" value="<?php wplus_helper::show_value('tooltip_login_otp'); ?>">
            <p><?php esc_html_e('متن تولتیپ فراموشی رمزعبور', 'woodmartplus') ?></p>
            <input class="type-text-width-100" type="text" class="left-text" placeholder="<?php esc_html_e('فراموشی رمزعبور', 'woodmartplus') ?>" name="<?php echo wplus_helper::generate_option('[tooltip_forget_password]'); ?>" value="<?php wplus_helper::show_value('tooltip_forget_password'); ?>">
         </div>
      </div>
   </div>
</div>