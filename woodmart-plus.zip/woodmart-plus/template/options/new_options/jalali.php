<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('تاریخ شمسی', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('با این کار میتوانید وبسایت خود را شمسی کنید', 'woodmartplus') ?></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[is_jalali]'); ?>" <?php echo wplus_helper::show_value('is_jalali', false) ? 'checked' : '' ?>>
    </div>
</div>

<div class="item p-18 br-bottom">
    <span class="title"><?php esc_html_e('تاریخ شمسی برای نمودار', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('تاریخ شمسی برای نمودار های ووکامرس', 'woodmartplus') ?></p>
    <div class="btn-select">
        <input type="checkbox" class="switch" name="<?php echo wplus_helper::generate_option('[is_wc_analytics]'); ?>" <?php echo wplus_helper::show_value('is_wc_analytics', false) ? 'checked' : '' ?>>
    </div>
</div>