<?php 
    $number_digits = wplus_helper::get_setting('number_otp', 4);
    $logo = wplus_helper::get_logo_login_register(); 
    $translate_shortcode = Translate_Shortcode::get_instance();
?>

<div class="container wdplus_login_register">
    <div class="form-box">
        <div class="top-header">
            <?php if ($logo): ?>
                <div class="logo-area">
                    <div class="logo-container">
                        <img src="<?php echo $logo; ?>" alt="logo" />
                    </div>
                </div>
            <?php endif; ?>
            <h5><?php echo esc_html( $translate_shortcode->prepare_message(wplus_helper::get_setting('title_login_register'))); ?></h5>
            
        </div>

        <div class="alert slide-in">
            <span class="alert-icon">
                <svg class="svg_success" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                </svg>
                <svg class="svg_error" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" />
                </svg>
            </span>
            <span class="alert_msg"></span>
        </div>

        <form class="first_step">
            <div class="input-group">
                <div class="floating-input-field">
                    <input type="text" class="username" name="username" required autocomplete="off">
                    <label for="username"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('first_placeholder', 'شماره موبایل ، ایمیل، نام کاربری...'))  ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M20.5899 22C20.5899 18.13 16.7399 15 11.9999 15C7.25991 15 3.40991 18.13 3.40991 22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <div class="input-bottom-line"></div>
                </div>
            </div>
            <button type="submit" class="submit-btn">
                <span class="btn-text"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('first_btn_text', 'ثبت نام / ورود')); ?></span>
                <span class="loading-spinner"></span>
            </button>
            <?php if (woodplus_Recaptcha::is_recaptcha_enabled() &&  wplus_helper::get_setting('setting_recaptcha_enable')) { ?>
                <div id="recaptcha-contact-form" class="ga-recaptcha" data-sitekey="<?php echo esc_attr(wplus_helper::get_setting('google_recaptcha_site_key')); ?>"></div>
            <?php } ?>

            <?php if( wplus_helper::get_page_by_id() ): ?>
            <div class="extra-links" style="margin-top: 30px;">
                <a href="<?php echo esc_url(wplus_helper::get_page_by_id()); ?>"  target="_blank">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 22C12 22 20 18 20 12V5L12 2L4 5V12C4 18 12 22 12 22Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M12 14V17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    <span><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('description_login_register', esc_html('حریم خصوصی', 'woodmartplus'))); ?></span>
                </a>
            </div>
            <?php endif; ?>
            <input type="hidden" class="nonce_login_register" value="<?php echo wp_create_nonce('form_login_register') ?>">
        </form>
    </div>

    <div class="form-box" style="display:none">
        <?php if ($logo): ?>
            <div class="logo-area">
                <div class="logo-container">
                    <img src="<?php echo $logo; ?>" alt="logo" />
                </div>
            </div>
        <?php endif; ?>
        <div class="alert slide-in">
            <span class="alert-icon">
                <svg class="svg_success" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                </svg>
                <svg class="svg_error" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" />
                </svg>
            </span>
            <span class="alert_msg"></span>
        </div>

        <div class="top-header">
            <p class="title_password"></p>
        </div>

        <form action="#" method="POST" class="step_password">
            <div class="input-group">
                <div class="floating-input-field">
                    <input type="password" class="password" required autocomplete="off">
                    <label for="password"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('two_title_text', 'رمزعبور خود را وارد کنید')) ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
            </div>

            <button type="submit" class="submit-btn">
                <span class="btn-text"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('two_btn_text', 'تایید و ادامه')); ?></span>
                <div class="loading-spinner"></div>
            </button>

            <a href="#" class="back_to_start" onclick="event.preventDefault();"></a>

            <div class="extra-links" style="margin-top:30px;justify-content: space-between;">
                
                <a href="#" class="tooltip_wdplus go_to_otp_auth" data-tooltip="<?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('tooltip_login_otp', 'کد احراز هویت به موبایل ثبت شده ارسال میشود')); ?>">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M19.4 15C19.2669 15.3016 19.2272 15.6362 19.286 15.9606C19.3448 16.285 19.4995 16.5843 19.73 16.82L19.79 16.88C19.976 17.0657 20.1235 17.2863 20.2241 17.5291C20.3248 17.7719 20.3766 18.0322 20.3766 18.295C20.3766 18.5578 20.3248 18.8181 20.2241 19.0609C20.1235 19.3037 19.976 19.5243 19.79 19.71C19.6043 19.896 19.3837 20.0435 19.1409 20.1441C18.8981 20.2448 18.6378 20.2966 18.375 20.2966C18.1122 20.2966 17.8519 20.2448 17.6091 20.1441C17.3663 20.0435 17.1457 19.896 16.96 19.71L16.9 19.65C16.6643 19.4195 16.365 19.2648 16.0406 19.206C15.7162 19.1472 15.3816 19.1869 15.08 19.32C14.7842 19.4468 14.532 19.6572 14.3543 19.9255C14.1766 20.1938 14.0813 20.5082 14.08 20.83V21C14.08 21.5304 13.8693 22.0391 13.4942 22.4142C13.1191 22.7893 12.6104 23 12.08 23C11.5496 23 11.0409 22.7893 10.6658 22.4142C10.2907 22.0391 10.08 21.5304 10.08 21V20.91C10.0723 20.579 9.96512 20.258 9.77251 19.9887C9.5799 19.7194 9.31074 19.5143 9 19.4C8.69838 19.2669 8.36381 19.2272 8.03941 19.286C7.71502 19.3448 7.41568 19.4995 7.18 19.73L7.12 19.79C6.93425 19.976 6.71368 20.1235 6.47088 20.2241C6.22808 20.3248 5.96783 20.3766 5.705 20.3766C5.44217 20.3766 5.18192 20.3248 4.93912 20.2241C4.69632 20.1235 4.47575 19.976 4.29 19.79C4.10405 19.6043 3.95653 19.3837 3.85588 19.1409C3.75523 18.8981 3.70343 18.6378 3.70343 18.375C3.70343 18.1122 3.75523 17.8519 3.85588 17.6091C3.95653 17.3663 4.10405 17.1457 4.29 16.96L4.35 16.9C4.58054 16.6643 4.73519 16.365 4.794 16.0406C4.85282 15.7162 4.81312 15.3816 4.68 15.08C4.55324 14.7842 4.34276 14.532 4.07447 14.3543C3.80618 14.1766 3.49179 14.0813 3.17 14.08H3C2.46957 14.08 1.96086 13.8693 1.58579 13.4942C1.21071 13.1191 1 12.6104 1 12.08C1 11.5496 1.21071 11.0409 1.58579 10.6658C1.96086 10.2907 2.46957 10.08 3 10.08H3.09C3.42099 10.0723 3.742 9.96512 4.0113 9.77251C4.28059 9.5799 4.48572 9.31074 4.6 9C4.73312 8.69838 4.77282 8.36381 4.714 8.03941C4.65519 7.71502 4.50054 7.41568 4.27 7.18L4.21 7.12C4.02405 6.93425 3.87653 6.71368 3.77588 6.47088C3.67523 6.22808 3.62343 5.96783 3.62343 5.705C3.62343 5.44217 3.67523 5.18192 3.77588 4.93912C3.87653 4.69632 4.02405 4.47575 4.21 4.29C4.39575 4.10405 4.61632 3.95653 4.85912 3.85588C5.10192 3.75523 5.36217 3.70343 5.625 3.70343C5.88783 3.70343 6.14808 3.75523 6.39088 3.85588C6.63368 3.95653 6.85425 4.10405 7.04 4.29L7.1 4.35C7.33568 4.58054 7.63502 4.73519 7.95941 4.794C8.28381 4.85282 8.61838 4.81312 8.92 4.68H9C9.29577 4.55324 9.54802 4.34276 9.72569 4.07447C9.90337 3.80618 9.99872 3.49179 10 3.17V3C10 2.46957 10.2107 1.96086 10.5858 1.58579C10.9609 1.21071 11.4696 1 12 1C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V3.09C14.0013 3.41179 14.0966 3.72618 14.2743 3.99447C14.452 4.26276 14.7042 4.47324 15 4.6C15.3016 4.73312 15.6362 4.77282 15.9606 4.714C16.285 4.65519 16.5843 4.50054 16.82 4.27L16.88 4.21C17.0657 4.02405 17.2863 3.87653 17.5291 3.77588C17.7719 3.67523 18.0322 3.62343 18.295 3.62343C18.5578 3.62343 18.8181 3.67523 19.0609 3.77588C19.3037 3.87653 19.5243 4.02405 19.71 4.21C19.896 4.39575 20.0435 4.61632 20.1441 4.85912C20.2448 5.10192 20.2966 5.36217 20.2966 5.625C20.2966 5.88783 20.2448 6.14808 20.1441 6.39088C20.0435 6.63368 19.896 6.85425 19.71 7.04L19.65 7.1C19.4195 7.33568 19.2648 7.63502 19.206 7.95941C19.1472 8.28381 19.1869 8.61838 19.32 8.92V9C19.4468 9.29577 19.6572 9.54802 19.9255 9.72569C20.1938 9.90337 20.5082 9.99872 20.83 10H21C21.5304 10 22.0391 10.2107 22.4142 10.5858C22.7893 10.9609 23 11.4696 23 12C23 12.5304 22.7893 13.0391 22.4142 13.4142C22.0391 13.7893 21.5304 14 21 14H20.91C20.5882 14.0013 20.2738 14.0966 20.0055 14.2743C19.7372 14.452 19.5268 14.7042 19.4 15Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>

                    <span><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('two_text_login_otp', 'ورود با رمز یکبار مصرف')); ?></span>
                </a>
                <a href="#" class="tooltip_wdplus reset_pass" data-tooltip="<?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('tooltip_forget_password', 'میتوانید رمز عبور خود را نو سازی کنید')); ?>">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 10V8C8 5.79086 9.79086 4 12 4C14.2091 4 16 5.79086 16 8V10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                        <path d="M12 14V17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                        <path d="M17 10H7C5.89543 10 5 10.8954 5 12V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V12C19 10.8954 18.1046 10 17 10Z" stroke="currentColor" stroke-width="1.5" />
                    </svg>
                    <span><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('first_text_forgetpassword', 'فراموشی رمز عبور')); ?></span>
                </a>
            </div>
            <input type="hidden" value="<?php echo wp_create_nonce('form_login_with_email') ?>" class="nonce_login_email">
            
        </form>
    </div>

    <div class="form-box" style="display:none;">
        <?php if ($logo): ?>
            <div class="logo-area">
                <div class="logo-container">
                    <img src="<?php echo $logo; ?>" alt="logo" />
                </div>
            </div>
        <?php endif; ?>
        <div class="alert slide-in">
            <span class="alert-icon">
                <svg class="svg_success" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                </svg>
                <svg class="svg_error" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" />
                </svg>
            </span>
            <span class="alert_msg"></span>
        </div>

        <div class="top-header">
            <p class="title_otp"><?php esc_html_e('لطفا کد اعتبارسنجی ارسال شده به موبایل خود را در کادر زیر وارد نمایید.', 'woodmartplus'); ?></p>
            <div class="action-links">
                <div class="resend-code">
                    <span class="timer"><?php esc_html_e('ارسال مجدد کد تا', 'woodmartplus'); ?><span id="countdown"></span></span>
                </div>
            </div>
        </div>

        <form action="#" method="POST" class="step_otp">

            <div class="otp-inputs" dir="ltr">
                <input type="text" class="otp-input" maxlength="<?php echo $number_digits; ?>" autocomplete="one-time-code" />
            </div>

            <button type="submit" class="submit-btn">
                <span class="btn-text"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('four_btn_text', 'تایید و ادامه')); ?></span>
                <div class="loading-spinner"></div>
            </button>

            <div class="extra-links" style="justify-content: space-between;">
                <a href="#" class="back_to_start" onclick="event.preventDefault();"></a>
            </div>
            <input type="hidden" value="<?php echo wp_create_nonce('form_verify_otp') ?>" class="nonce_verify_otp">
            
        </form>
    </div>

    <div class="form-box" style="display: none;">
        <div class="top-header">
            <?php if ($logo): ?>
                <div class="logo-area">
                    <div class="logo-container">
                        <img src="<?php echo $logo; ?>" alt="logo" />
                    </div>
                </div>
            <?php endif; ?>
            <h2><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('three_placeholder_username', 'بازیابی رمز عبور')); ?></h2>

            <div class="alert slide-in">
                <span class="alert-icon">
                    <svg class="svg_success" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                    </svg>
                    <svg class="svg_error" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" />
                    </svg>
                </span>
                <span class="alert_msg"></span>
            </div>

        </div>
        <form class="reset_password">
            <div class="input-group">
                <div class="floating-input-field">
                    <input type="password" class="newpassword" name="newpassword" required autocomplete="off">
                    <label for="newpassword"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('three_placeholder_password', 'رمزعبور')); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16 12H8M12 8V16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                        <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <div class="floating-input-field">
                    <input type="password" class="repeatpassword" name="repeatpassword" required autocomplete="off">
                    <label for="repeatpassword"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('three_placeholder_passwordreapet', 'تکرار رمزعبور')); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </div>
            </div>
            <button type="submit" class="submit-btn">
                <span class="btn-text"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('three_btn_text', 'بازیابی')); ?></span>
                <span class="loading-spinner"></span>
            </button>
            <input type="hidden" value="<?php echo wp_create_nonce('form_reset_password') ?>" class="nonce_reset_password">
        </form>
    </div>

    <div class="form-box" style="display:none;">
        <div class="top-header">
            <?php if ($logo): ?>
                <div class="logo-area">
                    <div class="logo-container">
                        <img src="<?php echo $logo; ?>" alt="logo" />
                    </div>
                </div>
            <?php endif; ?>
            <h2><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('five_title_text', 'ثبت نام')); ?></h2>

            <div class="alert slide-in">
                <span class="alert-icon">
                    <svg class="svg_success" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                    </svg>
                    <svg class="svg_error" width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" />
                    </svg>
                </span>
                <span class="alert_msg"></span>
            </div>

        </div>

        <form class="register_step">
            <div class="input-group">

                <div class="floating-input-field">
                    <input type="text" class="user_name" name="user_name" required autocomplete="off">
                    <label for="user_name"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('five_username_text', 'نام کاربری')); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M20.5899 22C20.5899 18.13 16.7399 15 11.9999 15C7.25991 15 3.40991 18.13 3.40991 22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>

                <div class="floating-input-field email_here">
                    <input type="text" class="email" name="email" required autocomplete="off">
                    <label for="email"><?php esc_html_e('ایمیل', 'woodmartplus'); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M22 6L12 13L2 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                
                <?php if( wplus_helper::get_setting('enable_field_birthday') ): ?>
                <div class="floating-input-field birth_day_class">
                    <input type="text" id="birth_day" name="birth_day" required autocomplete="off">
                    <label for="birth_day"><?php esc_html_e('تاریخ تولد', 'woodmartplus'); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M22 6L12 13L2 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <?php endif; ?>

                <div class="floating-input-field">
                    <input type="password" class="new_password" name="new_password" required autocomplete="off">
                    <label for="new_password"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('five_password_text', 'رمزعبور')); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16 12H8M12 8V16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                        <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <div class="floating-input-field">
                    <input type="password" class="repate_password" name="repate_password" required autocomplete="off">
                    <label for="repate_password"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('five_passwordrepat_text', 'تکرار رمزعبور')); ?></label>
                    <svg class="input-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </div>
            </div>
            <button type="submit" class="submit-btn">
                <span class="btn-text"><?php echo $translate_shortcode->prepare_message(wplus_helper::get_setting('five_btn_text', 'ثبت نام')); ?></span>
                <span class="loading-spinner"></span>
            </button>
            <input type="hidden" value="<?php echo wp_create_nonce('form_register') ?>" class="nonce_form_register">
        </form>
    </div>
</div>