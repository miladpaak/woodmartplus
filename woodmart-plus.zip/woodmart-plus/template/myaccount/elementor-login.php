<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>

   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/all.css">
   <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/fontawesome.css">
   <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/global-fonts.css">
   <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/hint.min.css">
   <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/global.css">
   <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/kamadatepicker.min.css">
   <style>
      :root {
         --width-width3: <?php echo wplus_helper::get_setting('width_dashboard') . 'px'; ?>;
         --main-color: <?php echo wplus_helper::get_setting('color_dashboard'); ?>;
         --link-color: <?php echo wplus_helper::get_setting('color_link_dashboard'); ?>;
         --red-1: <?php echo wplus_helper::get_setting('color_dashboard'); ?>;
         --red-5: <?php echo wplus_helper::get_setting('color_dashboard_hover'); ?>;
         --blue-3: <?php echo wplus_helper::get_setting('color_dashboard'); ?>;
         --wplus_dashboard_font : <?php echo wplus_helper::get_setting('font_dashboard', 'IRANSansX');  ?>;
      }
      
      :root {
         --primary-color: var(--main-color);
         --secondary-color: var(--red-5);
         --background-color: #f5f5f5;
         --form-background: rgba(255, 255, 255, 0.98);
         --text-primary: #333;
         --text-secondary: #666;
         --shadow-color: var(--red-5);
         --border-color: #eee;
      }

      <?php 
       $firstColor = wplus_helper::get_background_img_color_login('color_bg_login_register');
       $secoundColor = wplus_helper::get_setting('color_two_bg_login_register');
       $background = $firstColor .'!important';
       if( $secoundColor )
       {
         $background = 'linear-gradient(233deg, '.$firstColor.', '.$secoundColor.') !important';
       }
      ?>

      body {

         font-family: <?php echo wplus_helper::get_setting('font_dashboard', 'IRANSansX');  ?>;
         background: <?php echo $background ?>;
         background-repeat: no-repeat;
         background-size: 100% auto;
         background-position: center top;
         background-attachment: fixed;
      }

      html body {

         font-family: var(--wplus_dashboard_font) !important;
      }

      .text_darkgray {
         line-height: 2.7;
         margin-top: 17px;
         text-align: center;
      }

      .login_container img {
         width: 100px;
      }
   </style>
   <?php wp_head(); ?>
</head>
<?php do_action('woodplus_dashboard_head'); ?>
<?php wp_enqueue_script('kamadatepicker'); ?>
<body <?php body_class(); ?>>


   <?php do_action('elementor_login_register'); ?>

   <?php wp_footer(); ?>
  
   <?php if (wplus_helper::get_setting('setting_recaptcha_enable')): ?>
      <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallbackCaptcha&render=explicit"></script>
   <?php endif; ?>
   
</body>

</html>