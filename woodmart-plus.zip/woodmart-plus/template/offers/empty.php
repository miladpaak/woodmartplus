<div class="white_card">
    <div class="nocontent_section">
    <div class="nocontent_section__image">
        <img src="<?php echo WOODPLUS_ASSET ?>img/offer-none.png">
    </div>
    <h5 class="nocontent_section__title">
        <?php esc_html_e('هیچ کد تخفیفی ندارید.', 'woodmartplus'); ?>
    </h5>
    </div>
</div>