<div class="white_card">
    <div class="nocontent_section">
        <div class="nocontent_section__image">
            <img src="<?php echo WOODPLUS_ASSET ?>img/notification-none.png">
        </div>
        <h5 class="nocontent_section__title">
            <?php esc_html_e('هیچ اعلانی ندارید.', 'woodmartplus'); ?>
        </h5>
    </div>
</div>