 <div class="solid_input">
    <label for="sltTicketCategory"><?php esc_html_e('دپارتمان', 'woodmartplus'); ?></label>
    <select name="admin_departeman" class="select_departeman ticket_select_items">
        <option value="departman_default"><?php esc_html_e('دپارتمان را انتخاب کنید', 'woodmartplus'); ?></option>
        <?php foreach ($departemans as $key => $departeman): ?>
        <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($departeman); ?></option>
        <?php endforeach; ?>
    </select>
</div>