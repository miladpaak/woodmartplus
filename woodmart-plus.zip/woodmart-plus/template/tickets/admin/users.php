
<div class="item p-18 br-bottom select2_category">
    <span class="title"><?php esc_html_e('انتخاب کاربر', 'woodmartplus') ?></span>
    <p class="des"><?php esc_html_e('برای ارسال تیکت ، یک کاربر را باید انتخاب کنید', 'woodmartplus'); ?></p>
    <div>
        <select class="multi-select-user" name="user_selected_for_ticket" >
            <option value="" selected="selected"></option>
        </select>
    </div>
</div>

