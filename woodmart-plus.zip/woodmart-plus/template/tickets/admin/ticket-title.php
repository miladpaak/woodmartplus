<div class="item br-bottom p-18">
    <span class="title"><?php echo esc_html_e('عنوان', 'woodmartplus'); ?></span>
    <p class="des"><?php esc_html_e('عنوان تیکت را وارد کنید', 'woodmartplus'); ?></p>
    <div class="suggestion-inputs gray-inp">
        <input type="text" class="left-text" name="send_ticket_title" value="" placeholder="<?php esc_html_e('تیکت مدیریتی','woodmartplus'); ?>">
    </div>
</div>
