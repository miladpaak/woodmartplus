<?php
/**
 * Loop Add to Cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/add-to-cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;



echo apply_filters(
	'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
	sprintf(
		'<a href="%s" data-quantity="%s" class="%s arams-btn-add-to-cart" %s><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" role="img" > <path d="M3 4h2l.7 3L7 15h9.8a2 2 0 0 0 1.95-1.56l1.5-6.44A1 1 0 0 0 19.3 6H5.7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/> <circle cx="9" cy="19" r="1.6" fill="currentColor"/> <circle cx="17" cy="19" r="1.6" fill="currentColor"/> <circle cx="18.5" cy="5.5" r="3" fill="currentColor" opacity=".2"/> <text x="18.5" y="6.15" text-anchor="middle" font-size="3.4" font-family="inherit" fill="currentColor" style="font-weight:700">3</text> </svg><div class="lds-ring"><div></div><div></div><div></div><div></div></div></a>',
		esc_url( $product->add_to_cart_url() ),
		esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
		esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
		isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
	),
	$product,
	$args
);