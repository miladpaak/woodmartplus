<div class="tab-content active" id="overviewTab">
    <div id="detailsBody">
        <div class="detail-section">
            <div class="detail-title"><?php esc_html_e('شرایط هدف‌گیری','woodmartplus'); ?></div>
            <div class="detail-content">
                <p>
                    <?php echo esc_html($campaign['condition_text']); ?>
                </p>
                <p>
                    <?php echo esc_html($campaign['user_success']); ?>
                </p>
            </div>
        </div>

        <div class="detail-section">
            <div class="detail-title"><?php esc_html_e('زمان‌بندی','woodmartplus'); ?></div>
            <div class="detail-content">
                <strong><?php esc_html_e('نوع ارسال:','woodmartplus'); ?></strong> <?php echo esc_html($campaign['type']); ?> <br />
                <strong><?php esc_html_e('تاریخ ایجاد:','woodmartplus'); ?></strong> <?php echo esc_html($campaign['campaign_created']); ?> <br />
                <?php if( $campaign['date_send'] ): ?>
                    <strong><?php esc_html_e('تاریخ ارسال:','wi-win'); ?></strong> <?php echo esc_html($campaign['date_send']); ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="detail-section">
            <div class="detail-title"><?php esc_html_e('کد تخفیف','woodmartplus'); ?></div>
            <div class="detail-content">
                <strong><?php esc_html_e('کد تخفیف : ','woodmartplus'); ?></strong> <?php echo esc_html($campaign['coupon_code']) ?>  <br />
                <strong><?php esc_html_e('تاریخ انقضا : ','woodmartplus'); ?></strong> <?php echo esc_html($campaign['coupon_code_expire']) ?> <br />
                <strong><?php esc_html_e('فعال بودن برای این کمپین :','wi-win'); ?> <?php echo esc_html($campaign['exclusive_campaign']) ?> </strong> 
            </div>
        </div>
    </div>
</div>