<?php include_once 'campaign-detial.php'; ?>
<?php include_once 'users-detial.php'; ?>
<?php include_once 'logs-detial.php'; ?>