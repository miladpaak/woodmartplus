 <div class="tab-content" id="logsTab">
   
    <!-- جدول لاگ‌ها -->
    <div class="logs-container">
        <table class="logs-table">
            <thead>
                <tr>
                    <th>شماره تلفن</th>
                    <th>وضعیت</th>
                    <th>زمان ارسال</th>
                    <th>توضیحات</th>
                </tr>
            </thead>
            <tbody id="logsTableBody">
                <?php foreach( $campaingLogs as $campaingLog ): ?>
                    <tr>
                        <td class="phone-number"><?php echo esc_html($campaingLog['phone']); ?></td>
                        <td><span class="status-badge <?php echo esc_html($campaingLog['class']); ?>"><?php echo esc_html($campaingLog['status']); ?></span></td>
                        <td><?php echo esc_html($campaingLog['time']); ?></td>
                        <td><?php echo esc_html($campaingLog['description']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>