    <div class="tab-content" id="usersTab">
    <?php if( $usersDetial ): ?>
    <div class="excel-export-sticky">
        <button type="button" class="excel-export-btn" id="exportExcelBtn" data-campaing_id="<?php echo  esc_attr($usersDetial['transition']); unset($usersDetial['transition']); ?>">
            <svg class="excel-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="rgba(255,255,255,0.1)"/>
                <polyline points="14,2 14,8 20,8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <line x1="16" y1="13" x2="8" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <line x1="16" y1="17" x2="8" y2="17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <polyline points="10,9 9,9 8,9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <?php esc_html_e('خروجی اکسل','woodmartplus'); ?>
        </button>
    </div>
     <?php endif; ?>
    <div class="users-container" style="max-height: 400px; overflow-y: auto;">
        <table class="users-table">
            <thead>
                <tr>
                    <th><?php esc_html_e('شناسه','woodmartplus'); ?></th>
                    <th><?php esc_html_e('نام و نام خانوادگی','woodmartplus'); ?></th>
                    <th><?php esc_html_e('شماره تلفن','woodmartplus'); ?></th>
                </tr>
            </thead>
            
            <tbody id="usersTableBody">
                <?php if( $usersDetial ): ?>
                    <?php foreach( $usersDetial as $user_detial ): ?>
                        <tr>
                            <td>
                                <a href="<?php echo $user_detial['link_profile'] ?>" target="_blank"><?php echo $user_detial['id']; ?></a>
                            </td>
                            <td>
                                <?php echo $user_detial['fullname']; ?>
                            </td>
                            <td class="phone-number">
                                <?php echo $user_detial['phone']; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td>
                            <?php esc_html_e('کاربری یافت نشد','woodmartplus'); ?>
                        </td>
                        <td>
                            <?php esc_html_e('کاربری یافت نشد','woodmartplus'); ?>
                        </td>
                        <td class="phone-number">
                            <?php esc_html_e('کاربری یافت نشد','woodmartplus'); ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
