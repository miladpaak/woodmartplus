<div class="license-callout" dir="rtl">
  <div class="license-icon" aria-hidden="true">
    <!-- SVG Key Icon -->
    <svg viewBox="0 0 24 24" width="44" height="44" role="img">
      <path d="M21 7a5 5 0 0 1-6.59 4.73l-1.22 1.22h-1.59v1.59H10v1.59H8.41L5 20l-1.5-1.5 2.3-2.3V14.6h1.59v-1.59h1.59v-1.59l1.22-1.22A5 5 0 1 1 21 7Zm-5-3a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"></path>
    </svg>
  </div>

  <div class="license-content">
   <h2 class="license-title" style="
    padding-right: 5px;
    padding-bottom: 15px;

">لایسنس قالب و پلاگین وودمارت پلاس تداخل دارند یا فعال نیستند</h2>
    

    
    <div class="license-note">
      <strong>توجه:</strong>

      اگر مطمئن هستید که لایسنس شما فعال می‌باشد لطفا قالب و پلاگین وودمارت پلاس خود را به آخرین نسخه که در در وبسایت راست‌چین وجود دارد بروزرسانی نمایید تا لایسنس برایتان سازگار شود.
    
    </div>

    <div class="license-actions">
      <a target="_blank" href="http://file.lordwp.site/learning-woodmartpluss/licensecheck.mp4" class="btn btn-primary">اگر لایسنس قالب فعال است اما محتویات وودمارت پلاس نمایش داده نمیشود کلیک نمایید</a>
      
    </div>
  </div>
</div>

<style>
  .license-callout{
    --radius:16px;
    --shadow:0 10px 30px rgba(0,0,0,.12);
    --grad:linear-gradient(135deg,#6C5CE7 0%,#00C2FF 100%);
    display:flex; align-items:center; gap:20px;
    padding:22px; border-radius:var(--radius);
    background: var(--grad);
    color:#fff; box-shadow:var(--shadow);
width:93%;
margin:30px 10px 0px 5px;
  }
  .license-content{
    background: rgba(255,255,255,.14);
    backdrop-filter: blur(8px);
    border-radius:12px;
    padding:16px 18px;
    max-width: 780px;
    width:100%;
  }
  .license-icon{
    flex:0 0 auto;
    display:grid; place-items:center;
    width:64px; height:64px; border-radius:14px;
    background: rgba(255,255,255,.18);
    border:1px solid rgba(255,255,255,.3);
  }
  .license-icon svg{ fill:#fff; opacity:.95; }

  .license-title{
    margin:0 0 6px; font-size:20px; font-weight:800;
  }
  .license-desc{
    margin:0 0 14px; font-size:14px; color:#eef2ff; opacity:.95;
  }

  /* باکس توجه */
  .license-note{
    background: rgba(255, 193, 7, 0.2); /* رنگ زرد شفاف */
    border: 1px solid rgba(255, 193, 7, 0.6);
    color: #fffbea;
    padding: 10px 14px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 16px;
    line-height: 1.8;
  }
  .license-note strong{
    color: #ffe066;
    font-weight: 800;
  }

  .license-actions{ display:flex; gap:10px; flex-wrap:wrap; }
  .btn{
    padding:10px 16px; border-radius:12px;
    font-size:14px; font-weight:700; text-decoration:none;
    transition: transform .15s ease;
    border:1px solid transparent;
  }
  .btn:hover{ transform: translateY(-1px); }
  .btn-primary{
    background:#fff; color:#0f172a;
  }
  .btn-ghost{
    background: transparent; color:#fff; border-color:rgba(255,255,255,.5);
  }
  .btn-ghost:hover{ background: rgba(255,255,255,.12); }
</style>
