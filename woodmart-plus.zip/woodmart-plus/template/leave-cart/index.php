<div id="cart-details-popup" class="cart-popup-overlay">


    <div class="cart-popup-content">

        <div class="popup-header">
            <h3><?php esc_html_e('جزئیات سبد خرید', 'woodmartplus'); ?></h3>
            <span class="close-popup">&times;</span>
        </div>

        <div class="popup-body">

            <!-- Customer Info Section -->
            <div class="customer-info-section">
                <div>
                    <h4><?php esc_html_e('اطلاعات مشتری', 'woodmartplus'); ?></h4>
                    <div class="customer-details">
                        <p><strong><?php esc_html_e('نام:', 'woodmartplus'); ?></strong> <span class="customer-name"></span></p>
                        <p><strong><?php esc_html_e('موبایل:', 'woodmartplus'); ?></strong> <span class="customer-phone"></span></p>
                    </div>
                </div>
            </div>
            <!-- Cart Products Section -->
            <div class="cart-products-section">
                <div class="lds-ripple">
                    <div></div>
                    <div></div>
                </div>
                <div class="cart_detial">
                    <h4><?php esc_html_e('محصولات سبد خرید', 'woodmartplus'); ?></h4>
                    <h4>
                        <span class="title_totalcart"><?php esc_html_e('جمع سبد خرید : ', 'woodmartplus') ?></span>
                        <span class="price_totalcart"></span>
                    </h4>
                </div>
                <div class="products-list">

                </div>
            </div>
            <!-- SMS Section -->
            <div class="sms-section">
                <div class="lds-ripple2">
                    <div></div>
                    <div></div>
                </div>
                <div class="nit"></div>
            </div>

        </div>

        <div class="popup-footer">
            <button class="button-primary send-sms"><?php esc_html_e('ارسال پیامک', 'woodmartplus'); ?></button>
            <button class="button-secondary close-popup"><?php esc_html_e('بستن', 'woodmartplus'); ?></button>
        </div>
    </div>
</div>