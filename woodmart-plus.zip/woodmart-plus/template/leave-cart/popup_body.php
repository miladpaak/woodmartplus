<?php $totalCart = $cart_items['total_cart'];
unset($cart_items['total_cart']); ?>

<span class="trick_totalcart" style="display:none;">
    <?php echo wc_price($totalCart); ?>
</span>

<?php foreach ($cart_items as $item): ?>

    <div class="product-item">
        <div class="product-image">
            <img src="<?php echo $item['product_image'] ?>" alt="<?php echo $item['product_title'] ?>">
        </div>
        <div class="product-info">
            <h5>
                <a href="<?php echo $item['product_link']; ?>"><?php echo $item['product_title']; ?></a>
            </h5>
            <div class="product-meta">
                <span class="quantity">
                    <?php
                    printf(__('تعداد : %s', 'woodmartplus'), $item['quantity']);
                    ?>
                </span>
            </div>
        </div>
        <div class="product-price">
            <?php echo wc_price($item['product_price']); ?>
        </div>
    </div>
<?php endforeach; ?>