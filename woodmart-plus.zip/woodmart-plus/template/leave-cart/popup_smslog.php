<?php
if (!defined('ABSPATH')) exit;
?>

<div id="sms-log-popup" class="sms-log-popup">
    <div class="sms-log-popup-content">
        <div class="sms-log-popup-header">
            <h3><?php esc_html_e('تاریخچه پیامک‌ها', 'woodmartplus'); ?></h3>
            <span class="close-sms-log">&times;</span>
        </div>
        <div class="sms-log-popup-body">
            
            <div class="sms-log-data">
                <div class="sms-log-table-container">
                    <table class="sms-log-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('تاریخ', 'woodmartplus'); ?></th>
                                <th><?php esc_html_e('شماره موبایل', 'woodmartplus'); ?></th>
                                <th><?php esc_html_e('متن پیام', 'woodmartplus'); ?></th>
                                <th><?php esc_html_e('وضعیت', 'woodmartplus'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="sms-log-entries">
                        </tbody>
                    </table>
                </div>
                
                <div class="email-log-table-container">
                    <h4><?php esc_html_e('تاریخچه ایمیل‌ها', 'woodmartplus'); ?></h4>
                    <table class="email-log-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('تاریخ', 'woodmartplus'); ?></th>
                                <th><?php esc_html_e('ایمیل', 'woodmartplus'); ?></th>
                                <th><?php esc_html_e('موضوع', 'woodmartplus'); ?></th>
                                <th><?php esc_html_e('وضعیت', 'woodmartplus'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="email-log-entries">
                        </tbody>
                    </table>
                </div>
                
                <div class="no-logs-message" style="display: none;">
                    <p><?php esc_html_e('هیچ سابقه‌ای یافت نشد.', 'woodmartplus'); ?></p>
                </div>
            </div>
            <div class="sms-log-error">
                <p></p>
            </div>
        </div>
        <div class="sms-log-popup-footer">
            <button class="close-sms-log-btn"><?php esc_html_e('بستن', 'woodmartplus'); ?></button>
        </div>
    </div>
</div>

