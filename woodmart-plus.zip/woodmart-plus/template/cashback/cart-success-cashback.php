
<style>

.cashback-box {
    display: flex;
    align-items: center;
    gap: 15px;
    background: linear-gradient(135deg, #f1f8e9, #dcedc8);
    padding: 20px;
    border: 1px solid #c5e1a5;
    border-radius: 12px;
    margin-top: 25px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    animation: fadeIn 0.5s ease-in-out;
}

.cashback-icon {
    font-size: 27px;
    background-color: #7cb342;
    color: white;
    padding: 14px;
    height: 60px;
    width: 60px;
    border-radius: 50%;
    flex-shrink: 0;
    box-shadow: 0 0 10px rgba(124, 179, 66, 0.5);
}

.cashback-content h4 {
    margin: 0 0 5px 0;
    font-size: 18px;
    color: #33691e;
}

.cashback-content p {
    margin: 0;
    font-size: 15px;
    color: #558b2f;
}

.cashback-amount {
    font-size: 18px;
    color: #1b5e20;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(15px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>

<div class="cashback-box">
    <div class="cashback-icon">🎁</div>
    <div class="cashback-content">
    <h4 style="padding-bottom: 6px;"><?php esc_html_e('مبلغ برگشتی به کیف پول شما','woodmartplus'); ?></h4>
    <?php
        printf(__('همراه این خرید <strong class="cashback-amount" style="margin-left:7px">%s</strong> به کیف پول شما در خرید های بعدی اضافه خواهد شد','woodmartplus'),
            wc_price($result)
        )
    ?>
    </div>
</div>
