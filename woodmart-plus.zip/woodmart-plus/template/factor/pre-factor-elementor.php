<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php esc_html_e('پیش فاکتور','woodmartplus'); ?></title>
    <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/pre-factor.css">
    <?php wp_head(); ?>

    <style>
        :root {
            --color-factor: <?php echo wplus_helper::get_setting('color_pre_factor'); ?>;
            --factor-width: <?php echo wplus_helper::get_setting('width_factor') . 'px'; ?>;
        }
    </style>
</head>
<body <?php body_class(); ?>>
    <div class="action-buttons">
        <button class="action-button print-button" onclick="window.print()">
            <svg><use xlink:href="#icon-print"/></svg>
            <?php esc_html_e('چاپ پیش فاکتور','woodmartplus'); ?>
        </button>
    </div>
  
    <?php do_action('elementor_builder_pre_factor'); ?>
    <?php wp_footer(); ?>
</body>
</html>
