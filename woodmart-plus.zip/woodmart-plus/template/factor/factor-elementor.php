<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php esc_html_e('صفحه فاکتور','woodmartplus'); ?></title>
    <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/pre-factor.css">
    <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/all.css">
    <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/global-fonts.css">
    <link rel="stylesheet" href="<?php echo WOODPLUS_ASSET ?>css/hint.min.css">
    <?php wp_head(); ?>

    <style>
        :root {
            --color-factor: <?php echo wplus_helper::get_setting('color_factor'); ?>;
            --factor-width: <?php echo wplus_helper::get_setting('width_factor') . 'px'; ?>;
        }
        body {
            font-family: <?php echo wplus_helper::get_setting('font_dashboard','iranyekan');  ?> !important;
        }
        .wd-sticky-nav-enabled{
            --wd-sticky-nav-w : 0px;
        }
    </style>
</head>
<body <?php body_class(); ?>>

    <div class="container_prefactor">
        <?php do_action('elementor_builder_factor'); ?>
    </div>
    
    <div class="action-buttons">
        <button class="action-button print-button" onclick="window.print()">
            <svg><use xlink:href="#icon-print"/></svg>
            <?php esc_html_e('چاپ فاکتور','woodmartplus'); ?>
        </button>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
