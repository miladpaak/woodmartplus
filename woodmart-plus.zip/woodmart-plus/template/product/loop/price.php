<?php

global $product, $wc_tag_product_object;
$outOfStockTag = $wc_tag_product_object->get_outofstock_tag();
?>
<?php if( 'outofstock' ===  $product->get_stock_status() && $outOfStockTag ): ?>
    <span class="price">
        <?php echo $outOfStockTag; ?>
    </span>
<?php else: ?>
    <?php if ($price_html = $product->get_price_html()) : ?>
        <span class="price"><?php echo $price_html; ?></span>
    <?php else: ?>
        <span><?php echo $wc_tag_product_object->generate_tag() ?? ''; ?></span>
    <?php endif ?>
<?php endif ?>