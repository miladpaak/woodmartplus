<?php

global $product, $wc_tag_product_object;
$outOfStockTag = $wc_tag_product_object->get_outofstock_tag();
?>
<?php if( 'outofstock' === $product->get_stock_status() && $outOfStockTag ): ?>
    <p class="<?php echo esc_attr(apply_filters('woocommerce_product_price_class', 'price')); ?>"><?php echo $outOfStockTag; ?></p>
<?php else: ?>
    <?php if ($price_html = $product->get_price_html()): ?>
        <p class="<?php echo esc_attr(apply_filters('woocommerce_product_price_class', 'price')); ?>"><?php echo $price_html; ?></p>
    <?php else: ?>
        <h1><?php echo $wc_tag_product_object->generate_single_tag(); ?></h1>
    <?php endif; ?>
<?php endif; ?>
