<div class="order-not-found">

    <div class="not-found-icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line>
        </svg>
    </div>

    <h3 class="not-found-title"><?php esc_html_e('سفارشی یافت نشد','woodmartplus'); ?></h3>
    <p class="not-found-message"><?php esc_html_e('متأسفیم، هیچ سفارشی با اطلاعات وارد شده یافت نشد.','woodmartplus'); ?></p>
</div>